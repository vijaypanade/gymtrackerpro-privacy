// lib/providers/ai_provider.dart
//
// RESPONSIBILITY:
//   - AI coach insights (rule-based daily messages, fatigue level,
//     weight suggestions, recommended sets/modifier)
//   - Performance pattern memory (last 10 sessions for adaptive tone)
//   - AI workout plan generation via ApiService.askAI() — secure backend
//   - Response parsing + fallback handling when backend fails
//   - Daily cache of insight (so message stays stable through the day)
//
// NOT RESPONSIBLE FOR:
//   - Persisting workout logs / week plan (WorkoutProvider)
//   - Computing analytics scores (AnalyticsProvider)
//   - Premium gating (UI / orchestrator decides what to mask)
//
// DESIGN:
//   - Pure inputs via `AICoachInputs` — no direct provider deps.
//   - Performance memory IS owned here because it's an AI concept,
//     not a workout concept. WorkoutProvider notifies us when a day
//     completes via `recordSession()`.

import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../models/memory_models.dart';
import '../models/models.dart';
import '../models/workout_log.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import '../utils/id_helper.dart';

// ═══════════════════════════════════════════════════════════════
// ENUMS
// ═══════════════════════════════════════════════════════════════
enum FatigueLevel    { fresh, normal, fatigued }
enum WeightSuggestion { increase, decrease, maintain }

// ═══════════════════════════════════════════════════════════════
// AI COACH INSIGHT — daily-cached structured output
// ═══════════════════════════════════════════════════════════════
class AICoachInsight {
  final FatigueLevel     fatigueLevel;
  final String           fatigueMessage;
  final WeightSuggestion weightSuggestion;
  final String           weightMessage;
  final String           weakMuscleGroup;
  final String           dailyCoachMessage;
  final int              recommendedSets;
  final double           weightModifier;
  final String           cacheDate;

  const AICoachInsight({
    required this.fatigueLevel,
    required this.fatigueMessage,
    required this.weightSuggestion,
    required this.weightMessage,
    required this.weakMuscleGroup,
    required this.dailyCoachMessage,
    required this.recommendedSets,
    required this.weightModifier,
    required this.cacheDate,
  });

  Map<String, dynamic> toJson() => {
        'fatigueLevel':      fatigueLevel.name,
        'fatigueMessage':    fatigueMessage,
        'weightSuggestion':  weightSuggestion.name,
        'weightMessage':     weightMessage,
        'weakMuscleGroup':   weakMuscleGroup,
        'dailyCoachMessage': dailyCoachMessage,
        'recommendedSets':   recommendedSets,
        'weightModifier':    weightModifier,
        'cacheDate':         cacheDate,
      };

  factory AICoachInsight.fromJson(Map<String, dynamic> j) => AICoachInsight(
        fatigueLevel: FatigueLevel.values.firstWhere(
          (e) => e.name == (j['fatigueLevel'] ?? 'normal'),
          orElse: () => FatigueLevel.normal,
        ),
        fatigueMessage: j['fatigueMessage'] as String? ?? '',
        weightSuggestion: WeightSuggestion.values.firstWhere(
          (e) => e.name == (j['weightSuggestion'] ?? 'maintain'),
          orElse: () => WeightSuggestion.maintain,
        ),
        weightMessage:     j['weightMessage']     as String? ?? '',
        weakMuscleGroup:   j['weakMuscleGroup']   as String? ?? '',
        dailyCoachMessage: j['dailyCoachMessage'] as String? ?? '',
        recommendedSets:   j['recommendedSets']   as int?    ?? 4,
        weightModifier:    (j['weightModifier']   as num?)?.toDouble() ?? 1.0,
        cacheDate:         j['cacheDate']         as String? ?? '',
      );

  static const defaultInsight = AICoachInsight(
    fatigueLevel:      FatigueLevel.fresh,
    fatigueMessage:    '✅ Fully recovered — optimal performance today!',
    weightSuggestion:  WeightSuggestion.maintain,
    weightMessage:     '🎯 Focus on form today — build your foundation.',
    weakMuscleGroup:   '',
    recommendedSets:   4,
    weightModifier:    1.0,
    dailyCoachMessage: '🚀 Day 1 — The hardest part is starting. You did it!',
    cacheDate:         '',
  );
}

// ═══════════════════════════════════════════════════════════════
// PERFORMANCE PATTERN — one row of session memory
// ═══════════════════════════════════════════════════════════════
class PerformancePattern {
  final String       date;
  final double       volume;
  final int          setsCompleted;
  final int          setsPlanned;
  final double       effortScore;       // 0–100
  final String       mood;
  final bool         wasFailedSession;  // effort < 40
  final List<String> musclesTrained;
  final String       bestExercise;

  const PerformancePattern({
    required this.date,
    required this.volume,
    required this.setsCompleted,
    required this.setsPlanned,
    required this.effortScore,
    required this.mood,
    this.wasFailedSession = false,
    this.musclesTrained   = const [],
    this.bestExercise     = '',
  });

  Map<String, dynamic> toJson() => {
        'date':             date,
        'volume':           volume,
        'setsCompleted':    setsCompleted,
        'setsPlanned':      setsPlanned,
        'effortScore':      effortScore,
        'mood':             mood,
        'wasFailedSession': wasFailedSession,
        'musclesTrained':   musclesTrained,
        'bestExercise':     bestExercise,
      };

  factory PerformancePattern.fromJson(Map<String, dynamic> j) =>
      PerformancePattern(
        date:             j['date']             as String? ?? '',
        volume:           (j['volume']          as num?)?.toDouble() ?? 0,
        setsCompleted:    j['setsCompleted']    as int?    ?? 0,
        setsPlanned:      j['setsPlanned']      as int?    ?? 0,
        effortScore:      (j['effortScore']     as num?)?.toDouble() ?? 0,
        mood:             j['mood']             as String? ?? 'normal',
        wasFailedSession: j['wasFailedSession'] as bool?   ?? false,
        musclesTrained:   (j['musclesTrained']  as List?)?.cast<String>() ?? [],
        bestExercise:     j['bestExercise']     as String? ?? '',
      );
}

// ═══════════════════════════════════════════════════════════════
// COACH INPUTS — what AIProvider needs to compute insights
// ═══════════════════════════════════════════════════════════════
class AICoachInputs {
  final List<WorkoutLog> logs;
  final MoodType         mood;
  final int              currentStreak;
  final int              totalWorkouts;
  final String           goal;
  final String           level;
  final String           trainerType;
  final String           userName;
  final bool             isOnPlateau;
  final bool             needsDeload;
  final int              daysSinceLastWorkout;

  const AICoachInputs({
    required this.logs,
    required this.mood,
    required this.currentStreak,
    required this.totalWorkouts,
    required this.goal,
    required this.level,
    required this.trainerType,
    required this.userName,
    required this.isOnPlateau,
    required this.needsDeload,
    required this.daysSinceLastWorkout,
  });
}

// ═══════════════════════════════════════════════════════════════
// AI WORKOUT REQUEST — what to ask the backend for
// ═══════════════════════════════════════════════════════════════
class AIWorkoutRequest {
  final String                 goal;
  final String                 level;
  final int                    daysPerWeek;
  final List<String>           weakMuscles;
  final bool                   isOnPlateau;
  final bool                   needsDeload;
  final bool                   isFatigued;
  final String                 performanceTrend;
  final List<String>           missedDays;
  final List<String>           recentWorkoutNames;
  final int                    currentStreak;
  final int                    totalWorkouts;
  final double                 weeklyVolumeTrend;
  final List<ExerciseMemory>   exerciseHistory;
  final WeeklyMemory?          lastWeekMemory;

  const AIWorkoutRequest({
    required this.goal,
    required this.level,
    required this.daysPerWeek,
    this.weakMuscles        = const [],
    this.isOnPlateau        = false,
    this.needsDeload        = false,
    this.isFatigued         = false,
    this.performanceTrend   = 'stable',
    this.missedDays         = const [],
    this.recentWorkoutNames = const [],
    this.currentStreak      = 0,
    this.totalWorkouts      = 0,
    this.weeklyVolumeTrend  = 0,
    this.exerciseHistory    = const [],
    this.lastWeekMemory,
  });
}

// ═══════════════════════════════════════════════════════════════
// AI PROVIDER
// ═══════════════════════════════════════════════════════════════
class AIProvider extends ChangeNotifier {
  AICoachInsight       _insight  = AICoachInsight.defaultInsight;
  List<PerformancePattern> _perfMemory = [];
  String _aiSuggestion = ''; // last AI-generated workout summary

  bool _loaded = false;
  bool _generatingPlan = false;

  static const int _maxMemory = 10;

  // ── Public state ─────────────────────────────────────────
  bool get isLoaded => _loaded;
  bool get isGeneratingPlan => _generatingPlan;
  AICoachInsight get insight => _insight;
  List<PerformancePattern> get performanceMemory =>
      List.unmodifiable(_perfMemory);
  String get lastAISuggestion => _aiSuggestion;

  // ── Behavior-derived getters ─────────────────────────────
  double get averageEffortScore {
    if (_perfMemory.isEmpty) return 70;
    final total = _perfMemory.fold(0.0, (s, p) => s + p.effortScore);
    return (total / _perfMemory.length).clamp(0, 100);
  }

  int  get failedSessionCount =>
      _perfMemory.where((p) => p.wasFailedSession).length;
  bool get hasFailurePattern  => failedSessionCount >= 2;

  String get bestPerformingExercise {
    if (_perfMemory.isEmpty) return '';
    final non = _perfMemory.where((p) => p.bestExercise.isNotEmpty).toList();
    if (non.isEmpty) return '';
    final freq = <String, int>{};
    for (final p in non) {
      freq[p.bestExercise] = (freq[p.bestExercise] ?? 0) + 1;
    }
    return (freq.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value)))
        .first
        .key;
  }

  List<String> get musclesSkippedLast7Days {
    const all = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
    final cutoff  = DateTime.now().subtract(const Duration(days: 7));
    final trained = <String>{};
    for (final p in _perfMemory) {
      try {
        final d = DateTime.parse(p.date);
        if (d.isAfter(cutoff)) trained.addAll(p.musclesTrained);
      } catch (_) {}
    }
    return all.where((m) => !trained.contains(m)).toList();
  }

  String get performanceTrend {
    if (_perfMemory.length < 3) return 'stable';
    final recent =
        _perfMemory.take(3).map((p) => p.effortScore).toList();
    final older =
        _perfMemory.skip(3).take(3).map((p) => p.effortScore).toList();
    if (older.isEmpty) return 'stable';
    final rAvg = recent.reduce((a, b) => a + b) / recent.length;
    final oAvg = older.reduce((a, b) => a + b) /  older.length;
    if (rAvg > oAvg + 5) return 'improving';
    if (rAvg < oAvg - 5) return 'declining';
    return 'stable';
  }

  // ═════════════════════════════════════════════════════════
  // LOAD
  // ═════════════════════════════════════════════════════════
  Future<void> load() async {
    if (_loaded) return;
    try {
      // Daily insight cache
      final cached = await StorageService.instance.loadObject<AICoachInsight>(
        StorageKeys.aiCache,
        AICoachInsight.fromJson,
      );
      if (cached != null && cached.cacheDate == _todayStr) {
        _insight = cached;
      }

      // Performance memory
      _perfMemory = await StorageService.instance.loadList<PerformancePattern>(
        StorageKeys.performanceMemory,
        PerformancePattern.fromJson,
      );
    } catch (e) {
      debugPrint('AIProvider.load error: $e');
    } finally {
      _loaded = true;
      notifyListeners();
    }
  }

  // ═════════════════════════════════════════════════════════
  // RECOMPUTE INSIGHT — called when inputs change
  // (mood update, log added, day complete, etc.)
  // ═════════════════════════════════════════════════════════
  Future<void> recomputeInsight(AICoachInputs inputs) async {
    _insight = _computeInsight(inputs);
    notifyListeners();
    await StorageService.instance
        .setJson(StorageKeys.aiCache, _insight.toJson());
  }

  void invalidateInsightCache() {
    _insight = AICoachInsight.defaultInsight;
    notifyListeners();
  }

  // ═════════════════════════════════════════════════════════
  // PERFORMANCE MEMORY
  // ═════════════════════════════════════════════════════════
  Future<void> recordSession({
    required DayPlan day,
    required MoodType mood,
    required String Function(String) normalizeMuscle,
  }) async {
    final setsPlanned   = day.exercises.fold(0, (v, e) => v + e.sets.length);
    final setsCompleted = day.exercises
        .fold(0, (v, e) => v + e.sets.where((s) => s.done).length);
    final volume = _calcVolume(day);
    final effort = setsPlanned > 0
        ? (setsCompleted / setsPlanned * 100).clamp(0, 100).toDouble()
        : 50.0;

    final musclesHit = day.exercises
        .map((e) => normalizeMuscle(e.category))
        .where((m) => m.isNotEmpty)
        .toSet()
        .toList();

    String bestEx = '';
    double bestVol = 0;
    for (final ex in day.exercises) {
      final exVol = ex.sets
          .where((s) => s.done)
          .fold(0.0, (s, set) => s + set.weight * set.reps);
      if (exVol > bestVol) {
        bestVol = exVol;
        bestEx  = ex.name;
      }
    }

    _perfMemory.insert(
      0,
      PerformancePattern(
        date:             _todayStr,
        volume:           volume,
        setsCompleted:    setsCompleted,
        setsPlanned:      setsPlanned,
        effortScore:      effort,
        mood:             mood.name,
        wasFailedSession: effort < 40,
        musclesTrained:   musclesHit,
        bestExercise:     bestEx,
      ),
    );

    if (_perfMemory.length > _maxMemory) {
      _perfMemory = _perfMemory.sublist(0, _maxMemory);
    }

    notifyListeners();
    await _persistMemory();
  }

  Future<void> clearMemory() async {
    _perfMemory = [];
    notifyListeners();
    await _persistMemory();
  }

  // ═════════════════════════════════════════════════════════
  // AI WORKOUT PLAN GENERATION (via ApiService.askAI)
  // ═════════════════════════════════════════════════════════

  /// Generates a workout plan via the secure backend.
  /// Returns parsed JSON map. Falls back to default PPL plan on any error
  /// (including the case where ApiService returns an error string).
  Future<Map<String, dynamic>> generateWorkoutPlan(
      AIWorkoutRequest request) async {
    _generatingPlan = true;
    notifyListeners();
    try {
      final prompt = _buildPrompt(request);
      final raw    = await ApiService.askAI(prompt);

      // ApiService returns error strings prefixed with ⚠️ or ❌ — catch them.
      if (raw.startsWith('⚠️') || raw.startsWith('❌')) {
        debugPrint('AIProvider backend returned error: $raw');
        return _fallbackWorkoutMap();
      }

      final parsed = _parseResponse(raw);
      _aiSuggestion = _formatWorkout(parsed);
      return parsed;
    } catch (e, s) {
      debugPrint('AIProvider.generateWorkoutPlan error: $e\n$s');
      _aiSuggestion = _fallbackText();
      return _fallbackWorkoutMap();
    } finally {
      _generatingPlan = false;
      notifyListeners();
    }
  }

  /// Quick-text variant — used by the dashboard "Get AI workout" button.
  /// Stores the formatted text in `lastAISuggestion`.
  Future<void> generateQuickSuggestion(AIWorkoutRequest request) async {
    final result = await generateWorkoutPlan(request);
    _aiSuggestion = _formatWorkout(result);
    notifyListeners();
  }

  // ═════════════════════════════════════════════════════════
  // PROMPT BUILDING
  // ═════════════════════════════════════════════════════════
  String _buildPrompt(AIWorkoutRequest r) {
    final buf = StringBuffer();
    buf.writeln('You are an elite fitness coach. Generate a personalized weekly workout plan.');
    buf.writeln();
    buf.writeln('USER PROFILE:');
    buf.writeln('- Goal: ${r.goal.replaceAll('_', ' ')}');
    buf.writeln('- Experience: ${r.level}');
    buf.writeln('- Days per week: ${r.daysPerWeek}');
    buf.writeln('- Current streak: ${r.currentStreak} days');
    buf.writeln('- Total workouts completed: ${r.totalWorkouts}');
    buf.writeln();

    buf.writeln('CURRENT STATE:');
    if (r.weakMuscles.isNotEmpty) {
      buf.writeln('- Weak muscles to prioritize: ${r.weakMuscles.join(", ")}');
    }
    if (r.isOnPlateau)  buf.writeln('- User is on a plateau — vary the stimulus');
    if (r.needsDeload)  buf.writeln('- User needs a deload week — reduce intensity 30-40%');
    if (r.isFatigued)   buf.writeln('- User is fatigued — moderate intensity');
    buf.writeln('- Performance trend: ${r.performanceTrend}');
    buf.writeln('- Weekly volume trend: ${r.weeklyVolumeTrend.toStringAsFixed(1)}%');
    if (r.missedDays.isNotEmpty) {
      buf.writeln('- Missed days: ${r.missedDays.join(", ")}');
    }
    if (r.recentWorkoutNames.isNotEmpty) {
      buf.writeln('- Recent workouts: ${r.recentWorkoutNames.join(", ")}');
    }
    buf.writeln();

    if (r.exerciseHistory.isNotEmpty) {
      buf.writeln('RECENT EXERCISE PERFORMANCE (use these as baseline):');
      for (final e in r.exerciseHistory) {
        buf.writeln('- ${e.name}: best ${e.bestWeight}${e.unit} x ${e.bestReps} reps');
      }
      buf.writeln();
    }

    final lw = r.lastWeekMemory;
    if (lw != null) {
      buf.writeln('LAST WEEK SUMMARY:');
      buf.writeln('- Plan: ${lw.planName}');
      buf.writeln('- Completed: ${lw.completedDays}/${lw.plannedDays} days');
      buf.writeln('- Total volume: ${lw.totalVolume.toStringAsFixed(0)}kg');
      buf.writeln('- Avg effort: ${lw.avgEffortScore.toStringAsFixed(0)}%');
      buf.writeln();
    }

    buf.writeln('OUTPUT REQUIREMENTS:');
    buf.writeln('Return ONLY valid JSON in this exact structure (no markdown, no commentary):');
    buf.writeln('{');
    buf.writeln('  "workout_name": "string",');
    buf.writeln('  "days": [');
    buf.writeln('    { "day": "Monday", "focus": "Push", "exercises": [');
    buf.writeln('      { "name": "Bench Press", "sets": 4, "reps": "8-12" }');
    buf.writeln('    ]}');
    buf.writeln('  ]');
    buf.writeln('}');

    return buf.toString();
  }

  Map<String, dynamic> _parseResponse(String raw) {
    try {
      var clean = raw.trim();
      clean = clean.replaceAll(RegExp(r'^```(?:json)?', multiLine: true), '');
      clean = clean.replaceAll(RegExp(r'```$',          multiLine: true), '');
      clean = clean.trim();

      final firstBrace = clean.indexOf('{');
      final lastBrace  = clean.lastIndexOf('}');
      if (firstBrace >= 0 && lastBrace > firstBrace) {
        clean = clean.substring(firstBrace, lastBrace + 1);
      }

      final decoded = jsonDecode(clean);
      if (decoded is Map<String, dynamic>) return decoded;
      return _fallbackWorkoutMap();
    } catch (e) {
      debugPrint('AIProvider._parseResponse error: $e');
      return _fallbackWorkoutMap();
    }
  }

  String _formatWorkout(Map<String, dynamic> data) {
    try {
      final name = data['workout_name'] ?? 'Workout';
      final days = data['days'] as List? ?? [];
      final buf  = StringBuffer('🔥 $name\n\n');
      for (final day in days) {
        if (day is! Map) continue;
        buf.writeln('${day["day"]} — ${day["focus"]}');
        final exercises = day['exercises'] as List? ?? [];
        for (final ex in exercises) {
          if (ex is! Map) continue;
          buf.writeln('• ${ex["name"]} (${ex["sets"]} x ${ex["reps"]})');
        }
        buf.writeln();
      }
      return buf.toString().trim();
    } catch (_) {
      return 'Workout ready 💪';
    }
  }

  String _fallbackText() => '''
AI busy right now ⚠️

🔥 Try this:
Push: Chest + Triceps
Pull: Back + Biceps
Legs: Quads + Hamstrings

Stay consistent 💪''';

  Map<String, dynamic> _fallbackWorkoutMap() => {
        'workout_name': 'Default PPL Plan',
        'days': [
          {'day': 'Monday', 'focus': 'Push', 'exercises': [
            {'name': 'Bench Press',     'sets': 4, 'reps': '8-12'},
            {'name': 'Overhead Press',  'sets': 3, 'reps': '8-10'},
            {'name': 'Tricep Pushdown', 'sets': 3, 'reps': '10-12'},
          ]},
          {'day': 'Tuesday', 'focus': 'Pull', 'exercises': [
            {'name': 'Pull-ups',    'sets': 4, 'reps': '6-10'},
            {'name': 'Barbell Row', 'sets': 3, 'reps': '8-10'},
            {'name': 'Bicep Curl',  'sets': 3, 'reps': '10-12'},
          ]},
          {'day': 'Wednesday', 'focus': 'Legs', 'exercises': [
            {'name': 'Squat',             'sets': 4, 'reps': '6-10'},
            {'name': 'Romanian Deadlift', 'sets': 3, 'reps': '8-10'},
            {'name': 'Calf Raise',        'sets': 3, 'reps': '12-15'},
          ]},
          {'day': 'Thursday', 'focus': 'Rest', 'exercises': []},
          {'day': 'Friday', 'focus': 'Push', 'exercises': [
            {'name': 'Incline Bench', 'sets': 4, 'reps': '8-12'},
            {'name': 'Lateral Raise', 'sets': 3, 'reps': '12-15'},
            {'name': 'Dips',          'sets': 3, 'reps': '8-12'},
          ]},
          {'day': 'Saturday', 'focus': 'Pull', 'exercises': [
            {'name': 'Deadlift',     'sets': 3, 'reps': '5-8'},
            {'name': 'Lat Pulldown', 'sets': 3, 'reps': '10-12'},
            {'name': 'Hammer Curl',  'sets': 3, 'reps': '10-12'},
          ]},
          {'day': 'Sunday', 'focus': 'Rest', 'exercises': []},
        ],
      };

  // ═════════════════════════════════════════════════════════
  // INSIGHT COMPUTATION (rule-based, runs locally — fast)
  // ═════════════════════════════════════════════════════════
  AICoachInsight _computeInsight(AICoachInputs inputs) {
    final fatigue   = _detectFatigueLevel(inputs);
    final wSuggest  = _computeWeightSuggestion(inputs);
    final weakGroup = _detectWeakMuscleGroup(inputs.logs);
    final sets      = _computeRecommendedSets(fatigue, inputs);
    final modifier  = _computeWeightModifier(fatigue, wSuggest, inputs);
    final message   = _generateDailyCoachMessage(
      inputs:    inputs,
      fatigue:   fatigue,
      suggestion: wSuggest,
      weakMuscle: weakGroup,
    );

    return AICoachInsight(
      fatigueLevel:      fatigue,
      fatigueMessage:    _fatigueMessage(fatigue),
      weightSuggestion:  wSuggest,
      weightMessage:     _weightSuggestionMessage(wSuggest, inputs.isOnPlateau),
      weakMuscleGroup:   weakGroup,
      dailyCoachMessage: message,
      recommendedSets:   sets,
      weightModifier:    modifier,
      cacheDate:         _todayStr,
    );
  }

  FatigueLevel _detectFatigueLevel(AICoachInputs inputs) {
    // Use a simple rule: streak + mood + recent volume drops
    int score = 0;
    if (inputs.currentStreak >= 7)  score += 1;
    if (inputs.currentStreak >= 14) score += 1;
    if (inputs.currentStreak >= 21) score += 2;
    if (inputs.mood == MoodType.tired) score += 2;
    if (inputs.mood == MoodType.energetic) score -= 1;
    if (inputs.needsDeload) score += 2;
    if (hasFailurePattern) score += 1;

    if (score >= 4) return FatigueLevel.fatigued;
    if (score >= 2) return FatigueLevel.normal;
    return FatigueLevel.fresh;
  }

  String _fatigueMessage(FatigueLevel l) {
    switch (l) {
      case FatigueLevel.fresh:
        return IdHelper.pickString([
          '✅ Fully recovered — optimal performance today!',
          '🔋 Energy levels high — go get that PR!',
          '💪 Body fully charged — great session ahead!',
        ]);
      case FatigueLevel.normal:
        return IdHelper.pickString([
          '😐 Normal fatigue — train smart, focus on form.',
          '😤 Moderate soreness — warm up well.',
          '🔄 Decent recovery — quality over quantity today.',
        ]);
      case FatigueLevel.fatigued:
        return IdHelper.pickString([
          '⚠️ High fatigue — reduce intensity today.',
          '🔴 Body needs recovery — light session only.',
          '⚡ Significant fatigue detected — deload recommended.',
        ]);
    }
  }

  WeightSuggestion _computeWeightSuggestion(AICoachInputs inputs) {
    if (inputs.logs.isEmpty) return WeightSuggestion.maintain;
    if (inputs.isOnPlateau)  return WeightSuggestion.decrease;

    final recent = inputs.logs.reversed.take(6).toList();
    if (recent.isEmpty) return WeightSuggestion.maintain;

    final lastEx = recent.first;
    final sameEx =
        recent.where((l) => l.exercise == lastEx.exercise).take(3).toList();

    if (sameEx.length < 2) {
      if (lastEx.reps >= 12) return WeightSuggestion.increase;
      if (lastEx.reps <= 5)  return WeightSuggestion.decrease;
      return WeightSuggestion.maintain;
    }

    sameEx.sort((a, b) => b.date.compareTo(a.date));
    final lr = sameEx[0].reps;   final pr = sameEx[1].reps;
    final lw = sameEx[0].weight; final pw = sameEx[1].weight;

    if (lr >= 12 && lw >= pw)              return WeightSuggestion.increase;
    if (lr > pr  && lr >= 10)              return WeightSuggestion.increase;
    if (lr < pr * 0.75 && lr <= 5)         return WeightSuggestion.decrease;
    if (lw > pw * 1.1  && lr < pr * 0.8)   return WeightSuggestion.decrease;
    return WeightSuggestion.maintain;
  }

  String _weightSuggestionMessage(WeightSuggestion s, bool plateau) {
    if (plateau) {
      return '🔄 Plateau detected — drop 10% weight, reset reps, rebuild stronger!';
    }
    switch (s) {
      case WeightSuggestion.increase:
        return IdHelper.pickString([
          '📈 Progressive overload — increase weight 2.5–5kg!',
          '💪 Ready to grow — add weight this session!',
          '🏋️ Your strength has adapted — time to push more!',
        ]);
      case WeightSuggestion.decrease:
        return IdHelper.pickString([
          '⬇️ Reduce load 10% — prioritize form.',
          '🎯 Drop weight slightly — quality reps today.',
          '⚠️ Load too high — reset and rebuild with form.',
        ]);
      case WeightSuggestion.maintain:
        return IdHelper.pickString([
          '🎯 Same weight — perfect form and tempo today.',
          '🔁 Maintain load — squeeze every rep.',
          '💡 Consistent weight — master the movement.',
        ]);
    }
  }

  String _detectWeakMuscleGroup(List<WorkoutLog> logs) {
    if (logs.isEmpty) return '';
    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    final recent = logs.where((l) => l.date.isAfter(cutoff)).toList();
    if (recent.isEmpty) return '';

    const keywords = {
      'Chest':     ['bench', 'chest', 'fly', 'push', 'pec', 'incline', 'decline'],
      'Back':      ['row', 'pull', 'deadlift', 'lat', 'back', 'chin'],
      'Legs':      ['squat', 'leg', 'lunge', 'calf', 'hamstring', 'glute', 'rdl'],
      'Shoulders': ['shoulder', 'press', 'lateral', 'raise', 'delt', 'arnold'],
      'Arms':      ['curl', 'tricep', 'bicep', 'hammer', 'pushdown', 'extension'],
      'Core':      ['plank', 'crunch', 'ab', 'core', 'sit'],
    };

    final freq = <String, int>{};
    for (final log in recent) {
      final n = log.exercise.toLowerCase();
      for (final entry in keywords.entries) {
        if (entry.value.any((k) => n.contains(k))) {
          freq[entry.key] = (freq[entry.key] ?? 0) + 1;
          break;
        }
      }
    }

    if (freq.isEmpty) return '';
    const expected = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms'];
    String weakest = '';
    int    minFreq = 999;
    for (final m in expected) {
      final c = freq[m] ?? 0;
      if (c < minFreq) {
        minFreq = c;
        weakest = m;
      }
    }
    return weakest;
  }

  int _computeRecommendedSets(FatigueLevel f, AICoachInputs inputs) {
    final base = inputs.level == 'beginner'
        ? 3
        : inputs.level == 'advanced'
            ? 5
            : 4;
    final plateauBonus = inputs.isOnPlateau ? 1 : 0;
    switch (f) {
      case FatigueLevel.fatigued:
        return (base - 1 + plateauBonus).clamp(2, 6);
      case FatigueLevel.fresh:
        return (base + 1 + plateauBonus).clamp(3, 6);
      case FatigueLevel.normal:
        return (base + plateauBonus).clamp(2, 6);
    }
  }

  double _computeWeightModifier(
    FatigueLevel f,
    WeightSuggestion s,
    AICoachInputs inputs,
  ) {
    double m = 1.0;
    switch (f) {
      case FatigueLevel.fatigued: m *= 0.80; break;
      case FatigueLevel.normal:   m *= 0.95; break;
      case FatigueLevel.fresh:    break;
    }
    switch (s) {
      case WeightSuggestion.increase: m *= 1.05; break;
      case WeightSuggestion.decrease: m *= 0.90; break;
      case WeightSuggestion.maintain: break;
    }
    if (inputs.isOnPlateau) m *= 0.90;
    return m.clamp(0.5, 1.15);
  }

  // ═════════════════════════════════════════════════════════
  // DAILY COACH MESSAGE GENERATOR (adaptive tone, behavior-aware)
  // ═════════════════════════════════════════════════════════
  String _generateDailyCoachMessage({
    required AICoachInputs inputs,
    required FatigueLevel fatigue,
    required WeightSuggestion suggestion,
    required String weakMuscle,
  }) {
    final style    = _adaptiveTone(inputs.trainerType);
    final streak   = inputs.currentStreak;
    final inactive = inputs.daysSinceLastWorkout >= 3;
    final trend    = performanceTrend;
    final mood     = inputs.mood;

    // 1. Streak pressure — one day from milestone
    if (streak > 0) {
      if (streak == 6)  return _streakPressure(style, streak, '7-DAY FIRE BADGE');
      if (streak == 13) return _streakPressure(style, streak, 'UNSTOPPABLE BADGE');
      if (streak == 29) return _streakPressure(style, streak, 'IRON WILL BADGE');
      if (streak == 59) return _streakPressure(style, streak, 'LEGEND STATUS');
    }

    // 2. Comeback message
    if (inactive) {
      final days = inputs.daysSinceLastWorkout;
      return _style(
        style,
        friendly: '👋 $days days since your last session. No judgment — let\'s write your comeback today 💪',
        strict:   '📋 $days days missed. Acknowledge it. Move past it. Today begins the rebuild.',
        military: '🪖 ${days}D OFFLINE. WELCOME BACK. OPERATION RESUME. EXECUTE.',
        hype:     '🔥 $days DAYS?? Your comeback story starts RIGHT NOW! MAKE IT EPIC!!',
      );
    }

    // 3. Failure pattern
    if (hasFailurePattern) {
      return _style(
        style,
        friendly: '💙 I\'ve noticed you\'ve been struggling lately. That\'s human — but today, just finish ONE set. Then another.',
        strict:   '📊 Pattern detected: 2+ incomplete sessions. Today: minimum 3 sets. Consistency first.',
        military: '🪖 PATTERN: FAILING. CORRECTION MODE. 3 SETS MINIMUM. EXECUTE MISSION.',
        hype:     '🧠 Your brain says quit — your BODY says go. Override it! Just START — momentum will carry you!!',
      );
    }

    // 4. Deload signal
    if (inputs.needsDeload) {
      return _style(
        style,
        friendly: '🔄 Volume dropping 3 sessions. Smart move: deload week. Light sets, mobility focus.',
        strict:   '⚠️ Volume declining 3 sessions. Mandatory deload. 60% intensity max.',
        military: '🪖 DELOAD PROTOCOL ACTIVE. DATA SAYS REDUCE. EXECUTE.',
        hype:     '💡 Deload THIS week = comeback NEXT week with NEW PRS!! Trust the science!!',
      );
    }

    // 5. Plateau
    if (inputs.isOnPlateau) {
      return _style(
        style,
        friendly: '🔄 Plateau! Let\'s shake it up — drop 10%, add sets, attack from a new angle.',
        strict:   '📊 Strength stagnant 3+ sessions. Reset: -10% weight, +1 set. Rebuild.',
        military: '🪖 PLATEAU DETECTED. CHANGING TACTICS. DROP WEIGHT. ADD VOLUME. MOVE.',
        hype:     '💥 PLATEAU?! That\'s just your body BEGGING for a new stimulus! DESTROY IT!!',
      );
    }

    // 6. Skipped muscles (memory-based)
    final skipped = musclesSkippedLast7Days;
    if (skipped.isNotEmpty) {
      final s   = skipped.first;
      final cap = '${s[0].toUpperCase()}${s.substring(1)}';
      return _style(
        style,
        friendly: '🎯 $cap hasn\'t been trained in 7 days — let\'s fix that imbalance today!',
        strict:   '⚠️ $cap skipped 7+ days. Muscle imbalance forming. Address it today.',
        military: '🪖 MEMORY ALERT: $cap NEGLECTED 7 DAYS. CORRECT IMBALANCE. TODAY.',
        hype:     '🔥 Your $cap is collecting dust for 7 DAYS! Wake it UP — time to PUNISH IT!!',
      );
    }

    // 7. Declining trend
    if (trend == 'declining') {
      return _style(
        style,
        friendly: '💙 Noticed your effort dipping. That\'s okay — just show up today. That\'s the whole goal.',
        strict:   '📉 Performance declining. Evaluate: sleep? food? stress? Then fix one thing today.',
        military: '🪖 EFFORT LEVEL: DEGRADING. IDENTIFY CAUSE. CORRECT. REPORT.',
        hype:     '🔥 You\'re in a slump but LEGENDS were BUILT in slumps! TODAY IS THE TURNING POINT!!',
      );
    }

    // 8. Mood × fatigue combos
    if (mood == MoodType.tired && fatigue == FatigueLevel.fatigued) {
      return _style(
        style,
        friendly: '😴 Body + mind are tired. Light session — still counts! 💪',
        strict:   '😐 Tired and fatigued. Drop 30% intensity. Stay consistent.',
        military: '🪖 FATIGUE REAL. REDUCE WEIGHT. NEVER REDUCE EFFORT.',
        hype:     '💤 60% effort today builds the habit. Champions REST smart!',
      );
    }
    if (mood == MoodType.energetic && fatigue == FatigueLevel.fresh) {
      return _style(
        style,
        friendly: '⚡ FULLY charged today! This is a PR day — go for it! 🔥',
        strict:   '🔥 Peak energy + full recovery = PR day. Attack every set.',
        military: '🪖 MAXIMUM READINESS. TODAY WE DESTROY RECORDS.',
        hype:     '🚀 FULL ENERGY + FULL RECOVERY = LEGEND STATUS TODAY!! GO!!',
      );
    }
    if (fatigue == FatigueLevel.fatigued) {
      return _style(
        style,
        friendly: '⚠️ You\'re slightly fatigued — focus on form, not weight 💪',
        strict:   '⚠️ Fatigue detected. Reduce load 20%. Prioritize recovery.',
        military: '🪖 TACTICAL DELOAD. High fatigue. Reduce weight. Execute form.',
        hype:     '💥 Lighter today = HEAVIER tomorrow! Smart athletes adapt!',
      );
    }

    // 9. Improving — push harder
    if (trend == 'improving') {
      final best = bestPerformingExercise;
      return _style(
        style,
        friendly: best.isNotEmpty
            ? '📈 You\'ve been on a roll! $best is your best move right now — own it today!'
            : '📈 Your effort has been improving! Keep this momentum going!',
        strict:   '📈 3-session upward trend. Progressive overload today. No excuses.',
        military: '🪖 UPWARD TREND CONFIRMED. CAPITALIZE. ADD WEIGHT TODAY.',
        hype:     '🚀 YOU\'VE BEEN ON ABSOLUTE FIRE!! Ride this wave and SMASH YOUR PR!!',
      );
    }

    // 10. Weak muscle focus
    if (weakMuscle.isNotEmpty) {
      return _style(
        style,
        friendly: '🎯 Your $weakMuscle is lagging — prioritize it today!',
        strict:   '🎯 Weak point: $weakMuscle. Address the imbalance today.',
        military: '🪖 WEAKNESS DETECTED: $weakMuscle. Eliminate it. Add sets.',
        hype:     '🔥 $weakMuscle is your kryptonite — TODAY WE DESTROY IT!!',
      );
    }

    // 11. Weight progression
    if (suggestion == WeightSuggestion.increase) {
      return _style(
        style,
        friendly: '📈 Ready to level up — add 2.5kg today! You\'ve earned it!',
        strict:   '📈 Performance supports overload. Increase load today.',
        military: '🪖 DATA SAYS INCREASE. ADD WEIGHT. THAT IS THE MISSION.',
        hype:     '🔥 YOUR BODY IS READY TO GROW!! ADD WEIGHT AND MAKE HISTORY!!',
      );
    }

    // 12. Streak milestone
    if (streak > 0 && streak % 7 == 0) {
      return IdHelper.pickString([
        '👑 $streak-day streak! You are genuinely becoming someone different.',
        '🔱 $streak days straight. Most people don\'t make it here.',
        '⚔️ $streak-day warrior. The discipline is real now.',
      ]);
    }

    // 13. Beginner phase
    if (inputs.totalWorkouts < 7) {
      return _beginnerMotivation(inputs.totalWorkouts);
    }

    // 14. Goal-based fallback
    return _goalMessage(inputs.goal);
  }

  String _adaptiveTone(String userPreference) {
    if (hasFailurePattern) return 'strict';
    if (averageEffortScore >= 80 && performanceTrend == 'improving') {
      return 'motivational';
    }
    if (performanceTrend == 'declining' && !hasFailurePattern) {
      return 'friendly';
    }
    return userPreference;
  }

  String _streakPressure(String style, int current, String reward) {
    return _style(
      style,
      friendly: '🔥 $current-day streak! ONE more day unlocks the $reward. Don\'t let it slip now!',
      strict:   '📊 $current days in. $reward requires 1 more session. Show up.',
      military: '🪖 ${current}D STREAK. 1 DAY FROM $reward. THIS IS NOT THE DAY TO STOP.',
      hype:     '💥 $current DAYS AND THE $reward IS ONE SESSION AWAY!! DON\'T YOU DARE QUIT NOW!!',
    );
  }

  String _style(String style, {
    required String friendly,
    required String strict,
    required String military,
    required String hype,
  }) {
    switch (style) {
      case 'strict':       return strict;
      case 'military':     return military;
      case 'motivational': return hype;
      default:             return friendly;
    }
  }

  String _beginnerMotivation(int totalWorkouts) {
    const msgs = [
      '🚀 Day 1 — The hardest part is starting. You already won by showing up.',
      '🔥 Day 2 — Yesterday counts. Two in a row means a pattern is forming.',
      '💪 Day 3 — Third session. Your nervous system is beginning to adapt.',
      '⚡ Day 4 — Four days. Discipline is overriding motivation. That\'s growth.',
      '🏆 Day 5 — Five days in. Most people quit at day 3. You didn\'t.',
      '😈 Day 6 — One more. Tomorrow you\'ll be someone who completed a full week.',
      '👑 Day 7 — FULL WEEK COMPLETE. The version of you who started day 1 is gone.',
    ];
    return msgs[(totalWorkouts - 1).clamp(0, msgs.length - 1)];
  }

  String _goalMessage(String goal) {
    final options = <String, List<String>>{
      'fat_loss': [
        '🔥 Burn mode ON — push the pace today!',
        '💦 Fat burning session — keep rest short!',
        '⚡ Metabolic conditioning — go hard!',
      ],
      'muscle_gain': [
        '💪 Mind-muscle connection — quality reps!',
        '🏋️ Hypertrophy focus — slow, controlled tempo.',
        '📈 Volume day — squeeze every rep!',
      ],
      'strength': [
        '🏋️ Heavy day — attack the big lifts!',
        '💪 Strength focus — compound movements first.',
        '⚡ Power session — warm up thoroughly!',
      ],
    };
    final list = options[goal] ?? ['⚡ Another day, another session. Let\'s go!'];
    return IdHelper.pickString(list);
  }

  // ═════════════════════════════════════════════════════════
  // HELPERS
  // ═════════════════════════════════════════════════════════
  double _calcVolume(DayPlan day) {
    double total = 0;
    for (final ex in day.exercises) {
      for (final s in ex.sets) {
        if (!s.done) continue;
        if (ex.unit == 'min') {
          total += s.weight.clamp(0, 600);
        } else if (ex.bodyweight || ex.unit == 'reps') {
          total += s.reps.clamp(0, 999).toDouble();
        } else {
          total += (s.weight * (s.reps > 0 ? s.reps : 1)).clamp(0, 100000);
        }
      }
    }
    return total;
  }

  Future<void> _persistMemory() async {
    await StorageService.instance.setJson(
      StorageKeys.performanceMemory,
      _perfMemory.map((p) => p.toJson()).toList(),
    );
  }

  String get _todayStr {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-'
           '${n.day.toString().padLeft(2, '0')}';
  }
}
