import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';

import 'providers/ai_provider.dart';
import 'providers/analytics_provider.dart';
import 'providers/app_provider.dart';
import 'providers/gamification_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/user_provider.dart';
import 'providers/workout_provider.dart';

import 'screens/splash_screen.dart';

import 'services/ad_service.dart';
import 'services/billing_service.dart';
import 'services/monetization_service.dart';
import 'services/notification_service.dart';
import 'services/storage_service.dart';

import 'utils/app_constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await runZonedGuarded(() async {
    // 🔥 1. HIVE INIT
    await Hive.initFlutter();
    await Future.wait([
      Hive.openBox(StorageKeys.hiveWorkoutBox),
      Hive.openBox(StorageKeys.hiveLogsBox),
      Hive.openBox(StorageKeys.hiveSettingsBox),
    ]);

    // 🔥 2. FIREBASE INIT
    try {
      await Firebase.initializeApp();
    } catch (e, s) {
      debugPrint('❌ Firebase init failed: $e');
      debugPrint('$s');
    }

    // 🔥 3. CRASHLYTICS (FULL COVERAGE)
    FlutterError.onError = (details) {
      if (!kDebugMode) {
        FirebaseCrashlytics.instance.recordFlutterFatalError(details);
      } else {
        FlutterError.presentError(details);
      }
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      if (!kDebugMode) {
        FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      }
      return true;
    };

    // 🔥 4. STORAGE
    await StorageService.instance.init();

    // 🔥 5. MONETIZATION
    await MonetizationService.instance.init();

    // 🔥 6. ADS
    await MobileAds.instance.initialize();

    if (kDebugMode) {
      MobileAds.instance.updateRequestConfiguration(
        RequestConfiguration(
          testDeviceIds: ['E3803C1921456FA984C44D432ACE4118'],
        ),
      );
    }

    await AdService.instance.init(
      isPremium: MonetizationService.instance.isPremium,
    );

    // 🔥 7. BILLING + NOTIFICATIONS
    await Future.wait([
      BillingService.instance.init(),
      NotificationService.instance.init(),
    ]);

    // 🔥 8. UI CONFIG
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgSurface,
      systemNavigationBarIconBrightness: Brightness.light,
    ));

    runApp(const GymTrackerProApp());
  }, (error, stack) {
    if (!kDebugMode) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    } else {
      debugPrint('❌ Unhandled error: $error');
      debugPrint('$stack');
    }
  });
}

class GymTrackerProApp extends StatelessWidget {
  const GymTrackerProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // 🔹 BASIC PROVIDERS
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
        ChangeNotifierProvider(create: (_) => AnalyticsProvider()),
        ChangeNotifierProvider(create: (_) => AIProvider()),

        // ✅ FIXED: NO DOUBLE LOAD
        ChangeNotifierProvider(
          create: (_) => WorkoutProvider(), // ❌ ..load() removed
        ),

        ChangeNotifierProvider(create: (_) => GamificationProvider()),

        // 🔹 MAIN ORCHESTRATOR (STABLE)
        ChangeNotifierProxyProvider5<
            UserProvider,
            WorkoutProvider,
            AnalyticsProvider,
            AIProvider,
            SettingsProvider,
            AppProvider>(
          create: (ctx) => AppProvider(
            user: ctx.read<UserProvider>(),
            workout: ctx.read<WorkoutProvider>(),
            analytics: ctx.read<AnalyticsProvider>(),
            ai: ctx.read<AIProvider>(),
            settings: ctx.read<SettingsProvider>(),
          )..init(),

          // ✅ FIXED: NO RE-CREATION
         update: (ctx, user, workout, analytics, ai, settings, previous) {
  return previous ??
      AppProvider(
        user: user,
        workout: workout,
        analytics: analytics,
        ai: ai,
        settings: settings,
      )..init();
},
        ),
      ],
      child: MaterialApp(
        title: 'AI Trainer',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const SplashScreen(),
      ),
    );
  }
}