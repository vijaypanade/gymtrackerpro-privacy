// lib/services/gemini_service.dart — v4.0 WEEKLY MEMORY COACH
// ═══════════════════════════════════════════════════════════════
// OPTION A: Exercise history (PRs + recent weights) injected into prompt
//           → AI knows "last week bench = 60kg×8" → suggests 62.5kg
//
// OPTION B: WeeklyMemory system — stores last week's plan + performance
//           → Next week plan is explicitly based on previous week
//           → Proper periodization: week 1 base, week 2 overload, week 3 peak, week 4 deload
// ═══════════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:http/http.dart' as http;

// ─────────────────────────────────────────────────────────────────
// OPTION B: Weekly Memory Model
// Stored in SharedPreferences — persists across app restarts
// ─────────────────────────────────────────────────────────────────
class WeeklyMemory {
  final int    weekNumber;       // 1, 2, 3, 4...
  final String weekStartDate;    // ISO date string
  final String planName;         // "PPL Week 2"
  final double totalVolume;      // kg lifted this week
  final double avgEffortScore;   // 0-100
  final int    completedDays;    // how many days done
  final int    plannedDays;      // how many days were planned
  final bool   wasDeload;        // was this a deload week?
  final List<ExerciseMemory> topExercises; // top 6 exercises with weights

  const WeeklyMemory({
    required this.weekNumber,
    required this.weekStartDate,
    required this.planName,
    required this.totalVolume,
    required this.avgEffortScore,
    required this.completedDays,
    required this.plannedDays,
    required this.wasDeload,
    required this.topExercises,
  });

  Map<String, dynamic> toJson() => {
    'weekNumber':     weekNumber,
    'weekStartDate':  weekStartDate,
    'planName':       planName,
    'totalVolume':    totalVolume,
    'avgEffortScore': avgEffortScore,
    'completedDays':  completedDays,
    'plannedDays':    plannedDays,
    'wasDeload':      wasDeload,
    'topExercises':   topExercises.map((e) => e.toJson()).toList(),
  };

  factory WeeklyMemory.fromJson(Map<String, dynamic> j) => WeeklyMemory(
    weekNumber:     j['weekNumber']     as int?    ?? 1,
    weekStartDate:  j['weekStartDate']  as String? ?? '',
    planName:       j['planName']       as String? ?? '',
    totalVolume:    (j['totalVolume']   as num?)?.toDouble() ?? 0,
    avgEffortScore: (j['avgEffortScore'] as num?)?.toDouble() ?? 0,
    completedDays:  j['completedDays']  as int?    ?? 0,
    plannedDays:    j['plannedDays']    as int?    ?? 0,
    wasDeload:      j['wasDeload']      as bool?   ?? false,
    topExercises:   ((j['topExercises'] as List?) ?? [])
        .map((e) => ExerciseMemory.fromJson(e as Map<String, dynamic>))
        .toList(),
  );

  // Periodization phase based on week number (4-week cycle)
  String get phase {
    switch (weekNumber % 4) {
      case 1: return 'base';       // Week 1: establish baseline
      case 2: return 'overload';   // Week 2: increase volume
      case 3: return 'peak';       // Week 3: max intensity
      case 0: return 'deload';     // Week 4: recovery
      default: return 'base';
    }
  }

  String get nextPhase {
    switch (weekNumber % 4) {
      case 1: return 'overload';
      case 2: return 'peak';
      case 3: return 'deload';
      case 0: return 'base';
      default: return 'overload';
    }
  }
}

class ExerciseMemory {
  final String name;
  final double bestWeight;  // PR this week
  final int    bestReps;
  final String unit;        // 'kg' | 'reps' | 'min'
  final double totalVolume; // weight × reps × sets this week
  final String muscleGroup; // ✅ NEW: 'back' | 'chest' | 'legs' | 'shoulders' | 'arms' | 'core'

  const ExerciseMemory({
    required this.name,
    required this.bestWeight,
    required this.bestReps,
    required this.unit,
    required this.totalVolume,
    this.muscleGroup = '', // ✅ NEW
  });

  Map<String, dynamic> toJson() => {
    'name':        name,
    'bestWeight':  bestWeight,
    'bestReps':    bestReps,
    'unit':        unit,
    'totalVolume': totalVolume,
    'muscleGroup': muscleGroup, // ✅ NEW
  };

  factory ExerciseMemory.fromJson(Map<String, dynamic> j) => ExerciseMemory(
    name:        j['name']        as String? ?? '',
    bestWeight:  (j['bestWeight'] as num?)?.toDouble() ?? 0,
    bestReps:    j['bestReps']    as int?    ?? 0,
    unit:        j['unit']        as String? ?? 'kg',
    totalVolume: (j['totalVolume'] as num?)?.toDouble() ?? 0,
    muscleGroup: j['muscleGroup'] as String? ?? '', // ✅ NEW
  );

  // Human-readable summary for prompt injection — includes muscle group
  String get promptSummary {
    final muscle = muscleGroup.isNotEmpty ? ' [$muscleGroup]' : '';
    if (unit == 'reps' || bestWeight == 0) {
      return '$name$muscle: ${bestReps}reps (bodyweight)';
    }
    if (unit == 'min') {
      return '$name$muscle: ${bestReps}min';
    }
    return '$name$muscle: ${bestWeight}kg × ${bestReps}reps';
  }
}

// ─────────────────────────────────────────────────────────────────
// GEMINI SERVICE
// ─────────────────────────────────────────────────────────────────
class GeminiService {

  static const String _baseUrl =
    'https://generativelanguage.googleapis.com/v1beta/models/'
    'gemini-2.5-flash:generateContent'; // 1.5 च्या जागी 2.5-flash वापरून पहा


  final String apiKey;
  GeminiService(this.apiKey);

  Future<Map<String, dynamic>> generateWorkout({
    required String goal,
    required String experience,
    required int    daysPerWeek,
    required List<String> weakMuscles,
    // Performance context
    bool   isOnPlateau       = false,
    bool   needsDeload       = false,
    bool   isFatigued        = false,
    String performanceTrend  = 'stable',
    List<String> missedDays  = const [],
    List<String> recentWorkouts = const [],
    int    currentStreak     = 0,
    int    totalWorkouts     = 0,
    double weeklyVolumeTrend = 0,
    // OPTION A: Recent exercise history with actual weights
    List<ExerciseMemory> exerciseHistory = const [],
    // OPTION B: Last week's memory for periodization
    WeeklyMemory? lastWeekMemory,
  }) async {
    if (apiKey.isEmpty) {
      return _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);
    }

    try {
      final prompt = _buildSmartPrompt(
        goal:              goal,
        experience:        experience,
        days:              daysPerWeek,
        weakMuscles:       weakMuscles,
        isOnPlateau:       isOnPlateau,
        needsDeload:       needsDeload,
        isFatigued:        isFatigued,
        performanceTrend:  performanceTrend,
        missedDays:        missedDays,
        recentWorkouts:    recentWorkouts,
        currentStreak:     currentStreak,
        totalWorkouts:     totalWorkouts,
        weeklyVolumeTrend: weeklyVolumeTrend,
        exerciseHistory:   exerciseHistory,
        lastWeekMemory:    lastWeekMemory,
      );

      final response = await http.post(
        Uri.parse('$_baseUrl?key=$apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [{'parts': [{'text': prompt}]}],
          'generationConfig': {
            'temperature':     0.4,
            'topK':            40,
            'topP':            0.9,
            'maxOutputTokens': 2000,
          },
        }),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode != 200) {
        return _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'] as String?;
      if (text == null || text.trim().isEmpty) {
        return _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);
      }

      final parsed = _parseJsonSafely(text);
      if (parsed == null) {
        return _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);
      }

      return _validateAndNormalise(parsed, daysPerWeek)
          ?? _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);

    } catch (_) {
      return _fallbackWorkout(goal: goal, days: daysPerWeek, experience: experience);
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // SMART PROMPT — A + B combined
  // ─────────────────────────────────────────────────────────────────
  String _buildSmartPrompt({
    required String goal,
    required String experience,
    required int    days,
    required List<String> weakMuscles,
    required bool   isOnPlateau,
    required bool   needsDeload,
    required bool   isFatigued,
    required String performanceTrend,
    required List<String> missedDays,
    required List<String> recentWorkouts,
    required int    currentStreak,
    required int    totalWorkouts,
    required double weeklyVolumeTrend,
    required List<ExerciseMemory> exerciseHistory,
    required WeeklyMemory? lastWeekMemory,
  }) {
    final weakStr   = weakMuscles.isNotEmpty ? weakMuscles.join(', ') : 'none';
    final missedStr = missedDays.isNotEmpty  ? missedDays.join(', ')  : 'none';

    // ── OPTION A: Exercise history — grouped by muscle ────────────
    String historyBlock = '';
    if (exerciseHistory.isNotEmpty) {
      // Group exercises by muscle group for clearer AI context
      final byMuscle = <String, List<ExerciseMemory>>{};
      for (final ex in exerciseHistory) {
        final key = ex.muscleGroup.isNotEmpty ? ex.muscleGroup : 'other';
        byMuscle.putIfAbsent(key, () => []).add(ex);
      }

      final muscleOrder = ['chest','back','legs','shoulders','arms','core','other'];
      final grouped = StringBuffer();
      for (final muscle in muscleOrder) {
        final exList = byMuscle[muscle];
        if (exList == null || exList.isEmpty) continue;
        final cap = muscle[0].toUpperCase() + muscle.substring(1);
        grouped.writeln('  $cap:');
        for (final ex in exList) {
          grouped.writeln('    • ${ex.promptSummary}  [vol: ${ex.totalVolume.toStringAsFixed(0)}kg]');
        }
      }

      historyBlock = '''
━━━ LAST WEEK EXERCISE DATA — USE FOR WEIGHT PROGRESSION ━━━
(User's custom exercises — muscle group auto-detected from exercise name)

$grouped
PROGRESSION RULES (apply per exercise above):
- Reps at TOP of target range → increase weight +2.5kg next week
- Reps at BOTTOM of range    → keep weight, cue form
- Reps in middle             → same weight, target +1 rep
- Bodyweight exercise        → if hit top reps → add difficulty or slow tempo
- MAINTAIN the same split structure user set up (Back+Bicep, Chest+Tricep, Legs+Shoulders)
  unless user has missed days or needs deload
''';
    }

    // ── OPTION B: Weekly memory + periodization block ─────────────
    String memoryBlock = '';
    String weekDirective = '';

    if (lastWeekMemory != null) {
      final completionPct = lastWeekMemory.plannedDays > 0
          ? ((lastWeekMemory.completedDays / lastWeekMemory.plannedDays) * 100).round()
          : 0;

      memoryBlock = '''
━━━ LAST WEEK MEMORY (OPTION B — PERIODIZATION REFERENCE) ━━━
Week number: ${lastWeekMemory.weekNumber}
Last week plan: ${lastWeekMemory.planName}
Completion: ${lastWeekMemory.completedDays}/${lastWeekMemory.plannedDays} days ($completionPct%)
Total volume lifted: ${lastWeekMemory.totalVolume.toStringAsFixed(0)}kg
Average effort score: ${lastWeekMemory.avgEffortScore.toStringAsFixed(0)}/100
Was deload week: ${lastWeekMemory.wasDeload ? 'YES' : 'NO'}
Current phase: ${lastWeekMemory.phase} → Next phase: ${lastWeekMemory.nextPhase}
''';

      weekDirective = _getWeekDirective(lastWeekMemory, isFatigued, isOnPlateau);
    } else {
      weekDirective = '''
━━━ WEEK DIRECTIVE ━━━
This is Week 1 — establish baseline.
- Use moderate weights the user can handle with good form
- 3-4 sets per exercise
- Focus on movement quality
- Do NOT suggest specific weights (user has no history yet)
''';
    }

    final splitGuide   = _getSplitGuide(experience, days);
    final adaptDir     = lastWeekMemory == null
        ? _getAdaptationDirective(
            isOnPlateau: isOnPlateau,
            needsDeload: needsDeload,
            isFatigued:  isFatigued,
            performanceTrend: performanceTrend,
            weeklyVolumeTrend: weeklyVolumeTrend,
          )
        : ''; // week directive already handles this when memory exists

    return '''
You are an elite strength & conditioning AI coach inside a professional gym tracking app.
You have access to the user's actual training history. Use it to generate a SPECIFIC, PROGRESSIVE plan — not a generic one.

━━━ USER PROFILE ━━━
Goal: $goal
Experience: $experience
Days per week: $days
Current streak: $currentStreak days
Total workouts completed: $totalWorkouts
Performance trend: $performanceTrend
Weekly volume change: ${weeklyVolumeTrend > 0 ? '+' : ''}${weeklyVolumeTrend.toStringAsFixed(0)}%
Weak muscles: $weakStr
Missed days this week: $missedStr

━━━ SPLIT PROGRAMMING ━━━
$splitGuide

$memoryBlock

$historyBlock

$weekDirective

$adaptDir

━━━ CRITICAL RULES ━━━
0. MANDATORY: Generate EXACTLY $days workout days in the "days" array — no more, no less.
1. NEVER repeat last week's exact exercises — rotate at least 30% for variation
2. If exercise history is provided, suggest SPECIFIC weights based on progression rules
3. Never train same muscle group 2 days in a row
4. Compound movements must come first in each session
5. Sets/reps based on experience AND current phase:
   - Deload: 2-3 sets, 12-15 reps, 50-60% normal weight
   - Base: 3-4 sets, 10-12 reps
   - Overload: 4-5 sets, 8-10 reps, heavier weight
   - Peak: 4-5 sets, 5-6 reps, max weight
6. Notes field = specific coaching cue OR exact weight suggestion based on history
7. Coach message must reference their actual data (streak, last week volume, specific exercises)

━━━ OUTPUT — RETURN ONLY VALID JSON, NO MARKDOWN ━━━
{
  "workout_name": "descriptive name with week phase e.g. PPL Week 2 — Overload",
  "strategy": "2-3 sentence explanation of what changed from last week and why",
  "coach_message": "specific message referencing their actual weights/streak/progress",
  "week_number": ${lastWeekMemory != null ? lastWeekMemory.weekNumber + 1 : 1},
  "phase": "${lastWeekMemory?.nextPhase ?? 'base'}",
  "days": [
    {
      "day": "Day 1",
      "focus": "Chest + Triceps",
      "intensity": "Moderate",
      "exercises": [
        {
          "name": "Bench Press",
          "sets": 4,
          "reps": "8-10",
          "rest": "90s",
          "notes": "Last week: 60kg×8. Target this week: 62.5kg×8. Drive feet into floor."
        }
      ]
    }
  ]
}
''';
  }

  // ─────────────────────────────────────────────────────────────────
  // WEEK DIRECTIVE — based on periodization phase
  // ─────────────────────────────────────────────────────────────────
  String _getWeekDirective(
      WeeklyMemory last, bool isFatigued, bool isOnPlateau) {
    final nextPhase = last.nextPhase;
    final wasLowCompletion = last.completedDays < last.plannedDays - 1;

    // Override: if user missed many days last week → repeat base week
    if (wasLowCompletion && nextPhase != 'deload') {
      return '''
━━━ WEEK DIRECTIVE: REPEAT BASE (low completion last week) ━━━
Last week completion was low (${last.completedDays}/${last.plannedDays} days).
- Do NOT increase volume or intensity
- Repeat the same split structure as last week
- Keep exercises and weights similar — focus on consistency first
- Coach message should acknowledge the struggle, not punish
''';
    }

    switch (nextPhase) {
      case 'overload':
        return '''
━━━ WEEK DIRECTIVE: OVERLOAD WEEK ━━━
Last week was base. This week INCREASE volume.
- Add 1 set to all main compound lifts (e.g. 3→4 sets)
- Increase weight by 2.5-5kg on exercises where last week's top reps were hit
- Keep same exercises as last week (progressive overload requires consistency)
- Intensity label: "Hard" for compound days
- Strategy must mention: "+1 set on compounds, +2.5kg where possible"
''';

      case 'peak':
        return '''
━━━ WEEK DIRECTIVE: PEAK WEEK ━━━
This is the intensity peak. Go heavy.
- Reduce reps to 5-6 range on compounds
- Increase weight 5-7.5% vs overload week
- Keep sets same as overload week
- Drop 1-2 isolation exercises, replace with heavier compound variations
- Intensity label: "Very Hard" for main days
- Strategy must mention: "Reduced reps, maximum load — PR attempt week"
''';

      case 'deload':
        return '''
━━━ WEEK DIRECTIVE: DELOAD WEEK ━━━
Body needs recovery after 3 weeks of hard training.
- Reduce ALL sets by 40% (e.g. 4 sets → 2-3 sets)
- Reduce weight by 20-30% across all exercises
- Increase reps to 12-15 range
- Focus on mobility and form, not intensity
- Intensity label: "Deload" for all days
- Strategy must mention: "Planned deload — 40% volume reduction for recovery"
- Coach message should be encouraging: "Smart athletes deload. You'll come back stronger."
''';

      default: // base
        return '''
━━━ WEEK DIRECTIVE: BASE WEEK (new cycle) ━━━
Starting fresh 4-week cycle after deload.
- Return to normal volume (4 sets per compound)
- Use weights from 2 weeks ago as starting point
- Introduce 2-3 new exercise variations for stimulus
- Intensity label: "Moderate"
- Strategy must mention: "New training cycle — fresh start with improved baseline"
''';
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // SPLIT GUIDE
  // ─────────────────────────────────────────────────────────────────
  String _getSplitGuide(String experience, int days) {
    switch (experience.toLowerCase()) {
      case 'beginner':
        return 'BEGINNER: Full Body or Upper/Lower. Max 4 exercises/session. 3 sets. Compounds only. No intensity techniques.';
      case 'advanced':
        return 'ADVANCED: Muscle group split. 5-6 exercises/session. 4-5 sets. Include drop sets/supersets on isolation.';
      default:
        return 'INTERMEDIATE: Push/Pull/Legs split. 4-5 exercises/session. 4 sets. Mix compound + isolation.';
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // ADAPTATION DIRECTIVE (used when no weekly memory)
  // ─────────────────────────────────────────────────────────────────
  String _getAdaptationDirective({
    required bool   isOnPlateau,
    required bool   needsDeload,
    required bool   isFatigued,
    required String performanceTrend,
    required double weeklyVolumeTrend,
  }) {
    if (needsDeload) return '⚠️ DELOAD NEEDED: Reduce volume 40%, weights 20-30%, intensity: Deload.';
    if (isFatigued)  return '⚠️ HIGH FATIGUE: Reduce volume 20%, same weights, no intensity techniques.';
    if (isOnPlateau) return '🔄 PLATEAU: Rotate 50% exercises, change rep ranges, add 1 set to compounds.';
    if (performanceTrend == 'improving') return '📈 IMPROVING: Add weight where possible, push for PRs.';
    if (performanceTrend == 'declining') return '📉 DECLINING: Maintain volume, focus on quality over quantity.';
    return '✅ STABLE: Standard progressive week. +1 rep or +2.5kg where possible.';
  }

  // ─────────────────────────────────────────────────────────────────
  // JSON PARSING
  // ─────────────────────────────────────────────────────────────────
  Map<String, dynamic>? _parseJsonSafely(String raw) {
    String clean = raw.replaceAll('```json', '').replaceAll('```', '').trim();
    final start = clean.indexOf('{');
    final end   = clean.lastIndexOf('}');
    if (start == -1 || end == -1 || end <= start) return null;
    clean = clean.substring(start, end + 1);

    try {
      final r = jsonDecode(clean);
      if (r is Map<String, dynamic>) return r;
    } catch (_) {}

    final fixed = clean
        .replaceAll(RegExp(r',\s*}'), '}')
        .replaceAll(RegExp(r',\s*\]'), ']');
    try {
      final r = jsonDecode(fixed);
      if (r is Map<String, dynamic>) return r;
    } catch (_) {}

    return null;
  }

  // ─────────────────────────────────────────────────────────────────
  // VALIDATE & NORMALISE
  // ─────────────────────────────────────────────────────────────────
  Map<String, dynamic>? _validateAndNormalise(
      Map<String, dynamic> raw, int expectedDays) {
    try {
      final rawDays = raw['days'];
      if (rawDays is! List || rawDays.isEmpty) return null;

      final normDays = <Map<String, dynamic>>[];
      for (int i = 0; i < rawDays.length; i++) {
        final d = rawDays[i];
        if (d is! Map) continue;
        final rawEx = d['exercises'];
        if (rawEx is! List) continue;

        final normEx = <Map<String, dynamic>>[];
        for (final e in rawEx) {
          if (e is! Map) continue;
          final name = e['name']?.toString().trim() ?? '';
          if (name.isEmpty) continue;

          final rawReps = e['reps'];
          String repsStr = '10';
          if (rawReps is int) repsStr = rawReps.toString();
          else if (rawReps is String && rawReps.isNotEmpty) repsStr = rawReps;

          final rawSets = e['sets'];
          final sets = rawSets is int
              ? rawSets
              : int.tryParse(rawSets?.toString() ?? '') ?? 3;

          normEx.add({
            'name':  name,
            'sets':  sets.clamp(1, 6),
            'reps':  repsStr,
            'rest':  e['rest']?.toString()  ?? '60s',
            'notes': e['notes']?.toString() ?? '',
          });
        }
        if (normEx.isEmpty) continue;

        normDays.add({
          'day':       d['day']?.toString()       ?? 'Day ${i + 1}',
          'focus':     d['focus']?.toString()     ?? 'Workout',
          'intensity': d['intensity']?.toString() ?? 'Moderate',
          'exercises': normEx,
        });
      }

      if (normDays.isEmpty) return null;

      return {
        'workout_name':  raw['workout_name']?.toString()  ?? 'Smart Plan 💪',
        'strategy':      raw['strategy']?.toString()      ?? '',
        'coach_message': raw['coach_message']?.toString() ?? '',
        'week_number':   raw['week_number']  as int?      ?? 1,
        'phase':         raw['phase']?.toString()         ?? 'base',
        'days':          normDays,
      };
    } catch (_) {
      return null;
    }
  }

  // ─────────────────────────────────────────────────────────────────
  // FALLBACK
  // ─────────────────────────────────────────────────────────────────
  Map<String, dynamic> _fallbackWorkout({
    String goal       = 'muscle gain',
    int    days       = 4,
    String experience = 'intermediate',
  }) {
    final isStrength = goal.contains('strength');
    final isFatLoss  = goal.contains('fat');
    final isBeginner = experience == 'beginner';
    final isAdvanced = experience == 'advanced';
    final s    = isBeginner ? 3 : isAdvanced ? 5 : 4;
    final rest = isStrength ? '3min' : isFatLoss ? '45s' : '90s';

    final push = isStrength
        ? [{'name':'Bench Press','sets':s,'reps':'5','rest':rest,'notes':'Progressive overload — beat last session'},
           {'name':'Overhead Press','sets':s,'reps':'5','rest':rest,'notes':'Brace core, full lockout'},
           {'name':'Tricep Pushdown','sets':3,'reps':'8-10','rest':'90s','notes':'Elbows fixed'}]
        : [{'name':'Bench Press','sets':s,'reps':'8-10','rest':rest,'notes':'Add 2.5kg if hit top range'},
           {'name':'Incline DB Press','sets':s,'reps':'10-12','rest':'75s','notes':'30° incline, upper chest'},
           {'name':'Overhead Press','sets':3,'reps':'10','rest':rest,'notes':'Full ROM'},
           {'name':'Tricep Pushdown','sets':3,'reps':'12','rest':'60s','notes':'Keep elbows pinned'}];

    final pull = [{'name':'Pull Ups','sets':s,'reps':'8','rest':rest,'notes':'Dead hang start, full ROM'},
                  {'name':'Barbell Row','sets':s,'reps':'8-10','rest':rest,'notes':'Drive elbows back'},
                  {'name':'Lat Pulldown','sets':3,'reps':'12','rest':'75s','notes':'Pull to upper chest'},
                  {'name':'Dumbbell Curl','sets':3,'reps':'12','rest':'60s','notes':'Supinate at top'}];

    final legs = isStrength
        ? [{'name':'Squat','sets':s,'reps':'5','rest':'3min','notes':'Belt at 85%+'},
           {'name':'Deadlift','sets':4,'reps':'4','rest':'4min','notes':'Bar over mid-foot'},
           {'name':'Leg Press','sets':3,'reps':'8','rest':'2min','notes':'Full ROM'}]
        : [{'name':'Squat','sets':s,'reps':'8-10','rest':'2min','notes':'Hip crease below knee'},
           {'name':'Romanian Deadlift','sets':s,'reps':'10','rest':'90s','notes':'Hinge until hamstring stretch'},
           {'name':'Leg Press','sets':3,'reps':'12','rest':'90s','notes':'Press through heels'},
           {'name':'Calf Raise','sets':4,'reps':'15','rest':'60s','notes':'Full stretch at bottom'}];

    final allDays = [
      {'day':'Day 1','focus':'Push — Chest, Shoulders, Triceps','intensity':'Moderate','exercises':push},
      {'day':'Day 2','focus':'Pull — Back & Biceps',            'intensity':'Moderate','exercises':pull},
      {'day':'Day 3','focus':'Legs — Quads, Hamstrings, Calves','intensity':'Hard',    'exercises':legs},
      {'day':'Day 4','focus':'Push — Volume Focus',             'intensity':'Moderate','exercises':push},
      {'day':'Day 5','focus':'Pull — Volume Focus',             'intensity':'Moderate','exercises':pull},
      {'day':'Day 6','focus':'Legs — Strength Focus',           'intensity':'Hard',    'exercises':legs},
    ];

    final expName  = isBeginner ? 'Beginner' : isAdvanced ? 'Advanced' : 'Intermediate';
    final goalName = isStrength ? 'Strength' : isFatLoss ? 'Fat Loss' : 'Muscle Building';

    return {
      'workout_name':  '$expName $goalName Plan 💪',
      'strategy':      'Offline fallback plan. Connect to internet for personalised AI plan.',
      'coach_message': 'Offline plan loaded — your history will be used once online.',
      'week_number':   1,
      'phase':         'base',
      'days':          allDays.take(days.clamp(2, 6)).toList(),
    };
  }

  // ─────────────────────────────────────────────────────────
  // COACH MESSAGE — used by CoachProvider for daily AI insight
  // Short response (max 400 tokens) — cached once per day
  // ─────────────────────────────────────────────────────────
  Future<String?> generateCoachMessage({required String prompt}) async {
  if (apiKey.isEmpty) return null;

  try {
    final response = await http.post(
      Uri.parse('$_baseUrl?key=$apiKey'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.6,
          'topK': 40,
          'topP': 0.9,
          'maxOutputTokens': 500,
        },
      }),
    ).timeout(const Duration(seconds: 15));

    print("🔥 STATUS: ${response.statusCode}");
    print("🔥 BODY: ${response.body}");

    if (response.statusCode != 200) {
      print("❌ API ERROR");
      return null;
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;

    final finishReason = data['candidates']?[0]?['finishReason'];
    final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'];

    print("✅ FINISH REASON: $finishReason");

    if (finishReason == 'MAX_TOKENS') {
      print("⚠️ Response cut due to token limit");
    }

    if (text == null || text.toString().trim().isEmpty) {
      print("❌ EMPTY RESPONSE");
      return null;
    }

    return text.toString();

  } catch (e) {
    print("❌ EXCEPTION: $e");
    return null;
  }
}
}
