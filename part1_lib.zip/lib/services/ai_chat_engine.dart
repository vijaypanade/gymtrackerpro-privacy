// lib/services/ai_chat_engine.dart — v8.0 CLEAN & WORKING
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/models.dart';

class AIChatEngine {

  static final Map<String, int> _dailyCount = {};

  static const int _dailyLimit = 3;
  static const String _apiKey = String.fromEnvironment('GEMINI_API_KEY');

  static const String _endpoint =
    'https://generativelanguage.googleapis.com/v1beta/models/'
    'gemini-2.5-flash:generateContent'; // 1.5 च्या जागी 2.5-flash वापरून पहा

  static Future<String> getReply({
    required String userMessage,
    required UserProfile profile,
    required List<Map<String, String>> history,
    int streak           = 0,
    int totalWorkouts    = 0,
    String lastWorkout   = '',
    String skippedMuscle = '',
  }) async {
    final today = _todayKey();
    _dailyCount[today] ??= 0;

    if (_dailyCount[today]! >= _dailyLimit) {
      return '🔒 Daily AI limit reached ($_dailyLimit/$_dailyLimit)\n\nUpgrade to Premium 👑 for unlimited coaching.';
    }

    final reply = await _callGemini(
      prompt: _buildPrompt(profile,
          userMessage:    userMessage,
          streak:         streak,
          totalWorkouts:  totalWorkouts,
          lastWorkout:    lastWorkout,
          skippedMuscle:  skippedMuscle),
    );

    if (reply != null && reply.trim().isNotEmpty) {
  _dailyCount[today] = _dailyCount[today]! + 1;
  return reply;
}

print("⚠️ FALLBACK TRIGGERED");

    return _fallback(userMessage, profile,
        streak: streak, totalWorkouts: totalWorkouts,
        lastWorkout: lastWorkout, skippedMuscle: skippedMuscle);
  }

  static Future<String?> _callGemini({required String prompt}) async {
  try {
    print("🚀 SENDING TO GEMINI...");
    print("📝 PROMPT: $prompt");

    final response = await http.post(
      Uri.parse('$_endpoint?key=$_apiKey'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ],
        // lib/services/ai_chat_engine.dart मध्ये हे बदल कर:

// 1. maxOutputTokens वाढव (120 → 300)
'generationConfig': {
  'temperature': 0.7,
  'maxOutputTokens': 600, // 120 होता, खूप कमी!
},

      }),
    ).timeout(const Duration(seconds: 20));

    print("🔥 STATUS: ${response.statusCode}");
    print("🔥 BODY: ${response.body}");

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      final text = data['candidates']?[0]?['content']?['parts']?[0]?['text'];

      if (text != null && text.toString().trim().isNotEmpty) {
        return _sanitize(text.toString());
      } else {
        print("❌ EMPTY TEXT FROM GEMINI");
      }
    } else {
      print("❌ API ERROR: ${response.body}");
    }
  } catch (e) {
    print("❌ GEMINI EXCEPTION: $e");
  }

  return null;
}

  static String _buildPrompt(
  UserProfile p, {
  required String userMessage,
  required int    streak,
  required int    totalWorkouts,
  required String lastWorkout,
  required String skippedMuscle,
}) {
  final protein = (p.weightKg * (p.goal == 'fat_loss' ? 2.2 : 2.0)).round();
  final water   = (p.weightKg * 35).round();

  return '''
You are an expert fitness coach.

GOAL:
Give accurate, practical, science-based answers.

USER:
Age: ${p.age}
Weight: ${p.weightKg}kg
Goal: ${p.goal}
Level: ${p.level}

RULES:
- EXACTLY 4 lines only
- Each line max 8 words
- No paragraphs
- Use numbers when needed
- End with one action
- No extra explanation
-Use simple words. Avoid long sentences.
LOGIC:
Workout → sets × reps × rest  
Diet → protein + simple foods  
Medical → safe advice only  
Other → direct answer  
If answer is long, compress into 4 short lines.
Every line must be a complete sentence.
Never cut a sentence in middle.
TARGETS:
Protein: ${(p.weightKg * (p.goal == 'fat_loss' ? 2.2 : 2.0)).round()}g/day  
Water: ${(p.weightKg * 35).round()}ml/day  

LANGUAGE:
Reply in same language as user.

USER:
"$userMessage"
''';
}

  static String _personalityPrompt(String type) {
    switch (type) {
      case 'strict':       return 'You are a strict, no-nonsense coach. Blunt and direct. Zero excuses.';
      case 'military':     return 'You are a drill sergeant coach. Short commands. Military language. BE BRIEF.';
      case 'motivational': return 'You are a HYPE coach. High energy. CAPS for emphasis. Exclamation marks!! Unstoppable energy.';
      default:             return 'You are a warm, supportive gym buddy. Genuine, encouraging, specific.';
    }
  }

  // 2. _sanitize() मध्ये lines.take(5) ठेव पण
// blank lines filter कर जेणेकरून 5 meaningful lines येतील

static String _sanitize(String text) {
  final cleaned = text
      .replaceAll(RegExp(r'\*\*(.*?)\*\*'), r'$1')
      .replaceAll(RegExp(r'\*(.*?)\*'),     r'$1')
      .replaceAll(RegExp(r'#{1,6}\s'),      '')
      .replaceAll(RegExp(r'`{1,3}'),        '')
      .trim();

  final lines = cleaned
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.isNotEmpty)  // ← blank lines skip
      .take(5)                      // ← max 5 lines
      .toList();

  return lines.join('\n');
}

  static String _todayKey() {
    final n = DateTime.now();
    return '${n.year}-${n.month}-${n.day}';
  }
static bool _isSimpleQuestion(String msg) {
  final q = msg.toLowerCase();
  return q.contains('joke') ||
         q.contains('what is') ||
         q.contains('calculate') ||
         q.contains('+') ||
         q.contains('*') ||
         q.contains('-');
}

static bool _looksLikeCorrectAnswer(String reply) {
  return reply.length < 120; // simple heuristic
}

static String _simpleAnswer(String msg) {
  if (msg.contains('17') && msg.contains('23')) {
    return '391';
  }
  if (msg.toLowerCase().contains('joke')) {
    return 'Why did the gym trainer break up? Because there was no commitment 💀';
  }
  return 'Try again.';
}
  // ─────────────────────────────────────────────────────────────
  // OFFLINE FALLBACK
  // ─────────────────────────────────────────────────────────────
  static String _fallback(
    String msg,
    UserProfile p, {
    required int    streak,
    required int    totalWorkouts,
    required String lastWorkout,
    required String skippedMuscle,
  }) {
    final q = msg.toLowerCase().trim();
    final t = p.trainerType;
    final n = p.name.isEmpty ? 'Champion' : p.name;
    final protein = (p.weightKg * (p.goal == 'fat_loss' ? 2.2 : 2.0)).round();
    final water   = (p.weightKg * 35).round();

    if (_has(q, ['hi', 'hello', 'hey', 'sup', 'yo', 'namaste'])) {
      if (streak >= 7) return _tone(t,
        f: 'Hey $n! $streak days straight 🔥 You\'re building something real. What do you need?',
        s: '$n. $streak days. Still here. Good. Objective?',
        m: 'ATTENTION $n! $streak-DAY STREAK! State your mission!',
        h: 'YO $n!! ${streak}-DAY STREAK?! YOU\'RE A MACHINE!! 🔥 What are we crushing?!');
      if (totalWorkouts == 0) return _tone(t,
        f: 'Hey $n! 👋 Day 1 — you showed up. That\'s already more than most. Let\'s start!',
        s: '$n. Day 1. What\'s first?',
        m: 'RECRUIT $n! Day 1 begins NOW! First target?',
        h: 'YO $n!! DAY ONE!! LEGENDS START HERE!! 🚀');
      return _tone(t,
        f: 'Hey $n! 💪 Ask me about workouts, diet, or recovery.',
        s: '$n. What do you need.',
        m: '$n. Mission?',
        h: 'YO $n!! LET\'S GO!! 🔥 What are we crushing?!');
    }

    if (_has(q, ['skip', 'lazy', 'tired', 'no energy', 'can\'t', 'don\'t want', 'nahi', 'thak'])) {
      if (streak >= 5) return _tone(t,
        f: '$n, $streak days of discipline vs one moment of doubt. Just 10 minutes. Start.',
        s: '$streak days. Don\'t throw it away. Train.',
        m: '$streak DAYS $n! Soldiers don\'t negotiate with fatigue! MOVE!',
        h: '$streak DAYS AND YOU WANT TO STOP?! NO!! 🔥 10 MINUTES!!');
      return _tone(t,
        f: 'Start anyway. Motivation follows action. Just 10 minutes.',
        s: 'Nobody asked how you feel. Train.',
        m: 'PAIN IS TEMPORARY! REGRET IS FOREVER! MOVE IT!',
        h: 'YOUR FUTURE SELF IS BEGGING YOU!! GET UP!! 🚀');
    }

    if (_has(q, ['chest', 'bench', 'push day', 'pec', 'push up', 'pushup'])) {
      final isBeg = p.level == 'beginner';
      return _tone(t,
        f: isBeg
          ? 'Chest 💪\n• Push-ups 3×15\n• DB Press 3×10\n• Incline 3×12\nRest 90s.'
          : 'Chest 🔥\n• Bench 4×8\n• Incline DB 3×10\n• Cable Fly 3×12\n90s rest.',
        s: 'Chest:\n• Bench 5×5 max\n• Incline 4×8\n• Dips 3×failure',
        m: 'CHEST:\n• Bench 5×5 HEAVY\n• Incline 4×8\n• Dips 3×max\nEXECUTE!',
        h: 'CHEST DAY!! 🔥\n• Bench 5×5\n• Incline 4×10\n• Flys 3×15\nLET\'S GO!!');
    }

    if (_has(q, ['back', 'pull day', 'pullup', 'pull up', 'row', 'lat', 'deadlift'])) {
      return _tone(t,
        f: 'Back 💪\n• Pull-ups 3×8\n• Barbell Row 4×8\n• Lat Pulldown 3×12\n• Face Pull 3×15',
        s: 'Back:\n• Deadlift 4×5\n• Row 4×8\n• Pulldown 3×12',
        m: 'BACK:\n• Deadlift 4×5 MAX\n• Row 4×8\n• Pulldown 3×12\nEXECUTE!',
        h: 'BACK DAY!! 💪🔥\n• Deadlift 4×5\n• Row 4×8\n• Pulldown 3×12\nLET\'S GO!!');
    }

    if (_has(q, ['leg', 'squat', 'quad', 'hamstring', 'calf'])) {
      if (skippedMuscle.toLowerCase().contains('leg')) return _tone(t,
        f: '$n, legs have been skipping 👀 Today we fix that. Squats first. 🦵',
        s: 'Legs neglected. That ends today. Squat rack. Now.',
        m: 'SOLDIER! LEGS NEGLECTED! CORRECTIVE PROTOCOL NOW!',
        h: 'YOU\'VE BEEN AVOIDING LEGS!! NOT TODAY!! 🦵🔥');
      return _tone(t,
        f: 'Leg day 🦵\n• Squats 4×8\n• Leg Press 3×12\n• RDL 3×10\n• Calves 4×20',
        s: 'Legs:\n• Squat 5×5 heavy\n• Press 4×12\n• RDL 3×10',
        m: 'LEGS:\n• Squat 5×5 HEAVY\n• Press 4×12\n• RDL 3×10\nSUFFER!',
        h: 'LEG DAY IS KING!! 🦵🔥\n• Squats 5×5\n• Press 4×15\nCAN\'T WALK = GAINS!!');
    }

    if (_has(q, ['shoulder', 'delt', 'ohp', 'overhead', 'lateral'])) {
      return _tone(t,
        f: 'Shoulders 💪\n• OHP 4×8\n• Lateral Raise 4×12\n• Front Raise 3×12\n• Face Pull 3×15',
        s: 'Shoulders:\n• OHP 5×5\n• Laterals 4×12\n• Face Pull 3×15',
        m: 'SHOULDERS:\n• OHP 5×5 HEAVY\n• Laterals 4×15\nEXECUTE!',
        h: 'SHOULDER DAY!! 💪🔥\n• OHP 5×5\n• Laterals 4×15\nBOULDER SHOULDERS!!');
    }

    if (_has(q, ['arm', 'bicep', 'tricep', 'curl', 'biceps', 'triceps'])) {
      return _tone(t,
        f: 'Arms 💪\n• Barbell Curl 4×10\n• Hammer Curl 3×12\n• Pushdown 4×12\n• Overhead Extension 3×12',
        s: 'Arms:\n• Curl 4×10\n• Pushdown 4×12\nNo cheating.',
        m: 'ARMS:\n• Curl 4×10\n• Pushdown 4×12\nEXECUTE!',
        h: 'ARM DAY!! 💪🔥\n• Curls 4×10\n• Pushdown 4×12\nSLEEVES WON\'T FIT!!');
    }

    if (_has(q, ['ab', 'core', 'six pack', 'plank', 'crunch', 'abs'])) {
      return _tone(t,
        f: 'Core 🔥\n• Plank 3×45s\n• Leg Raises 3×15\n• Crunches 3×20\n• Russian Twist 3×20',
        s: 'Core:\n• Plank 3×60s\n• Leg Raise 4×15\n• Cable Crunch 3×15',
        m: 'CORE:\n• Plank 3×60s\n• Leg Raise 4×15\nIRON CORE!',
        h: 'ABS DAY!! 🔥\n• Plank 3×60s\n• Leg Raise 4×15\nSIX PACK INCOMING!!');
    }

    if (_has(q, ['protein', 'protien', 'diet', 'deit', 'food', 'eat', 'khana',
                 'calories', 'nutrition', 'meal', 'give me', 'macro'])) {
      return _tone(t,
        f: 'Daily target: ${protein}g protein 🍗\nChicken, eggs, paneer, dal, curd.\nHit this = 80% of results.\n${water}ml water too.',
        s: '${protein}g protein. ${water}ml water. Daily. Non-negotiable.',
        m: 'ORDER: ${protein}g PROTEIN + ${water}ml WATER DAILY. Execute.',
        h: 'PROTEIN IS POWER!! ${protein}g DAILY!! 🍗🔥 ${water}ml WATER TOO!!');
    }

    if (_has(q, ['rest', 'recovery', 'sore', 'sleep', 'overtraining', 'fatigue'])) {
      return _tone(t,
        f: 'Recovery IS training 💤\n• 7-8 hrs sleep\n• ${protein}g protein post-gym\n• ${water}ml water\nGains happen during rest.',
        s: 'Rest = growth. 7-8 hrs. ${protein}g protein. Come back stronger.',
        m: 'RECOVERY: 7-8 HRS SLEEP. ${water}ml WATER. ${protein}g PROTEIN. Report at 100%!',
        h: 'SLEEP = GAINS!! 💤🔥 7-8 HRS!!\n${water}ml water!\nCOME BACK STRONGER!!');
    }

    if (_has(q, ['pr', 'personal record', 'new max', '1rm', 'max lift'])) {
      return _tone(t,
        f: 'PR attempt $n! 🏆\nWarm-up: 5×5 at 60% → 3×3 at 80% → attack!\nFull rest between sets.',
        s: 'PR: Warm up. Full rest. One shot.',
        m: 'PR PROTOCOL: Warm up. Rest fully. ATTACK!!',
        h: 'PR DAY!! 🏆🔥 WARM UP RIGHT THEN DEMOLISH YOUR OLD RECORD!!');
    }

    if (_has(q, ['motivation', 'stuck', 'plateau', 'give up', 'not working'])) {
      if (streak >= 3) return _tone(t,
        f: '$streak days $n 💪 You\'re already doing what most only talk about. Keep going.',
        s: '$streak days. Train anyway.',
        m: '$streak-DAY STREAK! CONTINUE THE MISSION!',
        h: '$streak DAYS!! YOU ARE THE MOTIVATION!! 🔥🚀');
      return _tone(t,
        f: 'Discipline over motivation, always. Show up anyway 💪',
        s: 'Stop looking for motivation. Build discipline. Train.',
        m: 'DISCIPLINE IS BUILT IN HARD MOMENTS! MOVE!',
        h: 'STOP WAITING!! START AND THE FEELING FOLLOWS!! 🚀🔥');
    }

    if (_has(q, ['cardio', 'run', 'running', 'treadmill', 'cycling', 'hiit'])) {
      return _tone(t,
        f: 'Cardio 🏃\n20-30 min after weights.\nHR: 130-150 bpm.\nBetter than slow 60 min.',
        s: 'Cardio: 20-30 min post-lifting. 130-150 HR.',
        m: 'CARDIO: 20-30 MIN POST-TRAINING. 130-150 BPM. Execute.',
        h: 'CARDIO TIME!! 🏃🔥 20-30 MINS AFTER WEIGHTS!! FAT DOESN\'T STAND A CHANCE!!');
    }

    if (_has(q, ['supplement', 'creatine', 'whey', 'protein powder', 'pre workout'])) {
      return _tone(t,
        f: 'Priority 🥇\n1. Creatine 5g/day (proven)\n2. Whey if diet is short\n3. Everything else optional.\nFood first.',
        s: 'Creatine 5g/day. Whey if needed. That\'s it.',
        m: 'PROTOCOL: Creatine 5g daily. Whey if required. Execute.',
        h: 'CREATINE IS KING!! 5G DAILY!! 👑 PLUS WHEY IF NEEDED!!');
    }

    if (_has(q, ['home', 'no gym', 'ghar', 'without equipment', 'bodyweight'])) {
      return _tone(t,
        f: 'Home workout 🏠\n• Push-ups 4×15\n• Squats 4×20\n• Plank 3×45s\n• Dips on chair 3×12',
        s: 'Home:\n• Push-ups 4×15\n• Squats 4×20\n• Plank 3×60s\nNo excuses.',
        m: 'HOME PROTOCOL:\n• Push-ups 4×15\n• Squats 4×20\n• Plank 3×60s\nEXECUTE!',
        h: 'HOME WORKOUT!! 🏠🔥\n• Push-ups 4×15\n• Squats 4×20\n• Plank 3×60s\nLET\'S GO!!');
    }

    if (streak >= 3) return _tone(t,
      f: '$streak-day streak $n 🔥 Ask me about workouts, diet, or recovery.',
      s: '$streak days. What do you need.',
      m: '$streak-DAY STREAK! Mission?',
      h: '$streak DAYS OF FIRE!! 🔥 ASK ME ANYTHING!!');

    return _tone(t,
      f: 'I\'m your AI coach $n 💪 Ask about workouts, diet, or recovery.\n'
         '${totalWorkouts > 0 ? "$totalWorkouts sessions done — keep going!" : "Let\'s start your journey!"}',
      s: 'State your question.',
      m: '$n. Mission?',
      h: 'YO $n!! ASK ME ANYTHING!! 🔥 WORKOUTS, DIET, RECOVERY — LET\'S GO!!');
  }

  static bool _has(String text, List<String> keywords) =>
      keywords.any((k) => text.contains(k));

  static String _tone(String type, {
    required String f,
    required String s,
    required String m,
    required String h,
  }) {
    switch (type) {
      case 'strict':       return s;
      case 'military':     return m;
      case 'motivational': return h;
      default:             return f;
    }
  }
}