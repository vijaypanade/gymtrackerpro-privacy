import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();
  final _auth = FirebaseAuth.instance;

  User? get currentUser => _auth.currentUser;
  bool  get isSignedIn  => currentUser != null;

  Future<User?> signInWithGoogle() async {
    try {
      final result = await GoogleSignIn.instance.authenticate();
      final credential = GoogleAuthProvider.credential(
        idToken: result.authentication.idToken,
      );
      final userCredential = await _auth.signInWithCredential(credential);
      return userCredential.user;
    } on FirebaseAuthException catch (e) {
      if (kDebugMode) debugPrint('FirebaseAuth error: ${e.code}');
      return null;
    } catch (e) {
      if (kDebugMode) debugPrint('Sign-In error: $e');
      return _auth.currentUser;
    }
  }

  Future<void> signOut() async {
    try { await _auth.signOut(); }
    catch (e) { if (kDebugMode) debugPrint('signOut: $e'); }
    try { await GoogleSignIn.instance.signOut(); }
    catch (e) { if (kDebugMode) debugPrint('Google signOut: $e'); }
  }
}
