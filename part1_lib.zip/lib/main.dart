// lib/main.dart — PRODUCTION v4.1
// ✅ FIX: google_sign_in ^6.2.1 compatible
//         GoogleSignIn.instance.initialize() काढलं — v6 मध्ये नाही
// ══════════════════════════════════════════════════════════════
// INIT ORDER:
//   1. Flutter bindings
//   2. Crashlytics error handlers
//   3. Hive
//   4. Firebase
//   5. MonetizationService
//   6. MobileAds
//   7. AdService
//   8. BillingService, NotificationService
//   9. runApp()
// ══════════════════════════════════════════════════════════════

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'providers/app_provider.dart';
import 'providers/gamification_provider.dart';
import 'services/monetization_service.dart';
import 'services/ad_service.dart';
import 'services/billing_service.dart';
import 'services/notification_service.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'screens/splash_screen.dart';
import 'utils/app_constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await runZonedGuarded(() async {

    // Step 1: Hive
    await Hive.initFlutter();
    await Future.wait([
      Hive.openBox('workoutBox'),
      Hive.openBox('logsBox'),
      Hive.openBox('settingsBox'),
    ]);

    // Step 2: Firebase
    try {
      await Firebase.initializeApp();
    } catch (e, stack) {
      debugPrint('❌ Firebase init failed: $e');
      debugPrint('Stack: $stack');
    }

    // Step 3: Crashlytics
    if (!kDebugMode) {
      FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterFatalError;
    } else {
      FlutterError.onError = FlutterError.presentError;
    }

    // Step 4: MonetizationService
    await MonetizationService.instance.init();

    // Step 5: MobileAds
    await MobileAds.instance.initialize();
    if (kDebugMode) {
      MobileAds.instance.updateRequestConfiguration(
        RequestConfiguration(
          testDeviceIds: ['E3803C1921456FA984C44D432ACE4118'],
        ),
      );
    }

    // Step 6: AdService
    await AdService.instance.init(
      isPremium: MonetizationService.instance.isPremium,
    );

    // Step 7: Billing + Notifications
    await GoogleSignIn.instance.initialize(
      serverClientId: '613150292675-gfusr43a42eahcd7o9k19nlbrd22ji47.apps.googleusercontent.com',
    );
    //         GoogleSignIn() AuthService मध्ये directly instantiate केला आहे
    await Future.wait([
      BillingService.instance.init(),
      NotificationService.instance.init(),
    ]);

    // Step 8: UI
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor:                    Colors.transparent,
      statusBarIconBrightness:           Brightness.light,
      systemNavigationBarColor:          AppColors.bgSurface,
      systemNavigationBarIconBrightness: Brightness.light,
    ));

    runApp(const GymTrackerProApp());

  }, (error, stack) {
    if (!kDebugMode) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    } else {
      debugPrint('❌ Unhandled error: $error');
      debugPrint('Stack: $stack');
    }
  });
}

class GymTrackerProApp extends StatelessWidget {
  const GymTrackerProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => GamificationProvider()),
      ],
      child: MaterialApp(
        title:                     'AI Trainer',
        debugShowCheckedModeBanner: false,
        theme:                     AppTheme.dark,
        home:                      const SplashScreen(),
      ),
    );
  }
}
