// lib/providers/coach_provider.dart
// ══════════════════════════════════════════════════════════
// Owns: AI daily message, suggestions, coaching insights
// REPLACES: ai_trainer.dart (deleted — was fake string matching)
// USES: GeminiService for real LLM-backed coaching
// Cached: 1 per day — no repeated API calls
// ══════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/gemini_service.dart';
import '../models/models.dart';
import '../models/workout_log.dart';
import 'workout_provider.dart';
import 'analytics_provider.dart';

// ─────────────────────────────────────────────────────────
// COACH INSIGHT — daily cached response
// ─────────────────────────────────────────────────────────
class CoachInsight {
  final String dailyMessage;       // Main motivational message
  final String suggestion;         // Specific actionable suggestion
  final String warning;            // e.g. "Overtraining risk detected"
  final String weakMuscleAlert;    // e.g. "Back needs attention"
  final String progressNote;       // e.g. "Bench up 5% this week"
  final String cacheDate;

  const CoachInsight({
    required this.dailyMessage,
    required this.suggestion,
    required this.warning,
    required this.weakMuscleAlert,
    required this.progressNote,
    required this.cacheDate,
  });

  factory CoachInsight.loading() => const CoachInsight(
    dailyMessage:   '💪 Loading your AI coach...',
    suggestion:     '',
    warning:        '',
    weakMuscleAlert:'',
    progressNote:   '',
    cacheDate:      '',
  );

  factory CoachInsight.fallback({required String userName}) => CoachInsight(
    dailyMessage:   '🔥 Let\'s make today count, $userName!',
    suggestion:     'Focus on progressive overload — add 2.5kg where you can.',
    warning:        '',
    weakMuscleAlert:'',
    progressNote:   '',
    cacheDate:      _todayStatic,
  );

  factory CoachInsight.fromJson(Map<String, dynamic> j) => CoachInsight(
    dailyMessage:    j['dailyMessage']    as String? ?? '',
    suggestion:      j['suggestion']      as String? ?? '',
    warning:         j['warning']         as String? ?? '',
    weakMuscleAlert: j['weakMuscleAlert'] as String? ?? '',
    progressNote:    j['progressNote']    as String? ?? '',
    cacheDate:       j['cacheDate']       as String? ?? '',
  );

  Map<String, dynamic> toJson() => {
    'dailyMessage':    dailyMessage,
    'suggestion':      suggestion,
    'warning':         warning,
    'weakMuscleAlert': weakMuscleAlert,
    'progressNote':    progressNote,
    'cacheDate':       cacheDate,
  };

  static String get _todayStatic {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2,'0')}-${n.day.toString().padLeft(2,'0')}';
  }
}

// ─────────────────────────────────────────────────────────
// COACH PROVIDER
// ─────────────────────────────────────────────────────────
class CoachProvider extends ChangeNotifier {
  final WorkoutProvider   _workout;
  final AnalyticsProvider _analytics;
  final GeminiService     _gemini;
  final UserProfile       profile;

  static const _keyCacheInsight = 'coach_insight_cache_v2';

  CoachProvider({
    required WorkoutProvider   workout,
    required AnalyticsProvider analytics,
    required GeminiService     gemini,
    required this.profile,
  })  : _workout   = workout,
        _analytics = analytics,
        _gemini    = gemini;

  // ── State ──────────────────────────────────────────────
  CoachInsight _insight   = CoachInsight.loading();
  bool         _fetching  = false;
  bool         _hasFetched = false;

  // ── Getters ────────────────────────────────────────────
  CoachInsight get insight      => _insight;
  bool         get isFetching   => _fetching;
  String       get dailyMessage => _insight.dailyMessage;
  String       get suggestion   => _insight.suggestion;
  String       get warning      => _insight.warning;

  // ─────────────────────────────────────────────────────────
  // INIT — load cache, fetch if stale
  // ─────────────────────────────────────────────────────────
  Future<void> init() async {
    await _loadCache();
    if (_insight.cacheDate != _todayStr) {
      await fetchInsight();
    }
  }

  Future<void> _loadCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw   = prefs.getString(_keyCacheInsight);
      if (raw == null) return;
      final cached = CoachInsight.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      if (cached.cacheDate == _todayStr) {
        _insight = cached;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('CoachProvider._loadCache error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────
  // FETCH INSIGHT — from Gemini, cached per day
  // This REPLACES AITrainer.getTodaySuggestion() which was fake
  // ─────────────────────────────────────────────────────────
  Future<void> fetchInsight() async {
    if (_fetching) return;
    _fetching = true;
    notifyListeners();

    try {
      final insight = await _buildInsightFromGemini();
      _insight  = insight;
      _fetching = false;
      await _saveCache(insight);
    } catch (e) {
      debugPrint('CoachProvider.fetchInsight error: $e');
      _insight  = CoachInsight.fallback(userName: profile.name);
      _fetching = false;
    }

    _hasFetched = true;
    notifyListeners();
  }

  Future<CoachInsight> _buildInsightFromGemini() async {
    final logs     = _workout.logs;
    final weakest  = _workout.weakestMuscle;
    final skipped  = _workout.musclesSkippedLastWeek;
    final fatigue  = _analytics.fatigueIndex;
    final readiness= _analytics.readinessScore;
    final plateau  = _analytics.isOnPlateau;
    final deload   = _analytics.needsDeload;

    // Build a rich coaching prompt — not just "what workout today"
    final prompt = '''
You are an elite personal trainer AI. Give a SHORT daily coaching message (2-3 sentences max each field).

User context:
- Name: ${profile.name}
- Goal: ${profile.goal.replaceAll('_', ' ')}
- Level: ${profile.level}
- Total workouts: ${_workout.logs.length}
- Fatigue index: ${fatigue.toStringAsFixed(0)}/100 ${fatigue > 70 ? "(HIGH)" : fatigue > 40 ? "(MODERATE)" : "(LOW)"}
- Readiness: ${readiness.toStringAsFixed(0)}/100
- Plateau detected: $plateau
- Needs deload: $deload
- Weakest muscle: ${weakest.isEmpty ? 'none' : weakest}
- Muscles skipped this week: ${skipped.isEmpty ? 'none' : skipped.join(', ')}
- Weekly volume change: ${_analytics.state.weeklyImprovement.toStringAsFixed(0)}%

Return ONLY JSON (no markdown):
{
  "dailyMessage": "Motivational but specific message referencing their actual data",
  "suggestion": "ONE specific actionable thing they should do today",
  "warning": "Empty string if no warning, else a specific health/overtraining warning",
  "weakMuscleAlert": "Empty string if fine, else specific weak muscle recommendation",
  "progressNote": "One positive observation about their recent progress (or empty)"
}
''';

    final response = await _gemini.generateCoachMessage(prompt: prompt);
    return _parseCoachResponse(response);
  }

  CoachInsight _parseCoachResponse(String raw) {
    try {
      String clean = raw
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();
      final start = clean.indexOf('{');
      final end   = clean.lastIndexOf('}');
      if (start == -1 || end == -1) throw const FormatException('No JSON found');
      clean = clean.substring(start, end + 1);
      final j = jsonDecode(clean) as Map<String, dynamic>;
      return CoachInsight(
        dailyMessage:    (j['dailyMessage']    as String? ?? '').trim(),
        suggestion:      (j['suggestion']      as String? ?? '').trim(),
        warning:         (j['warning']         as String? ?? '').trim(),
        weakMuscleAlert: (j['weakMuscleAlert'] as String? ?? '').trim(),
        progressNote:    (j['progressNote']    as String? ?? '').trim(),
        cacheDate:       _todayStr,
      );
    } catch (e) {
      debugPrint('CoachProvider._parseCoachResponse error: $e (raw: $raw)');
      return CoachInsight.fallback(userName: profile.name);
    }
  }

  Future<void> _saveCache(CoachInsight insight) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyCacheInsight, jsonEncode(insight.toJson()));
    } catch (e) {
      debugPrint('CoachProvider._saveCache error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────
  // FORCE REFRESH — user pulls to refresh
  // ─────────────────────────────────────────────────────────
  Future<void> refresh() async {
    _insight = CoachInsight.loading();
    notifyListeners();
    await fetchInsight();
  }

  String get _todayStr {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2,'0')}-${n.day.toString().padLeft(2,'0')}';
  }
}
