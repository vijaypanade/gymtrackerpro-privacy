// lib/providers/analytics_provider.dart
// ══════════════════════════════════════════════════════════
// Owns: fatigue, readiness, plateau, strength curves, consistency
// Depends on: WorkoutProvider (reads logs, not writes)
// NEW: e1RM per exercise, volume per muscle per week, consistency score
// ══════════════════════════════════════════════════════════

import 'package:flutter/foundation.dart';
import '../models/models.dart';
import '../models/workout_log.dart';
import '../engines/analytics_engine.dart';
import 'workout_provider.dart';

// ─────────────────────────────────────────────────────────
// STRENGTH DATA POINT — for trend charts
// ─────────────────────────────────────────────────────────
class StrengthPoint {
  final DateTime date;
  final double   weight;
  final int      reps;
  final double   e1rm; // estimated 1RM via Epley

  const StrengthPoint({
    required this.date,
    required this.weight,
    required this.reps,
    required this.e1rm,
  });
}

// ─────────────────────────────────────────────────────────
// MUSCLE VOLUME — sets + kg per muscle this week
// ─────────────────────────────────────────────────────────
class MuscleVolume {
  final String muscle;
  final int    setsThisWeek;
  final double kgThisWeek;
  final int    recommendedSets; // science-based minimum effective volume

  const MuscleVolume({
    required this.muscle,
    required this.setsThisWeek,
    required this.kgThisWeek,
    required this.recommendedSets,
  });

  /// Are they training enough of this muscle?
  bool get isSufficient => setsThisWeek >= recommendedSets;

  String get statusEmoji {
    if (setsThisWeek == 0)              return '❌';
    if (setsThisWeek < recommendedSets) return '⚠️';
    return '✅';
  }
}

// ─────────────────────────────────────────────────────────
// ANALYTICS SNAPSHOT — cached to avoid recomputing
// ─────────────────────────────────────────────────────────
class AnalyticsState {
  final double fatigueIndex;      // 0-100 (higher = more fatigued)
  final double readinessScore;    // 0-100 (higher = more ready)
  final double plateauRisk;       // 0-100 (higher = closer to plateau)
  final double weeklyImprovement; // % change vs last week volume
  final String muscleImbalance;   // human-readable imbalance warning
  final String cacheDate;

  const AnalyticsState({
    required this.fatigueIndex,
    required this.readinessScore,
    required this.plateauRisk,
    required this.weeklyImprovement,
    required this.muscleImbalance,
    required this.cacheDate,
  });

  factory AnalyticsState.empty() => AnalyticsState(
    fatigueIndex:      0,
    readinessScore:    85,
    plateauRisk:       0,
    weeklyImprovement: 0,
    muscleImbalance:   'Start training to see insights',
    cacheDate:         '',
  );
}

// ─────────────────────────────────────────────────────────
// ANALYTICS PROVIDER
// ─────────────────────────────────────────────────────────
class AnalyticsProvider extends ChangeNotifier {
  final WorkoutProvider _workout;

  AnalyticsProvider(this._workout) {
    // Recompute when workout data changes
    _workout.addListener(_invalidate);
  }

  AnalyticsState  _state      = AnalyticsState.empty();
  String          _cacheDate  = '';

  // Science-based minimum effective volume (sets/week per muscle)
  static const Map<String, int> _minSets = {
    'chest':     10,
    'back':      12,
    'legs':      14,
    'shoulders':  8,
    'arms':       8,
    'core':       8,
  };

  // ── Getters ────────────────────────────────────────────
  AnalyticsState  get state          => _freshState();
  double          get fatigueIndex   => state.fatigueIndex;
  double          get readinessScore => state.readinessScore;
  double          get plateauRisk    => state.plateauRisk;
  bool            get needsDeload    =>
      fatigueIndex > 70 || (plateauRisk > 65 && state.weeklyImprovement < -5);
  bool            get isOnPlateau    => plateauRisk > 60;

  // ─────────────────────────────────────────────────────────
  // COMPUTE — lazy, cached per day
  // ─────────────────────────────────────────────────────────
  AnalyticsState _freshState() {
    final today = _todayStr;
    if (_state.cacheDate == today && _state != AnalyticsState.empty()) {
      return _state;
    }

    final logs  = _workout.logs;
    final mood  = MoodType.normal; // passed in from app state
    final streak = 0; // from streak provider

    _state = AnalyticsState(
      fatigueIndex:      AnalyticsEngine.computeFatigueIndex(
                             logs: logs, mood: mood, streak: streak),
      readinessScore:    AnalyticsEngine.computeReadiness(
                             recovery: _overallRecovery(logs),
                             fatigue:  AnalyticsEngine.computeFatigueIndex(
                                          logs: logs, mood: mood, streak: streak),
                             streak:   streak,
                             mood:     mood.name,
                             needsDeload: false),
      plateauRisk:       AnalyticsEngine.computePlateauScore(logs: logs),
      weeklyImprovement: AnalyticsEngine.computeWeeklyImprovement(logs: logs),
      muscleImbalance:   AnalyticsEngine.getMuscleImbalance(logs),
      cacheDate:         today,
    );
    return _state;
  }

  void _invalidate() {
    _cacheDate = '';
    _state = AnalyticsState.empty();
    notifyListeners();
  }

  // ─────────────────────────────────────────────────────────
  // STRENGTH PROGRESSION CURVE — per exercise (NEW)
  // Used by Stats screen strength trend chart
  // ─────────────────────────────────────────────────────────
  List<StrengthPoint> strengthProgression(String exerciseKey) {
    final logs = _workout.logs
        .where((l) => l.exercise == exerciseKey && l.weight > 0)
        .toList()
      ..sort((a, b) => a.date.compareTo(b.date));

    return logs.map((l) => StrengthPoint(
      date:   l.date,
      weight: l.weight,
      reps:   l.reps,
      e1rm:   _epleyE1RM(l.weight, l.reps),
    )).toList();
  }

  /// Epley formula for estimated 1RM
  static double _epleyE1RM(double weight, int reps) {
    if (reps <= 0 || weight <= 0) return 0;
    if (reps == 1) return weight;
    return weight * (1 + reps / 30.0);
  }

  double estimatedE1RM(String exerciseKey) {
    return _workout.estimatedE1RM(exerciseKey);
  }

  // ─────────────────────────────────────────────────────────
  // VOLUME PER MUSCLE PER WEEK — NEW
  // ─────────────────────────────────────────────────────────
  List<MuscleVolume> get weeklyMuscleVolumes {
    final setsMap   = _workout.setsPerMuscleThisWeek;
    final volumeMap = _workout.weeklyVolumeByMuscle;
    const muscles   = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];

    return muscles.map((m) => MuscleVolume(
      muscle:           m,
      setsThisWeek:     setsMap[m]   ?? 0,
      kgThisWeek:       volumeMap[m] ?? 0,
      recommendedSets:  _minSets[m]  ?? 8,
    )).toList();
  }

  // ─────────────────────────────────────────────────────────
  // CONSISTENCY SCORE — NEW
  // ─────────────────────────────────────────────────────────
  /// Workouts completed / workouts planned last 4 weeks
  double consistencyScore(List<Map<String, dynamic>> historyLast4Weeks) {
    if (historyLast4Weeks.isEmpty) return 0;
    final planned   = historyLast4Weeks.length;
    final completed = historyLast4Weeks.where((w) {
      return (w['completed'] as bool?) ?? false;
    }).length;
    return completed / planned;
  }

  // ─────────────────────────────────────────────────────────
  // MUSCLE RECOVERY — how recovered each muscle is
  // ─────────────────────────────────────────────────────────
  Map<String, int> get muscleRecoveryScores {
    const recoveryHours = {
      'legs': 72, 'back': 48, 'chest': 48,
      'shoulders': 48, 'arms': 36, 'core': 24,
    };

    final lastTrained = _workout.lastTrainedByMuscle;
    final scores = <String, int>{};
    final now     = DateTime.now();

    for (final entry in recoveryHours.entries) {
      final muscle  = entry.key;
      final hours   = entry.value;
      final last    = lastTrained[muscle];

      if (last == null) {
        scores[muscle] = 100; // never trained → fully recovered
        continue;
      }

      final elapsed = now.difference(last).inHours;
      scores[muscle] = ((elapsed / hours) * 100).clamp(0, 100).round();
    }

    return scores;
  }

  double _overallRecovery(List<WorkoutLog> logs) {
    final scores = muscleRecoveryScores;
    if (scores.isEmpty) return 100;
    return scores.values.fold(0.0, (s, v) => s + v) / scores.length;
  }

  String get _todayStr {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2,'0')}-${n.day.toString().padLeft(2,'0')}';
  }

  @override
  void dispose() {
    _workout.removeListener(_invalidate);
    super.dispose();
  }
}
