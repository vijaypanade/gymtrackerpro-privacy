// lib/providers/app_provider.dart — v7.2 Elite Engine
// Readiness Score · Fatigue Index · Plateau Detection · Adaptive Coach
// Gamification Events · Advanced Analytics · Premium Gating
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/models.dart';
import '../models/workout_log.dart';
import '../services/ai_engine.dart';
import '../engines/analytics_engine.dart';
import '../services/gemini_service.dart';
import '../services/monetization_service.dart'; // ✅ Revenue logic

// ═══════════════════════════════════════════════════════════════
// STORAGE KEYS
// ═══════════════════════════════════════════════════════════════
class _Keys {
  static const weekPlan          = 'week_plan_v4';
  static const profile           = 'user_profile_v4';
  static const streak            = 'streak_data_v4';
  static const history           = 'history_v4';
  static const favorites         = 'favorites_v4';
  static const settings          = 'settings_v4';
  static const waterDate         = 'last_water_date_v4';
  static const logs              = 'workout_logs_v4';
  static const measurements      = 'body_measurements_v2';
  static const mood              = 'today_mood_v2';
  static const aiCache           = 'ai_coach_cache_v1';
  static const lastMuscleTrained = 'last_muscle_trained_v1';
  static const performanceMemory = 'perf_memory_v1';
  static const weeklyMemory      = 'weekly_memory_v1';  // ✅ NEW: weekly periodization memory

  static const hiveWorkout  = 'workoutBox';
  static const hiveLogs     = 'logsBox';
  static const hiveSettings = 'settingsBox';
  static const hiveWeekPlan = 'weekPlan';

  static const Map<String, int> muscleRecoveryHours = {
    'legs': 72, 'back': 48, 'chest': 48,
    'shoulders': 48, 'arms': 36, 'core': 24,
  };
}

// ═══════════════════════════════════════════════════════════════
// GAMIFICATION EVENTS — returned by hooks, no UI/storage here
// ═══════════════════════════════════════════════════════════════
enum XPEventType {
  workoutComplete,
  prBroken,
  streakMilestone,
  streakDay,
  deloadComplete,
  perfectWeek,
}

class XPEvent {
  final XPEventType type;
  final int         xp;
  final String      label;
  final String?     achievementId;

  const XPEvent({
    required this.type,
    required this.xp,
    required this.label,
    this.achievementId,
  });

  @override
  String toString() => 'XPEvent(${type.name}, +$xp XP, "$label")';
}
// ═══════════════════════════════════════════════
// PR RESULT — structured PR outcome
// ═══════════════════════════════════════════════
enum PROutcome { pr, match, drop, first }

class PRResult {
  final PROutcome outcome;
  final double    newWeight;
  final int       newReps;
  final double    prevWeight;
  final int       prevReps;
  final double    improvePct; // % improvement

  const PRResult({
    required this.outcome,
    required this.newWeight,
    required this.newReps,
    required this.prevWeight,
    required this.prevReps,
    required this.improvePct,
  });

  bool get isPR    => outcome == PROutcome.pr || outcome == PROutcome.first;
  bool get isMatch => outcome == PROutcome.match;
  bool get isDrop  => outcome == PROutcome.drop;
  bool get isFirst => outcome == PROutcome.first;

  String get uxMessage {
    switch (outcome) {
      case PROutcome.first:  return '🎉 First rep logged! Every journey starts here.';
      case PROutcome.pr:     return '🔥 You\'re getting stronger!';
      case PROutcome.match:  return '💪 Consistency builds strength. Keep pushing.';
      case PROutcome.drop:   return '📈 Recovery matters — come back stronger.';
    }
  }

  String get improvementStr {
    if (outcome == PROutcome.first) return '🎉 First ever!';
    if (improvePct == 0) return 'No change 🔁';
    if (improvePct > 0) return '+${improvePct.toStringAsFixed(1)}% 🔥';
    return '${improvePct.toStringAsFixed(1)}%';
  }
}

// Structured achievement event — UI renders this
class AchievementEvent {
  final String id;
  final String title;
  final String description;
  final String emoji;
  final int    bonusXP;
  final String triggerCondition;

  const AchievementEvent({
    required this.id, required this.title, required this.description,
    required this.emoji, required this.bonusXP, required this.triggerCondition,
  });

  @override
  String toString() => 'Achievement($id: "$title")';
}

// Streak risk detection result
class StreakRiskResult {
  final bool   atRisk;
  final String message;
  final int    hoursLeft; // until midnight

  const StreakRiskResult({
    required this.atRisk, required this.message, required this.hoursLeft,
  });
}

// Time-of-day context for micro-intelligence
enum TimeContext { earlyMorning, morning, afternoon, evening, lateNight }

extension TimeContextX on TimeContext {
  String get label {
    switch (this) {
      case TimeContext.earlyMorning: return 'early morning';
      case TimeContext.morning:      return 'morning';
      case TimeContext.afternoon:    return 'afternoon';
      case TimeContext.evening:      return 'evening';
      case TimeContext.lateNight:    return 'late night';
    }
  }
}

class StreakMilestone {
  final int    days;
  final String label;
  final String emoji;
  final int    bonusXP;

  const StreakMilestone({
    required this.days, required this.label,
    required this.emoji, required this.bonusXP,
  });
}

// ═══════════════════════════════════════════════════════════════
// PERFORMANCE PATTERN — AI memory unit
// ═══════════════════════════════════════════════════════════════
class PerformancePattern {
  final String       date;
  final double       volume;
  final int          setsCompleted;
  final int          setsPlanned;
  final double       effortScore;     // 0–100
  final String       mood;
  final bool         wasFailedSession; // true if effort < 40%
  final List<String> musclesTrained;  // which muscles hit this session
  final String       bestExercise;    // highest volume exercise this session

  const PerformancePattern({
    required this.date,
    required this.volume,
    required this.setsCompleted,
    required this.setsPlanned,
    required this.effortScore,
    required this.mood,
    this.wasFailedSession = false,
    this.musclesTrained   = const [],
    this.bestExercise     = '',
  });

  Map<String, dynamic> toJson() => {
    'date':             date,
    'volume':           volume,
    'setsCompleted':    setsCompleted,
    'setsPlanned':      setsPlanned,
    'effortScore':      effortScore,
    'mood':             mood,
    'wasFailedSession': wasFailedSession,
    'musclesTrained':   musclesTrained,
    'bestExercise':     bestExercise,
  };

  factory PerformancePattern.fromJson(Map<String, dynamic> j) =>
      PerformancePattern(
        date:             j['date']             as String? ?? '',
        volume:           (j['volume']           as num?)?.toDouble() ?? 0,
        setsCompleted:    j['setsCompleted']     as int?    ?? 0,
        setsPlanned:      j['setsPlanned']       as int?    ?? 0,
        effortScore:      (j['effortScore']      as num?)?.toDouble() ?? 0,
        mood:             j['mood']              as String? ?? 'normal',
        wasFailedSession: j['wasFailedSession']  as bool?   ?? false,
        musclesTrained:   (j['musclesTrained']   as List?)?.cast<String>() ?? [],
        bestExercise:     j['bestExercise']      as String? ?? '',
      );
}

// ═══════════════════════════════════════════════════════════════
// ANALYTICS SNAPSHOT — cached, not recomputed every frame
// ═══════════════════════════════════════════════════════════════
class AnalyticsSnapshot {
  final double readinessScore;     // 0–100
  final double fatigueIndex;       // 0–100
  final double effortScoreToday;   // 0–100
  final double plateauScore;       // 0–100
  final double overtTrainingRisk;  // 0–100
  final double weeklyImprovementPct;
  final double muscleBalanceScore; // 0–100 (higher = more balanced)
  final double intensityScore;     // 0–100
  final String recoveryTrend;      // 'improving' | 'stable' | 'declining'
  final bool   isOnPlateau;
  final String cacheDate;

  const AnalyticsSnapshot({
    required this.readinessScore,
    required this.fatigueIndex,
    required this.effortScoreToday,
    required this.plateauScore,
    required this.overtTrainingRisk,
    required this.weeklyImprovementPct,
    required this.muscleBalanceScore,
    required this.intensityScore,
    required this.recoveryTrend,
    required this.isOnPlateau,
    required this.cacheDate,
  });

  Map<String, dynamic> toJson() => {
    'readinessScore': readinessScore, 'fatigueIndex': fatigueIndex,
    'effortScoreToday': effortScoreToday, 'plateauScore': plateauScore,
    'overtTrainingRisk': overtTrainingRisk,
    'weeklyImprovementPct': weeklyImprovementPct,
    'muscleBalanceScore': muscleBalanceScore, 'intensityScore': intensityScore,
    'recoveryTrend': recoveryTrend, 'isOnPlateau': isOnPlateau,
    'cacheDate': cacheDate,
  };

  factory AnalyticsSnapshot.fromJson(Map<String, dynamic> j) =>
      AnalyticsSnapshot(
        readinessScore:       (j['readinessScore']       as num?)?.toDouble() ?? 70,
        fatigueIndex:         (j['fatigueIndex']         as num?)?.toDouble() ?? 30,
        effortScoreToday:     (j['effortScoreToday']     as num?)?.toDouble() ?? 50,
        plateauScore:         (j['plateauScore']         as num?)?.toDouble() ?? 0,
        overtTrainingRisk:    (j['overtTrainingRisk']    as num?)?.toDouble() ?? 0,
        weeklyImprovementPct: (j['weeklyImprovementPct'] as num?)?.toDouble() ?? 0,
        muscleBalanceScore:   (j['muscleBalanceScore']   as num?)?.toDouble() ?? 70,
        intensityScore:       (j['intensityScore']       as num?)?.toDouble() ?? 60,
        recoveryTrend:         j['recoveryTrend']         as String? ?? 'stable',
        isOnPlateau:           j['isOnPlateau']           as bool?   ?? false,
        cacheDate:             j['cacheDate']             as String? ?? '',
      );

  static AnalyticsSnapshot get empty => AnalyticsSnapshot(
    readinessScore: 72, fatigueIndex: 28, effortScoreToday: 55,
    plateauScore: 0, overtTrainingRisk: 0, weeklyImprovementPct: 0,
    muscleBalanceScore: 74, intensityScore: 60,
    recoveryTrend: 'stable', isOnPlateau: false, cacheDate: '',
  );
}

// ═══════════════════════════════════════════════════════════════
// PROGRESSION RESULT
// ═══════════════════════════════════════════════════════════════
class ProgressionResult {
  final String message;
  final double nextWeight;
  final int    targetReps;

  const ProgressionResult({
    required this.message,
    required this.nextWeight,
    required this.targetReps,
  });
}

// ═══════════════════════════════════════════════════════════════
// AI COACH INSIGHT — daily cache
// ═══════════════════════════════════════════════════════════════
enum FatigueLevel    { fresh, normal, fatigued }
enum WeightSuggestion { increase, decrease, maintain }

class AICoachInsight {
  final FatigueLevel     fatigueLevel;
  final String           fatigueMessage;
  final WeightSuggestion weightSuggestion;
  final String           weightMessage;
  final String           weakMuscleGroup;
  final String           dailyCoachMessage;
  final int              recommendedSets;
  final double           weightModifier;
  final String           cacheDate;

  const AICoachInsight({
    required this.fatigueLevel,    required this.fatigueMessage,
    required this.weightSuggestion, required this.weightMessage,
    required this.weakMuscleGroup, required this.dailyCoachMessage,
    required this.recommendedSets, required this.weightModifier,
    required this.cacheDate,
  });

  Map<String, dynamic> toJson() => {
    'fatigueLevel': fatigueLevel.name, 'fatigueMessage': fatigueMessage,
    'weightSuggestion': weightSuggestion.name, 'weightMessage': weightMessage,
    'weakMuscleGroup': weakMuscleGroup, 'dailyCoachMessage': dailyCoachMessage,
    'recommendedSets': recommendedSets, 'weightModifier': weightModifier,
    'cacheDate': cacheDate,
  };

  factory AICoachInsight.fromJson(Map<String, dynamic> j) => AICoachInsight(
    fatigueLevel:      FatigueLevel.values.firstWhere(
        (e) => e.name == (j['fatigueLevel'] ?? 'normal'),
        orElse: () => FatigueLevel.normal),
    fatigueMessage:    j['fatigueMessage']    as String? ?? '',
    weightSuggestion:  WeightSuggestion.values.firstWhere(
        (e) => e.name == (j['weightSuggestion'] ?? 'maintain'),
        orElse: () => WeightSuggestion.maintain),
    weightMessage:     j['weightMessage']     as String? ?? '',
    weakMuscleGroup:   j['weakMuscleGroup']   as String? ?? '',
    dailyCoachMessage: j['dailyCoachMessage'] as String? ?? '',
    recommendedSets:   j['recommendedSets']   as int?    ?? 4,
    weightModifier:    (j['weightModifier']   as num?)?.toDouble() ?? 1.0,
    cacheDate:         j['cacheDate']         as String? ?? '',
  );

  static AICoachInsight get defaultInsight => const AICoachInsight(
    fatigueLevel: FatigueLevel.fresh,
    fatigueMessage: '✅ Fully recovered — optimal performance today!',
    weightSuggestion: WeightSuggestion.maintain,
    weightMessage: '🎯 Focus on form today — build your foundation.',
    weakMuscleGroup: '', recommendedSets: 4, weightModifier: 1.0,
    dailyCoachMessage: '🚀 Day 1 — The hardest part is starting. You did it!',
    cacheDate: '',
  );
}

// ═══════════════════════════════════════════════════════════════
// APP PROVIDER — Elite Engine
// ═══════════════════════════════════════════════════════════════
class AppProvider extends ChangeNotifier {
Map<String, dynamic>? weeklyPlan;
  Box? _workoutBox;
  Box? _logsBox;
  Box? _settingsBox;

  final Uuid   _uuid   = const Uuid();
  final Random _random = Random();

  bool _loading    = true;
  bool _isBatching = false;
  int  _refreshTrigger = 0;

  // ── Core state ──
  List<DayPlan>         _weekPlan          = [];
  List<WorkoutLog>      _logs              = [];
  UserProfile           _profile           = UserProfile();
  StreakData             _streak            = StreakData();
  List<HistoryEntry>    _history           = [];
  Set<String>           _favorites         = {};
  List<BodyMeasurement> _measurements      = [];
  MoodType              _todayMood         = MoodType.normal;
  bool                  showStreakPopup     = false;

  // ── AI Memory — last 10 performance patterns ──
  List<PerformancePattern> _perfMemory     = [];

  // ── Muscle recovery tracking ──
  Map<String, DateTime> _lastMuscleTrained = {};

  // ── AI + Analytics cache ──
  AICoachInsight?    _aiInsight;
  AnalyticsSnapshot? _analyticsSnapshot;
  String?            _cachedCoachMessage;
  int?               _cachedRecoveryScore;
  bool?              _cachedIsFatigued;

  // ── EMA score smoothing (prevents jumpy numbers) ──
  double? _smoothedReadiness;
  double? _smoothedFatigue;
  double? _smoothedIntensity;
  static const double _emaAlpha = 0.3; // smoothing factor 0–1 (lower = smoother)

  // ── Near-miss PR tracking (per exercise) ──
  // Maps exerciseKey → {weight, reps, date} of session closest to PR
  Map<String, Map<String, dynamic>> _nearMissCache = {};
Map<String, double> _muscleLoad = {};

  // ── Paywall trigger — set after key events, read by UI ──────
  PaywallTrigger? _pendingPaywallTrigger;
  PaywallTrigger? get pendingPaywallTrigger => _pendingPaywallTrigger;
  void clearPaywallTrigger() {
    _pendingPaywallTrigger = null;
    notifyListeners();
  }

  // ── Weekly Memory — Option B periodization ──────────────────
  WeeklyMemory? _lastWeekMemory;
  // ── Settings ──
  Map<String, dynamic> _settings = {
    'workoutReminderEnabled': false,
    'waterReminderEnabled':   false,
    'notificationsEnabled':   true,
    'waterReminderInterval':  60,
  };

  // isPremium removed — use MonetizationService.instance.isPremium

  // ── Monetization — delegate to MonetizationService ──────────
  // MonetizationService is the single source of truth for premium state,
  // AI usage counts, and ad frequency caps.
  bool get isPremium  => MonetizationService.instance.isPremium;
  bool canUseAI()     => MonetizationService.instance.canUseAI;
  int  get aiUsesRemaining => MonetizationService.instance.aiUsesRemaining;

  static const int _maxLogs    = 500;
  static const int _maxMemory  = 10;  // AI memory window

  // ── Streak milestones ──
  static const List<StreakMilestone> streakMilestones = [
    StreakMilestone(days: 7,  label: 'First Week',  emoji: '🔥', bonusXP: 100),
    StreakMilestone(days: 14, label: 'Two Weeks',   emoji: '⚡', bonusXP: 150),
    StreakMilestone(days: 30, label: 'Iron Month',  emoji: '🛡️', bonusXP: 300),
    StreakMilestone(days: 60, label: 'Legend Mode', emoji: '👑', bonusXP: 600),
  ];

AppProvider() { 
  // key debug removed
  _initHiveBoxes(); 
}

  int get refreshTrigger => _refreshTrigger;
/// Called by OnboardingScreen after user completes setup
Future<void> completeOnboarding() async {
  try {
    final p = await SharedPreferences.getInstance();
    await p.setBool('onboarding_done', true);
  } catch (e) { debugPrint('completeOnboarding: $e'); }
}

/// Check if onboarding was completed
Future<bool> isOnboardingComplete() async {
  try {
    final p = await SharedPreferences.getInstance();
    return p.getBool('onboarding_done') ?? false;
  } catch (_) { return false; }
}
// ✅ SECURITY FIX: API key via --dart-define=GEMINI_KEY=your_key_here
// Never commit a real key to source control — APKs can be decompiled.
// Build command: flutter run --dart-define=GEMINI_KEY=AIzaSy...
final GeminiService _geminiService = GeminiService(
  String.fromEnvironment('GEMINI_KEY'),
);
  // ═══════════════════════════════════════════════════════════
  // INIT
  // ═══════════════════════════════════════════════════════════
  void _initHiveBoxes() {
    try {
      if (Hive.isBoxOpen(_Keys.hiveWorkout))  _workoutBox  = Hive.box(_Keys.hiveWorkout);
      if (Hive.isBoxOpen(_Keys.hiveLogs))     _logsBox     = Hive.box(_Keys.hiveLogs);
      if (Hive.isBoxOpen(_Keys.hiveSettings)) _settingsBox = Hive.box(_Keys.hiveSettings);
    } catch (e) { debugPrint('Hive init: $e'); }
    _init();
  }
/// Applies an AI-generated plan to the week planner.
/// Routes through applyPlanToWeek which handles type safety + persistence.
Future<void> applyAIWorkout(Map<String, dynamic> plan) async {
  try {
    applyPlanToWeek(plan);
    await _saveWeekPlan(); // ✅ ensure save before app kill
  } catch (e) {
    debugPrint('applyAIWorkout error: $e');
    notifyListeners();
  }
}

void applyPlanToWeek(Map<String, dynamic> plan) {
  final rawDays = plan['days'];
  if (rawDays == null || rawDays is! List || rawDays.isEmpty) {
    debugPrint('applyPlanToWeek: invalid plan structure');
    return;
  }

  // ✅ FIX: Build new plan list — don't reuse _weekPlan reference
  final newPlan = <DayPlan>[];

  for (int i = 0; i < rawDays.length && i < 7; i++) {
    final d = rawDays[i];
    if (d is! Map) continue;

    final exercises = ((d['exercises'] as List?) ?? []).map<PlannedExercise?>((e) {
      if (e is! Map) return null;
      final name     = (e['name'] as String?)?.trim() ?? 'Exercise';
      if (name.isEmpty) return null;

      final rawSets  = e['sets'];
      final setCount = (rawSets is int ? rawSets : int.tryParse(rawSets?.toString() ?? '') ?? 3).clamp(1, 6);

      final rawReps  = e['reps'];
      int reps = 10;
      if (rawReps is int) {
        reps = rawReps;
      } else if (rawReps is String) {
        // Handle "8-12" → take lower bound
        reps = int.tryParse(rawReps.split(RegExp(r'[-–]')).first.trim()) ?? 10;
      }

      return PlannedExercise(
        id:       _uuid.v4(),
        baseId:   name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_'),
        name:     name,
        category: _getCategory(name),
        emoji:    _getEmoji(name),
        sets: List.generate(setCount, (idx) => ExSet(
          id:     _uuid.v4(),
          reps:   reps.clamp(1, 50),
          weight: 0,
          done:   false,
        )),
      );
    }).whereType<PlannedExercise>().toList();

    newPlan.add(DayPlan(
      id:        _uuid.v4(),
      dayIndex:  i,
      title:     (d['focus'] as String?)?.trim() ?? 'Workout',
      exercises: exercises,
      isRestDay: exercises.isEmpty,
    ));
  }

  _weekPlan = newPlan;

  // ✅ Pad to 7 days — _validateAndFixWeekPlan now handles this correctly
  _validateAndFixWeekPlan();
  _saveWeekPlan();

  // ✅ Force full UI rebuild — increment trigger so all consumers re-render
  _refreshTrigger++;
  _invalidateCache();
  notifyListeners();
}
  Future<void> _init() async {
    try {
      // ✅ Init monetization first — premium state needed everywhere
      await MonetizationService.instance.init();

      final prefs   = await SharedPreferences.getInstance();
      _profile      = _decode(prefs, _Keys.profile,      UserProfile.fromJson)  ?? UserProfile();
      _streak       = _decode(prefs, _Keys.streak,       StreakData.fromJson)   ?? StreakData();
      _history      = _decodeList(prefs, _Keys.history,      HistoryEntry.fromJson);
      _logs         = _decodeList(prefs, _Keys.logs,         WorkoutLog.fromJson);
      _measurements = _decodeList(prefs, _Keys.measurements, BodyMeasurement.fromJson);

      _loadLastMuscleTrained(prefs);
      _loadPerformanceMemory(prefs);
      _loadWeeklyMemory(prefs);  // ✅ NEW: load weekly periodization memory

      if (_logs.length > _maxLogs) {
        _logs = _logs.sublist(_logs.length - _maxLogs);
      }

      final fJson = prefs.getString(_Keys.favorites);
      if (fJson != null) {
        try { _favorites = Set<String>.from(jsonDecode(fJson) as List); } catch (_) {}
      }

      final setJson = prefs.getString(_Keys.settings);
      if (setJson != null) {
        try {
          final d = jsonDecode(setJson);
          if (d is Map) _settings = Map<String, dynamic>.from(d);
        } catch (_) {}
      }
      _settings.putIfAbsent('workoutReminderEnabled', () => false);
      _settings.putIfAbsent('waterReminderEnabled',   () => false);
      _settings.putIfAbsent('notificationsEnabled',   () => true);
      _settings.putIfAbsent('waterReminderInterval',  () => 60);

      _loadAICache(prefs);
      _loadAnalyticsCache(prefs);

      _weekPlan = _loadWeekPlan(prefs);
      _validateAndFixWeekPlan();

      if ((prefs.getString(_Keys.waterDate) ?? '') != _todayStr) {
        _profile.currentWaterMl = 0;
        await prefs.setString(_Keys.waterDate, _todayStr);
        _saveProfile();
      }

      final moodStr = prefs.getString(_Keys.mood) ?? 'normal';
      _todayMood = MoodType.values.firstWhere(
          (m) => m.name == moodStr, orElse: () => MoodType.normal);

    } catch (e, s) {
      debugPrint('_init error: $e\n$s');
      _resetToDefaults();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }
Future<void> generateAIWorkout() async {
  // ✅ Use MonetizationService — single source of truth
  if (!canUseAI()) {
    _aiSuggestion = "⚠️ Daily AI limit reached.\nUpgrade for unlimited AI coaching 🔒";
    notifyListeners();
    return;
  }

  try {
    final result = await _geminiService.generateWorkout(
      goal:              _profile.goal.replaceAll('_', ' '),
      experience:        _profile.level,
      daysPerWeek:       _profile.activityLevel == 'Active' ? 5
                       : _profile.activityLevel == 'Very Active' ? 6
                       : 4,
      weakMuscles: [
        if (weakestMuscle.isNotEmpty) weakestMuscle,
        ...musclesSkippedLast7Days.take(2),
      ],
      isOnPlateau:      isOnPlateau,
      needsDeload:      needsDeload,
      isFatigued:       isFatigued,
      performanceTrend: performanceTrend,
      recentWorkouts:   lastWorkoutNames,
      currentStreak:    _streak.currentStreak,
      totalWorkouts:    _streak.totalWorkouts,
      weeklyVolumeTrend: weeklyImprovementPercent,
    );

    // ✅ CORRECT PLACE
    _aiSuggestion = _formatWorkout(result);

    // 🎮 HOOK
    _onAIWorkoutGenerated();

    await MonetizationService.instance.recordAIUse(); // ✅

  } catch (e) {
    // 💪 FALLBACK
    _aiSuggestion = _fallbackWorkout();
  }

  notifyListeners();
}
Future<Map<String, dynamic>> getAIWorkoutPlan() async {
  // Detect missed days
  final missedDays = <String>[];
  const dayNames = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  for (int i = 0; i < _weekPlan.length; i++) {
    final d = _weekPlan[i];
    if (!d.isRestDay && d.exercises.isEmpty) missedDays.add(dayNames[i.clamp(0, 6)]);
  }

  // ── OPTION A: Build exercise history from actual logs ────────
  final exerciseHistory = _buildExerciseHistory();

  // ── OPTION B: Load last week memory ─────────────────────────
  final lastWeek = _lastWeekMemory;

  final result = await _geminiService.generateWorkout(
    goal:              _profile.goal.replaceAll('_', ' '),
    experience:        _profile.level,
    daysPerWeek:       6, // ✅ Always 6-day plan
    weakMuscles: [
      if (weakestMuscle.isNotEmpty) weakestMuscle,
      ...musclesSkippedLast7Days.take(2),
    ],
    isOnPlateau:       isOnPlateau,
    needsDeload:       needsDeload,
    isFatigued:        isFatigued,
    performanceTrend:  performanceTrend,
    missedDays:        missedDays,
    recentWorkouts:    lastWorkoutNames,
    currentStreak:     _streak.currentStreak,
    totalWorkouts:     _streak.totalWorkouts,
    weeklyVolumeTrend: weeklyImprovementPercent,
    // ✅ NEW: actual exercise weights + weekly memory
    exerciseHistory:   exerciseHistory,
    lastWeekMemory:    lastWeek,
  );
  // ✅ Record usage after successful generation
  await MonetizationService.instance.recordAIUse();
  return result;
}

/// OPTION A: Build list of top exercises with their best weight/reps from logs
/// Used to inject real performance data into the AI prompt
List<ExerciseMemory> _buildExerciseHistory() {
  if (_logs.isEmpty) return [];

  // Group logs by exercise, find best performance per exercise
  final Map<String, List<WorkoutLog>> byExercise = {};
  final cutoff = DateTime.now().subtract(const Duration(days: 21)); // last 3 weeks

  for (final log in _logs.where((l) => l.date.isAfter(cutoff))) {
    byExercise.putIfAbsent(log.exercise, () => []).add(log);
  }

  final memories = <ExerciseMemory>[];

  for (final entry in byExercise.entries) {
    final logs = entry.value;
    if (logs.isEmpty) continue;

    // Best weight this period
    logs.sort((a, b) => b.weight.compareTo(a.weight));
    final best = logs.first;

    // Total volume
    final totalVol = logs.fold<double>(
        0, (sum, l) => sum + (l.weight * l.reps));

    // Skip meaningless entries
    if (best.weight == 0 && best.reps == 0) continue;

    final unit = best.weight == 0 ? 'reps' : 'kg';

    memories.add(ExerciseMemory(
      name:        entry.key.replaceAll('_', ' '),
      bestWeight:  best.weight,
      bestReps:    best.reps,
      unit:        unit,
      totalVolume: totalVol,
    ));
  }

  // Sort by total volume — most trained exercises first
  memories.sort((a, b) => b.totalVolume.compareTo(a.totalVolume));

  // Return top 8 exercises (prompt length limit)
  return memories.take(8).toList();
}

/// OPTION B: Save current week as memory when plan is marked complete
/// Called from markDayComplete when all planned days are done
/// Also called manually when user generates next week plan
Future<void> saveCurrentWeekAsMemory() async {
  try {
    final completedDays  = _weekPlan.where((d) => d.isCompleted).length;
    final plannedDays    = _weekPlan.where((d) => !d.isRestDay).length;
    if (completedDays == 0) return; // nothing to save

    final totalVol       = weeklyVolumeTotalKg;
    final avgEffort      = averageEffortScore;

    // Build top exercises from current week plan
    final topExercises   = <ExerciseMemory>[];
    for (final day in _weekPlan.where((d) => d.isCompleted)) {
      for (final ex in day.exercises) {
        final doneSets = ex.sets.where((s) => s.done).toList();
        if (doneSets.isEmpty) continue;
        final best     = doneSets.reduce((a, b) => a.weight >= b.weight ? a : b);
        final vol      = doneSets.fold<double>(0, (s, set) => s + set.weight * set.reps);
        topExercises.add(ExerciseMemory(
          name:        ex.name,
          bestWeight:  best.weight,
          bestReps:    best.reps,
          unit:        ex.unit,
          totalVolume: vol,
        ));
      }
    }

    // Deduplicate — keep highest volume per exercise
    final dedupMap = <String, ExerciseMemory>{};
    for (final e in topExercises) {
      final key = e.name.toLowerCase();
      if (!dedupMap.containsKey(key) ||
          e.totalVolume > dedupMap[key]!.totalVolume) {
        dedupMap[key] = e;
      }
    }

    final currentWeekNum = (_lastWeekMemory?.weekNumber ?? 0) + 1;

    _lastWeekMemory = WeeklyMemory(
      weekNumber:     currentWeekNum,
      weekStartDate:  _todayStr,
      planName:       _weekPlan.firstWhere(
          (d) => !d.isRestDay && d.exercises.isNotEmpty,
          orElse: () => _weekPlan.first).title,
      totalVolume:    totalVol,
      avgEffortScore: avgEffort,
      completedDays:  completedDays,
      plannedDays:    plannedDays,
      wasDeload:      needsDeloadByVolume,
      topExercises:   (dedupMap.values.toList()
            ..sort((a, b) => b.totalVolume.compareTo(a.totalVolume)))
          .take(6)
          .toList(),
    );

    await _saveToPrefs(
      _Keys.weeklyMemory,
      jsonEncode(_lastWeekMemory!.toJson()),
    );

    debugPrint('✅ Weekly memory saved: Week $currentWeekNum, '
        '${_lastWeekMemory!.completedDays} days, '
        '${totalVol.toStringAsFixed(0)}kg volume');
  } catch (e) {
    debugPrint('saveCurrentWeekAsMemory error: $e');
  }
}

/// Load weekly memory from SharedPreferences on app start
void _loadWeeklyMemory(SharedPreferences prefs) {
  try {
    final raw = prefs.getString(_Keys.weeklyMemory);
    if (raw == null) return;
    _lastWeekMemory = WeeklyMemory.fromJson(
        jsonDecode(raw) as Map<String, dynamic>);
    debugPrint('✅ Weekly memory loaded: Week ${_lastWeekMemory!.weekNumber}');
  } catch (e) {
    debugPrint('_loadWeeklyMemory error: $e');
  }
}

/// Public getter — used in UI to show current phase
WeeklyMemory? get lastWeekMemory => _lastWeekMemory;
String get currentPhase => _lastWeekMemory?.nextPhase ?? 'base';
int    get currentWeekNumber => (_lastWeekMemory?.weekNumber ?? 0) + 1;
String _aiSuggestion = "";
String _fallbackWorkout() {
  return """
AI busy right now ⚠️

🔥 Try this:
Push: Chest + Triceps  
Pull: Back + Biceps  
Legs: Quads + Hamstrings  

Stay consistent 💪
""";
}
  // ── Persistence helpers for new systems ──────────────────
  void _loadLastMuscleTrained(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(_Keys.lastMuscleTrained);
      if (raw == null) return;
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        _lastMuscleTrained = decoded.map((k, v) {
          try { return MapEntry(k as String, DateTime.parse(v as String)); }
          catch (_) { return MapEntry(k as String, DateTime(2000)); }
        });
      }
    } catch (_) {}
  }
void _onAIWorkoutGenerated() {
  // future gamification
}
// increaseAIUsage() removed — MonetizationService.recordAIUse() used instead
  void _saveLastMuscleTrained() {
    final encoded = jsonEncode(
        _lastMuscleTrained.map((k, v) => MapEntry(k, v.toIso8601String())));
    _saveToPrefs(_Keys.lastMuscleTrained, encoded);
  }

  void _loadPerformanceMemory(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(_Keys.performanceMemory);
      if (raw == null) return;
      final list = jsonDecode(raw);
      if (list is List) {
        _perfMemory = list.map<PerformancePattern?>((j) {
          try { return PerformancePattern.fromJson(j as Map<String, dynamic>); }
          catch (_) { return null; }
        }).whereType<PerformancePattern>().toList();
      }
    } catch (_) {}
  }

  void _savePerformanceMemory() {
    _saveToPrefs(_Keys.performanceMemory,
        jsonEncode(_perfMemory.map((p) => p.toJson()).toList()));
  }

  void _loadAnalyticsCache(SharedPreferences prefs) {
    try {
      final raw = prefs.getString('analytics_cache_v1');
      if (raw == null) return;
      final snap = AnalyticsSnapshot.fromJson(
          jsonDecode(raw) as Map<String, dynamic>);
      if (snap.cacheDate == _todayStr) _analyticsSnapshot = snap;
    } catch (_) {}
  }

  void _saveAnalyticsCache() {
    if (_analyticsSnapshot == null) return;
    _saveToPrefs('analytics_cache_v1', jsonEncode(_analyticsSnapshot!.toJson()));
  }

  // ═══════════════════════════════════════════════════════════
  // NOTIFY CONTROL
  // ═══════════════════════════════════════════════════════════
  void _safeNotify() {
    if (!_isBatching) { _refreshTrigger++; _invalidateCache(); notifyListeners(); }
  }
  void startBatch() { _isBatching = true; }
  void endBatch()   { _isBatching = false; _invalidateCache(); notifyListeners(); }

  void _invalidateCache() {
    _cachedCoachMessage  = null;
    _cachedRecoveryScore = null;
    _cachedIsFatigued    = null;
    _analyticsSnapshot   = null;
    // Note: _smoothed values intentionally NOT cleared — EMA persists for gradual change
  }

  // Exponential Moving Average — prevents score jumps (Apple Watch style)
  double _applyEMA(double? previous, double newValue) {
    if (previous == null) return newValue;
    return ((_emaAlpha * newValue) + ((1 - _emaAlpha) * previous))
        .clamp(0, 100);
  }

  // ═══════════════════════════════════════════════════════════
  // PRIMARY GETTERS
  // ═══════════════════════════════════════════════════════════
  bool                  get loading      => _loading;
  // isPremium getter → MonetizationService (line 441)
  List<DayPlan>         get weekPlan     => List.unmodifiable(_weekPlan);
  UserProfile           get profile      => _profile;
  StreakData            get streak       => _streak;
  List<HistoryEntry>    get history      => List.unmodifiable(_history);
  Set<String>           get favorites    => Set.unmodifiable(_favorites);
  Map<String, dynamic>  get settings     => Map.unmodifiable(_settings);
  List<WorkoutLog>      get logs         => List.unmodifiable(_logs);
  List<BodyMeasurement> get measurements => List.unmodifiable(_measurements);
  MoodType              get todayMood    => _todayMood;

  String get goal               => _profile.goal;
  String get level              => _profile.level;
  String get trainerType        => _profile.trainerType;
  String get fitnessGoal        => _profile.goal;
  String get fitnessLevel       => _profile.level;
  String get trainerPersonality => _profile.trainerType;
  double get weightKg           => _profile.weightKg;
  double get heightCm           => _profile.heightCm;
  int    get age                => _profile.age;
  String get gender             => _profile.gender;

  bool get workoutReminderEnabled => (_settings['workoutReminderEnabled'] as bool?) ?? false;
  bool get waterReminderEnabled   => (_settings['waterReminderEnabled']   as bool?) ?? false;
  bool get notificationsEnabled   => (_settings['notificationsEnabled']   as bool?) ?? true;
  int  get waterReminderInterval  => (_settings['waterReminderInterval']  as int?)  ?? 60;
// _dailyAiUsage and _freeAiLimit removed — MonetizationService owns these
  // ═══════════════════════════════════════════════════════════
  // PREMIUM
  // ═══════════════════════════════════════════════════════════

  bool canViewAdvancedStats()   => isPremium;
  bool canUseSmartCoach()       => isPremium;
  bool canUseAdvancedInsights() => isPremium;

  // ── Premium upgrade — delegates to MonetizationService ──────
  void setPremium(bool value) {
    if (value) {
      MonetizationService.instance.upgradeToPremium();
    } else {
      MonetizationService.instance.revokePremium();
    }
    _aiInsight = null;
    notifyListeners();
  }

  Future<void> upgradeToPremium() async {
    await MonetizationService.instance.upgradeToPremium();
    _aiInsight = null;
    notifyListeners();
  }

  // ── Behavior-based paywall trigger detection ────────────────
  // Returns a PaywallTrigger if conditions met, null if not.
  // UI calls this after key events to decide whether to show paywall.
  Future<PaywallTrigger?> checkPaywallTrigger() async {
    if (isPremium) return null;

    // AI limit
    if (!canUseAI()) {
      final should = await MonetizationService.instance
          .shouldShowPaywall(PaywallTrigger.aiLimitHit);
      if (should) return PaywallTrigger.aiLimitHit;
    }

    // 5th or 10th workout milestone
    final total = _streak.totalWorkouts;
    if (total == 5 || total == 10 || total == 25) {
      final should = await MonetizationService.instance
          .shouldShowPaywall(PaywallTrigger.workoutMilestone);
      if (should) return PaywallTrigger.workoutMilestone;
    }

    // 7-day streak
    if (_streak.currentStreak == 7 || _streak.currentStreak == 14) {
      final should = await MonetizationService.instance
          .shouldShowPaywall(PaywallTrigger.streakMilestone);
      if (should) return PaywallTrigger.streakMilestone;
    }

    return null;
  }

  /// Called after PR broken — check if paywall should show
  Future<PaywallTrigger?> checkPRPaywall() async {
    if (isPremium) return null;
    final should = await MonetizationService.instance
        .shouldShowPaywall(PaywallTrigger.prBroken);
    return should ? PaywallTrigger.prBroken : null;
  }

  // ═══════════════════════════════════════════════════════════
  // ██████  ELITE ANALYTICS ENGINE  ██████
  // ═══════════════════════════════════════════════════════════

  /// Cached analytics snapshot — computed once per day or on invalidation
  AnalyticsSnapshot get analytics {
    if (_analyticsSnapshot != null &&
        _analyticsSnapshot!.cacheDate == _todayStr) {
      return _analyticsSnapshot!;
    }
    _analyticsSnapshot = _computeAnalytics();
    _saveAnalyticsCache();
    return _analyticsSnapshot!;
  }

  AnalyticsSnapshot _computeAnalytics() {
    final variance = _jitter(3); // ±3 human variance — never static numbers

    return AnalyticsSnapshot(
      readinessScore:       (_computeReadiness()       + variance).clamp(0, 100),
      fatigueIndex:         (_computeFatigueIndex()    - variance).clamp(0, 100),
      effortScoreToday:     (_computeEffortScore()     + variance).clamp(0, 100),
      plateauScore:         (_computePlateauScore()    + variance).clamp(0, 100),
      overtTrainingRisk:    (_computeOvertTrainingRisk() - variance).clamp(0, 100),
      weeklyImprovementPct: _computeWeeklyImprovement(),
      muscleBalanceScore:   (_computeMuscleBalance()   + variance).clamp(0, 100),
      intensityScore:       (_computeIntensityScore()  + variance).clamp(0, 100),
      recoveryTrend:         _computeRecoveryTrend(),
      isOnPlateau:           _computePlateauScore() >= 60,
      cacheDate:             _todayStr,
    );
  }

  // ── Readiness Score (0–100) ───────────────────────────────
  double _computeReadiness() {
  return AnalyticsEngine.computeReadiness(
    recovery: getOverallRecovery().toDouble(),
    fatigue: _computeFatigueIndex(),
    streak: _streak.currentStreak,
    mood: _todayMood.name,
    needsDeload: needsDeloadByVolume,
  );
}

  // ── Fatigue Index (0–100) — higher = more fatigued ─────────
  double _computeFatigueIndex() {
  return AnalyticsEngine.computeFatigueIndex(
    logs: _logs,
    mood: _todayMood,
    streak: _streak.currentStreak,
  );
}

  // ── Effort Score (0–100) — today's workout completion rate ──
  double _computeEffortScore() {
    final today = _weekPlan.elementAtOrNull(todayIndex);
    if (today == null || today.exercises.isEmpty) return 50;

    int planned   = 0;
    int completed = 0;
    for (final ex in today.exercises) {
      planned   += ex.sets.length;
      completed += ex.sets.where((s) => s.done).length;
    }

    if (planned == 0) return 50;
    final base = (completed / planned * 100).clamp(0, 100);

    // Mood adjustment
  double score = base.toDouble();
    if (_todayMood == MoodType.tired && base > 60) score += 10; // Extra credit for showing up tired
    return score.clamp(0, 100);
  }

  // ── Plateau Detection (0–100 score) ──────────────────────
  double _computePlateauScore() {
  return AnalyticsEngine.computePlateauScore(
    logs: _logs,
  );
}
  /// Plateau detected: no strength increase in last 3–5 sessions
  bool get isOnPlateau => analytics.isOnPlateau;

  // ── Overtraining Risk (0–100) ─────────────────────────────
  double _computeOvertTrainingRisk() {
    double risk = 0;

    if (_streak.currentStreak >= 7)  risk += 20;
    if (_streak.currentStreak >= 14) risk += 25;
    if (_streak.currentStreak >= 21) risk += 30;

    final fi = _computeFatigueIndex();
    risk += fi * 0.4;

    if (needsDeloadByVolume) risk += 30;

    // Recovery check
    final recovery = getOverallRecovery();
    if (recovery < 40) risk += 25;
    else if (recovery < 60) risk += 10;

    return risk.clamp(0, 95);
  }

  // ── Weekly Improvement % ─────────────────────────────────
  double _computeWeeklyImprovement() {
  return AnalyticsEngine.computeWeeklyImprovement(
    logs: _logs,
  );
}

  // ── Muscle Balance Score (0–100, higher = more balanced) ──
  double _computeMuscleBalance() {
    const muscles = ['chest','back','legs','shoulders','arms','core'];
    final freq = <String, int>{};

    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    final recent = _logs.where((l) => l.date.isAfter(cutoff)).toList();

    for (final log in recent) {
      final m = _normalizeMuscle(log.exercise.split('_').first);
      if (m.isNotEmpty) freq[m] = (freq[m] ?? 0) + 1;
    }

    if (freq.isEmpty) return 74;

    final counts = muscles.map((m) => (freq[m] ?? 0).toDouble()).toList();
    final maxCount = counts.reduce(max);
    if (maxCount == 0) return 74;

    // Coefficient of variation: lower = more balanced
    final mean = counts.reduce((a, b) => a + b) / counts.length;
    if (mean == 0) return 74;
    final variance = counts.map((c) => pow(c - mean, 2)).reduce((a, b) => a + b) / counts.length;
    final cv = sqrt(variance) / mean;

    // Invert: CV of 0 = 100% balanced, CV of 1+ = 0% balanced
   return ((1 - cv.clamp(0, 1)) * 100).clamp(20, 97).toDouble();
  }

  // ── Intensity Score (0–100) ───────────────────────────────
  double _computeIntensityScore() {
    if (_logs.isEmpty) return 50;
    final recent = _logs.reversed.take(5).toList();
    final avgVol = recent.map((l) => l.weight * l.reps).reduce((a, b) => a + b) / recent.length;

    // Normalize against a baseline of 500 kg·reps per session
    const baseline = 500.0;
    return ((avgVol / baseline) * 80).clamp(20, 95);
  }

  // ── Recovery Trend (7-day rolling) ───────────────────────
  String _computeRecoveryTrend() {
    final now = DateTime.now();
    final this7 = _logs.where((l) => now.difference(l.date).inDays < 7)
        .fold(0.0, (s, l) => s + l.weight * l.reps);
    final prev7 = _logs.where((l) {
      final d = now.difference(l.date).inDays;
      return d >= 7 && d < 14;
    }).fold(0.0, (s, l) => s + l.weight * l.reps);

    if (prev7 == 0) return 'stable';
    final change = (this7 - prev7) / prev7;
    if (change >  0.05) return 'improving';
    if (change < -0.05) return 'declining';
    return 'stable';
  }
String _formatWorkout(Map<String, dynamic> data) {
  try {
    final name = data["workout_name"] ?? "Workout";
    final days = data["days"] as List? ?? [];

    String output = "🔥 $name\n\n";

    for (var day in days) {
      output += "${day["day"]} — ${day["focus"]}\n";

      final exercises = day["exercises"] as List? ?? [];
      for (var ex in exercises) {
        output += "• ${ex["name"]} (${ex["sets"]} x ${ex["reps"]})\n";
      }

      output += "\n";
    }

    return output.trim();
  } catch (_) {
    return "Workout ready 💪";
  }
}
  // ── Public analytics getters — EMA smoothed ──────────────

  /// Readiness Score 0–100, EMA-smoothed (Apple Watch style)
  double get readinessScore {
    final raw = isPremium
        ? analytics.readinessScore
        : (analytics.readinessScore * 0.5 + 30).clamp(0, 70);
   _smoothedReadiness = _applyEMA(
  _smoothedReadiness,
  raw.toDouble(),
);
    if (_cachedRecoveryScore == null) _cachedRecoveryScore = _smoothedReadiness!.toInt();
    return _smoothedReadiness!;
  }

  /// Fatigue Index 0–100, EMA-smoothed
  double get fatigueIndex {
    final raw = isPremium ? analytics.fatigueIndex : analytics.fatigueIndex.clamp(0, 60);
  _smoothedFatigue = _applyEMA(_smoothedFatigue, raw.toDouble());
    return _smoothedFatigue!;
  }

  /// Effort score for today's workout (0–100)
  double get effortScoreToday => analytics.effortScoreToday;

  /// Plateau score 0–100
  double get plateauScore => isPremium ? analytics.plateauScore : 0;

  /// Overtraining risk 0–100
  double get overTrainingRisk => isPremium ? analytics.overtTrainingRisk : 0;

  /// Weekly improvement %
  double get weeklyImprovementPercent => analytics.weeklyImprovementPct;
String get weeklyMessage {
  if (weeklyImprovementPercent > 15) return "🚀 Elite progress!";
  if (weeklyImprovementPercent > 10) return "🔥 Strong progress this week!";
  if (weeklyImprovementPercent > 0) return "📈 You're improving steadily";
  if (weeklyImprovementPercent < -15) return "🛑 Overtraining risk!";
  if (weeklyImprovementPercent < -10) return "⚠️ Recovery needed";
  return "Maintain consistency 💪";
}

String get muscleImbalance {
  return AnalyticsEngine.getMuscleImbalance(_logs);
}
  /// Muscle balance score 0–100
  double get muscleBalanceScore => isPremium ? analytics.muscleBalanceScore : 70;

  /// Workout intensity score, EMA-smoothed
  double get intensityScore {
    _smoothedIntensity = _applyEMA(_smoothedIntensity, analytics.intensityScore);
    return _smoothedIntensity!;
  }

  /// Recovery trend: 'improving' | 'stable' | 'declining'
  String get recoveryTrend => analytics.recoveryTrend;

  // ── Time-of-day micro-intelligence ────────────────────────

  /// Current time context — drives tone and message type
  TimeContext get timeContext {
    final h = DateTime.now().hour;
    if (h >= 5  && h < 8)  return TimeContext.earlyMorning;
    if (h >= 8  && h < 12) return TimeContext.morning;
    if (h >= 12 && h < 18) return TimeContext.afternoon;
    if (h >= 18 && h < 22) return TimeContext.evening;
    return TimeContext.lateNight;
  }

  /// Time-aware greeting for coach card header
  String get timeAwareGreeting {
    final name = _profile.name.isNotEmpty ? _profile.name.split(' ').first : '';
    switch (timeContext) {
      case TimeContext.earlyMorning:
        return name.isNotEmpty
            ? '🌅 Early riser, $name. The world is still asleep.'
            : '🌅 Early riser. The world is still asleep.';
      case TimeContext.morning:
        return name.isNotEmpty
            ? '☀️ Good morning, $name. Let\'s make today count.'
            : '☀️ Good morning. Let\'s make today count.';
      case TimeContext.afternoon:
        return name.isNotEmpty
            ? '⚡ Afternoon, $name. Momentum is everything right now.'
            : '⚡ Afternoon. Momentum is everything right now.';
      case TimeContext.evening:
        return name.isNotEmpty
            ? '🌆 Evening, $name. End the day strong.'
            : '🌆 Evening. End the day strong.';
      case TimeContext.lateNight:
        return name.isNotEmpty
            ? '🌙 Late night, $name. Rest is training too.'
            : '🌙 Late night. Rest is training too.';
    }
  }

  /// Time-aware workout nudge — prep / during / recovery
  String get timeAwareWorkoutNudge {
    switch (timeContext) {
      case TimeContext.earlyMorning:
        return _pick([
          '🌅 Morning sessions build the strongest habits. Go.',
          '⏰ 5am crew. The commitment is already the win.',
          '🌄 Early training = endorphins all day. Let\'s go.',
        ]);
      case TimeContext.morning:
        return _pick([
          '☀️ Perfect training window. Body is primed. Attack.',
          '🔥 Morning energy is at its peak — use it.',
          '💪 Best time to train. No excuses at this hour.',
        ]);
      case TimeContext.afternoon:
        return _pick([
          '⚡ Afternoon slump? Train through it.',
          '💡 Post-lunch training — cortisol is low, focus is high.',
          '🔄 Afternoon = strength peak for most people. Capitalize.',
        ]);
      case TimeContext.evening:
        return _pick([
          '🌆 End your day on your terms. One session left.',
          '🔥 Evening training — release the day\'s stress into reps.',
          '⚡ Late session counts just as much. Show up.',
        ]);
      case TimeContext.lateNight:
        return _pick([
          '🌙 Late night? Lighter session — protect your sleep.',
          '😴 This hour: mobility and deload only. Recovery matters.',
          '🔄 Late training = recovery focus. Keep it light and brief.',
        ]);
    }
  }

  // ── Preferred exercises from AI memory ───────────────────

  /// User's most frequently trained exercises (from logs, top 5)
  List<String> get preferredExercises {
    final freq = <String, int>{};
    for (final log in _logs) {
      final name = log.exercise.replaceAll('_', ' ');
      freq[name] = (freq[name] ?? 0) + 1;
    }
    if (freq.isEmpty) return [];
    final sorted = freq.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(5).map((e) => e.key).toList();
  }


List<MuscleRecovery> get muscleRecoveryList {
  const muscles = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'];
  return muscles.map((muscle) {
    final key   = _normalizeMuscle(muscle);
    final score = getMuscleRecovery(muscle);

    // Last-trained date display — pulled from _lastMuscleTrained
    final last     = _lastMuscleTrained[key];
    final lastStr  = last != null
        ? '${last.day}/${last.month}'
        : 'Never';

    // Last volume from logs — same logic as before
    final muscleLogs = _logs
        .where((l) => _normalizeMuscle(
              l.muscleGroup ?? l.exercise.split('_').first,
            ) == key)
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));

    final lastVolume = muscleLogs.isNotEmpty
        ? muscleLogs.first.weight * muscleLogs.first.reps
        : 0.0;

    return MuscleRecovery(
      muscle:           muscle,
      recoveryScore:    score.round().clamp(0, 100),
      lastTrainedDate:  lastStr,
      lastVolume:       lastVolume,
    );
  }).toList();
}
  /// Preferred workout days from history pattern
  List<int> get preferredWorkoutDays {
    final counts = List<int>.filled(7, 0);
    for (final h in _history) {
      try { counts[(DateTime.parse(h.date).weekday - 1).clamp(0, 6)]++; }
      catch (_) {}
    }
    final maxCount = counts.reduce(max);
    if (maxCount == 0) return [];
    // Return day indices with above-average frequency
    final avg = counts.reduce((a, b) => a + b) / 7;
    return List.generate(7, (i) => i)
        .where((i) => counts[i] >= avg)
        .toList();
  }

  // ── Identity reinforcement messages ──────────────────────

  /// Returns identity message based on streak + history
  String get identityMessage {
    final streak = _streak.currentStreak;
    final total  = _streak.totalWorkouts;

    if (streak >= 30) return _pick([
      '🔱 You\'re not someone who \'tries\' to work out. You\'re an athlete.',
      '👑 30+ days consistent. This is your identity now, not a goal.',
      '⚔️ The version of you who started is gone. This is who you are.',
    ]);
    if (streak >= 14) return _pick([
      '⚡ 14+ days. You\'re becoming consistent — that\'s rarer than talent.',
      '🔥 Two weeks straight. You\'re not the same person you were.',
      '💪 Consistency this long means it\'s becoming a part of you.',
    ]);
    if (streak >= 7) return _pick([
      '🌟 7 days without breaking. That\'s a new identity forming.',
      '🔥 One week streak. You\'re proving something to yourself.',
      '💡 Week 1 complete. Most people never get here.',
    ]);
    if (total >= 20) return _pick([
      '📈 20+ workouts logged. You\'re becoming consistent.',
      '💪 The habit is forming. Keep pushing.',
      '⚡ 20+ sessions in. This is real now.',
    ]);
    if (total >= 5) return _pick([
      '🌱 You\'re building something real. Don\'t stop now.',
      '🔄 5 sessions in. The compound interest is starting.',
      '💙 Small start, real progress. Trust the process.',
    ]);
    return _pick([
      '🚀 Every expert was once a beginner. You\'re becoming.',
      '💙 You\'re early. The transformation has started.',
      '🌱 Day one energy is rare. Protect it.',
    ]);
  }

  // ── Near-miss PR detection ────────────────────────────────

  /// Detects if the latest log for an exercise was within 5% of a PR
  String? nearMissMessage(String exerciseKey, String unit) {
    final pr = getPR(exerciseKey, unit);
    if (pr <= 0) return null;

    final exLogs = getLogsForExercise(exerciseKey);
    if (exLogs.length < 2) return null;

    exLogs.sort((a, b) => b.date.compareTo(a.date));
    final latest = exLogs.first;

    final latestVal = unit == 'reps' ? latest.reps.toDouble()
        : unit == 'min' ? latest.minutes.toDouble()
        : latest.weight;

    final gap = pr - latestVal;
    if (gap <= 0) return null; // Was a PR
    final gapPct = gap / pr;

    if (gapPct <= 0.05) {
      // Within 5% of PR
      if (unit == 'reps') {
        return '🎯 Just ${gap.toInt()} reps away from your PR! Next session — go for it.';
      }
      return '🎯 Only ${gap.toStringAsFixed(1)}${unit == 'min' ? ' min' : 'kg'} from your PR! So close.';
    }
    if (gapPct <= 0.10) {
      return '📈 Within 10% of your PR on ${exerciseKey.replaceAll('_', ' ')}. Push harder next time.';
    }
    return null;
  }

  // ── Streak risk detection ─────────────────────────────────

  /// Returns streak risk if user hasn't trained today
  StreakRiskResult get streakRisk {
    if (_streak.currentStreak == 0) {
      return const StreakRiskResult(atRisk: false, message: '', hoursLeft: 24);
    }

    final lastDate = _streak.lastWorkoutDate;
    if (lastDate == _todayStr) {
      return const StreakRiskResult(atRisk: false, message: '', hoursLeft: 24);
    }

    final now        = DateTime.now();
    final midnight   = DateTime(now.year, now.month, now.day + 1);
    final hoursLeft  = midnight.difference(now).inHours;

    if (hoursLeft <= 4) {
      return StreakRiskResult(
        atRisk:    true,
        hoursLeft: hoursLeft,
        message:   '🚨 ${_streak.currentStreak}-day streak ending in ${hoursLeft}h! Train NOW or lose it.',
      );
    }
    if (hoursLeft <= 8) {
      return StreakRiskResult(
        atRisk:    true,
        hoursLeft: hoursLeft,
        message:   '⚠️ ${_streak.currentStreak}-day streak at risk — ${hoursLeft}h left today.',
      );
    }
    return StreakRiskResult(
      atRisk:    true,
      hoursLeft: hoursLeft,
      message:   '🔥 Don\'t break your ${_streak.currentStreak}-day streak. Train today.',
    );
  }

  // ── Achievement event detection ───────────────────────────

  /// Check if any achievement should fire based on current state
  AchievementEvent? checkAchievementTrigger() {
    final streak = _streak.currentStreak;
    final total  = _streak.totalWorkouts;

    // Streak achievements
    if (streak == 7)  return const AchievementEvent(id: 'streak_7',  title: 'On Fire',       description: '7-day streak reached!',       emoji: '🔥', bonusXP: 100, triggerCondition: 'streak_7');
    if (streak == 14) return const AchievementEvent(id: 'streak_14', title: 'Unstoppable',   description: '14-day streak reached!',      emoji: '⚡', bonusXP: 150, triggerCondition: 'streak_14');
    if (streak == 30) return const AchievementEvent(id: 'streak_30', title: 'Iron Will',      description: '30 days without stopping.',   emoji: '🛡️', bonusXP: 300, triggerCondition: 'streak_30');
    if (streak == 60) return const AchievementEvent(id: 'streak_60', title: 'Legend Mode',   description: '60-day streak. You\'re elite.',emoji: '👑', bonusXP: 600, triggerCondition: 'streak_60');

    // Total workout milestones
    if (total == 10)  return const AchievementEvent(id: 'total_10',  title: 'First 10',       description: '10 workouts completed!',      emoji: '💪', bonusXP: 80,  triggerCondition: 'total_10');
    if (total == 25)  return const AchievementEvent(id: 'total_25',  title: 'Quarter Century',description: '25 workouts logged!',          emoji: '🏅', bonusXP: 120, triggerCondition: 'total_25');
    if (total == 50)  return const AchievementEvent(id: 'total_50',  title: 'Halfway Hero',   description: '50 sessions. Serious work.',  emoji: '🏆', bonusXP: 200, triggerCondition: 'total_50');
    if (total == 100) return const AchievementEvent(id: 'total_100', title: 'Century Club',   description: '100 workouts. Elite tier.',   emoji: '💎', bonusXP: 500, triggerCondition: 'total_100');

    // Plateau broken achievement
    if (isOnPlateau && analytics.weeklyImprovementPct > 5) {
      return const AchievementEvent(id: 'plateau_broken', title: 'Plateau Destroyer', description: 'You broke through your plateau!', emoji: '💥', bonusXP: 150, triggerCondition: 'plateau_broken');
    }

    return null;
  }

  // ═══════════════════════════════════════════════════════════
  // MUSCLE RECOVERY — FIXED & PERSISTED
  // ═══════════════════════════════════════════════════════════
  double getMuscleRecovery(String muscle) {
    if (muscle.isEmpty) return 97;
    final key = _normalizeMuscle(muscle);
    if (key.isEmpty) return 97;

    final last = _lastMuscleTrained[key];
    if (last == null) return 97 + _jitter(2); // never trained

    final hours    = DateTime.now().difference(last).inHours;
    final maxHours = _Keys.muscleRecoveryHours[key] ?? 48;
    double recovery = ((hours / maxHours) * 100).clamp(0.0, 100.0);

    // Mood adjustment
    if (_todayMood == MoodType.tired)     recovery *= 0.85;
    if (_todayMood == MoodType.energetic) recovery  = (recovery * 1.05).clamp(0, 100);

    // Streak fatigue accumulation
    if (_streak.currentStreak >= 5)  recovery *= 0.97;
    if (_streak.currentStreak >= 10) recovery *= 0.94;
    if (_streak.currentStreak >= 21) recovery *= 0.90;

    // Add slight human variance — never show exact same number
    recovery += _jitter(2);
    return recovery.clamp(5, 97);
  }

 int getOverallRecovery() {
  const muscles = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'];
  final total   = muscles.fold(0.0, (s, m) => s + getMuscleRecovery(m));
  return (total / muscles.length).round().clamp(10, 97);
}
  String _normalizeMuscle(String muscle) {
    final m = muscle.toLowerCase();
    if (m.contains('shoulder')) return 'shoulders';
    if (m.contains('leg') || m.contains('glute') ||
        m.contains('hamstring') || m.contains('calf') ||
        m.contains('quad')) return 'legs';
    if (m.contains('chest') || m.contains('pec')) return 'chest';
    if (m.contains('back') || m.contains('lat') ||
        m.contains('row') || m.contains('deadlift')) return 'back';
    if (m.contains('arm') || m.contains('bicep') ||
        m.contains('tricep') || m.contains('curl')) return 'arms';
    if (m.contains('core') || m.contains('ab') ||
        m.contains('plank') || m.contains('crunch')) return 'core';
    return m.trim();
  }

  // ─── Small variance for human-like numbers ────────────────
  double _jitter(double range) => (_random.nextDouble() * range * 2) - range;

  // ═══════════════════════════════════════════════════════════
  // DELOAD DETECTION
  // ═══════════════════════════════════════════════════════════
  bool get needsDeloadByVolume {
    // ✅ SCIENTIFIC: Uses ACWR + training age + periodization rules
    // Old code: triggered after only 4 sessions (wrong — that's just beginner variation)
    return AnalyticsEngine.shouldDeload(
      logs:          _logs,
      streak:        _streak.currentStreak,
      totalWorkouts: _streak.totalWorkouts,
    );
  }

  // ── Avoidance detection ───────────────────────────────────
  /// Returns muscles the user has skipped recently
  List<String> get skippedMuscleGroups {
    const muscles = ['chest','back','legs','shoulders','arms'];
    final cutoff  = DateTime.now().subtract(const Duration(days: 14));
    final freq    = <String, int>{};

    for (final log in _logs.where((l) => l.date.isAfter(cutoff))) {
      final m = _normalizeMuscle(log.exercise.split('_').first);
      if (m.isNotEmpty) freq[m] = (freq[m] ?? 0) + 1;
    }

    return muscles.where((m) => (freq[m] ?? 0) == 0).toList();
  }

  /// Days since last workout
  int get daysSinceLastWorkout {
    if (_history.isEmpty) return 0;
    try {
      final last = DateTime.parse(_history.first.date);
      return DateTime.now().difference(last).inDays;
    } catch (_) { return 0; }
  }

  /// True if user has been inactive 3+ days
  bool get isInactive => daysSinceLastWorkout >= 3;

  // ═══════════════════════════════════════════════════════════
  // AI MEMORY — performance pattern storage
  // ═══════════════════════════════════════════════════════════
  void _recordPerformancePattern(DayPlan day) {
    final setsPlanned   = day.exercises.fold(0, (v, e) => v + e.sets.length);
    final setsCompleted = day.exercises.fold(0, (v, e) =>
        v + e.sets.where((s) => s.done).length);
    final volume = _calcVolume(day);
    final effort = setsPlanned > 0
        ? (setsCompleted / setsPlanned * 100).clamp(0, 100)
        : 50.0;

    // Detect which muscles were trained
    final musclesHit = day.exercises
        .map((e) => _normalizeMuscle(e.category))
        .where((m) => m.isNotEmpty)
        .toSet()
        .toList();

    // Find best exercise (highest volume: weight × reps across done sets)
    String bestEx = '';
    double bestVol = 0;
    for (final ex in day.exercises) {
      final exVol = ex.sets.where((s) => s.done)
          .fold(0.0, (s, set) => s + set.weight * set.reps);
      if (exVol > bestVol) { bestVol = exVol; bestEx = ex.name; }
    }

    _perfMemory.insert(0, PerformancePattern(
      date:             _todayStr,
      volume:           volume,
      setsCompleted:    setsCompleted,
      setsPlanned:      setsPlanned,
     effortScore: effort.toDouble(),
      mood:             _todayMood.name,
      wasFailedSession: effort < 40,
      musclesTrained:   musclesHit,
      bestExercise:     bestEx,
    ));

    if (_perfMemory.length > _maxMemory) {
      _perfMemory = _perfMemory.sublist(0, _maxMemory);
    }

    _savePerformanceMemory();
  }

  /// Average effort score from AI memory
  double get averageEffortScore {
    if (_perfMemory.isEmpty) return 70;
    final total = _perfMemory.fold(0.0, (s, p) => s + p.effortScore);
    return (total / _perfMemory.length).clamp(0, 100);
  }

  /// How many recent sessions were failed (effort < 40%)
  int get failedSessionCount =>
      _perfMemory.where((p) => p.wasFailedSession).length;

  /// Whether user has a pattern of failing workouts
  bool get hasFailurePattern => failedSessionCount >= 2;

  /// User's all-time best exercise (most volume in any session)
  String get bestPerformingExercise {
    if (_perfMemory.isEmpty) return '';
    final non = _perfMemory.where((p) => p.bestExercise.isNotEmpty).toList();
    if (non.isEmpty) return '';
    // Most frequently appearing as "best"
    final freq = <String, int>{};
    for (final p in non) {
      freq[p.bestExercise] = (freq[p.bestExercise] ?? 0) + 1;
    }
    return (freq.entries.toList()
        ..sort((a, b) => b.value.compareTo(a.value)))
        .first.key;
  }

  /// Muscles skipped in last 7 days (from AI memory)
  List<String> get musclesSkippedLast7Days {
    const all = ['chest','back','legs','shoulders','arms','core'];
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    final trained = <String>{};
    for (final p in _perfMemory) {
      try {
        final d = DateTime.parse(p.date);
        if (d.isAfter(cutoff)) trained.addAll(p.musclesTrained);
      } catch (_) {}
    }
    return all.where((m) => !trained.contains(m)).toList();
  }

  /// Adaptive tone — based on user behavior memory
  String get adaptiveCoachTone {
    // Lazy: 2+ failed sessions → strict
    if (hasFailurePattern) return 'strict';
    // On fire: high effort consistently → hype
    if (averageEffortScore >= 80 && performanceTrend == 'improving') return 'motivational';
    // Struggling but trying: supportive
    if (performanceTrend == 'declining' && !hasFailurePattern) return 'friendly';
    // Default: use user's preference
    return _profile.trainerType;
  }

  /// Performance trend from AI memory: 'improving' | 'declining' | 'stable'
  String get performanceTrend {
    if (_perfMemory.length < 3) return 'stable';
    final recent = _perfMemory.take(3).map((p) => p.effortScore).toList();
    final older  = _perfMemory.skip(3).take(3).map((p) => p.effortScore).toList();
    if (older.isEmpty) return 'stable';
    final recentAvg = recent.reduce((a, b) => a + b) / recent.length;
    final olderAvg  = older.reduce((a, b) => a + b) / older.length;
    if (recentAvg > olderAvg + 5) return 'improving';
    if (recentAvg < olderAvg - 5) return 'declining';
    return 'stable';
  }

  // ═══════════════════════════════════════════════════════════
  // AI COACH SYSTEM
  // ═══════════════════════════════════════════════════════════
  AICoachInsight get aiInsight {
    if (_isAICacheValid()) return _aiInsight!;
    _aiInsight = _computeAIInsight();
    _saveAICache();
    return _aiInsight!;
  }

  bool _isAICacheValid() =>
      _aiInsight != null && _aiInsight!.cacheDate == _todayStr;

  AICoachInsight _computeAIInsight() {
    final fatigue   = _detectFatigueLevel();
    final wSuggest  = _computeWeightSuggestion();
    final weakGroup = _detectWeakMuscleGroup();
    final sets      = _computeRecommendedSets(fatigue);
    final modifier  = _computeWeightModifier(fatigue, wSuggest);
    final message   = _generateDailyCoachMessage(fatigue, wSuggest, weakGroup);

    return AICoachInsight(
      fatigueLevel:      fatigue,
      fatigueMessage:    _fatigueMessage(fatigue),
      weightSuggestion:  wSuggest,
      weightMessage:     _weightSuggestionMessage(wSuggest),
      weakMuscleGroup:   weakGroup,
      dailyCoachMessage: message,
      recommendedSets:   sets,
      weightModifier:    modifier,
      cacheDate:         _todayStr,
    );
  }

  FatigueLevel _detectFatigueLevel() {
    final fi = _computeFatigueIndex();
    if (fi >= 60) return FatigueLevel.fatigued;
    if (fi >= 25) return FatigueLevel.normal;
    return FatigueLevel.fresh;
  }


  String _fatigueMessage(FatigueLevel l) {
    switch (l) {
      case FatigueLevel.fresh:
        return _pick(['✅ Fully recovered — optimal performance today!',
          '🔋 Energy levels high — go get that PR!',
          '💪 Body fully charged — great session ahead!']);
      case FatigueLevel.normal:
        return _pick(['😐 Normal fatigue — train smart, focus on form.',
          '😤 Moderate soreness — warm up well.',
          '🔄 Decent recovery — quality over quantity today.']);
      case FatigueLevel.fatigued:
        return _pick(['⚠️ High fatigue — reduce intensity today.',
          '🔴 Body needs recovery — light session only.',
          '⚡ Significant fatigue detected — deload recommended.']);
    }
  }

  WeightSuggestion _computeWeightSuggestion() {
    if (_logs.isEmpty) return WeightSuggestion.maintain;

    // Plateau → change strategy
    if (isOnPlateau) {
      // Plateau break: drop weight 10%, reset reps, rebuild
      return WeightSuggestion.decrease;
    }

    final recent = _logs.reversed.take(6).toList();
    if (recent.isEmpty) return WeightSuggestion.maintain;

    final lastEx = recent.first;
    final sameEx = recent.where((l) => l.exercise == lastEx.exercise).take(3).toList();

    if (sameEx.length < 2) {
      if (lastEx.reps >= 12) return WeightSuggestion.increase;
      if (lastEx.reps <= 5)  return WeightSuggestion.decrease;
      return WeightSuggestion.maintain;
    }

    sameEx.sort((a, b) => b.date.compareTo(a.date));
    final lr = sameEx[0].reps;   final pr = sameEx[1].reps;
    final lw = sameEx[0].weight; final pw = sameEx[1].weight;

    if (lr >= 12 && lw >= pw)            return WeightSuggestion.increase;
    if (lr > pr  && lr >= 10)            return WeightSuggestion.increase;
    if (lr < pr * 0.75 && lr <= 5)       return WeightSuggestion.decrease;
    if (lw > pw * 1.1 && lr < pr * 0.8) return WeightSuggestion.decrease;
    return WeightSuggestion.maintain;
  }

  String _weightSuggestionMessage(WeightSuggestion s) {
    if (isOnPlateau) {
      return '🔄 Plateau detected — drop 10% weight, reset reps, rebuild stronger!';
    }
    switch (s) {
      case WeightSuggestion.increase:
        return _pick(['📈 Progressive overload — increase weight 2.5–5kg!',
          '💪 Ready to grow — add weight this session!',
          '🏋️ Your strength has adapted — time to push more!']);
      case WeightSuggestion.decrease:
        return _pick(['⬇️ Reduce load 10% — prioritize form.',
          '🎯 Drop weight slightly — quality reps today.',
          '⚠️ Load too high — reset and rebuild with form.']);
      case WeightSuggestion.maintain:
        return _pick(['🎯 Same weight — perfect form and tempo today.',
          '🔁 Maintain load — squeeze every rep.',
          '💡 Consistent weight — master the movement.']);
    }
  }

  String _detectWeakMuscleGroup() {
    if (_logs.isEmpty) return '';
    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    final recent = _logs.where((l) => l.date.isAfter(cutoff)).toList();
    if (recent.isEmpty) return '';

    const keywords = {
      'Chest':     ['bench','chest','fly','push','pec','incline','decline'],
      'Back':      ['row','pull','deadlift','lat','back','chin'],
      'Legs':      ['squat','leg','lunge','calf','hamstring','glute','rdl'],
      'Shoulders': ['shoulder','press','lateral','raise','delt','arnold'],
      'Arms':      ['curl','tricep','bicep','hammer','pushdown','extension'],
      'Core':      ['plank','crunch','ab','core','sit'],
    };

    final freq = <String, int>{};
    for (final log in recent) {
      final name = log.exercise.toLowerCase();
      for (final entry in keywords.entries) {
        if (entry.value.any((k) => name.contains(k))) {
          freq[entry.key] = (freq[entry.key] ?? 0) + 1;
          break;
        }
      }
    }

    if (freq.isEmpty) return '';
    const expected = ['Chest','Back','Legs','Shoulders','Arms'];
    String weakest = ''; int minFreq = 999;
    for (final m in expected) {
      final c = freq[m] ?? 0;
      if (c < minFreq) { minFreq = c; weakest = m; }
    }
    return weakest;
  }

  int _computeRecommendedSets(FatigueLevel f) {
    final base = level == 'beginner' ? 3 : level == 'advanced' ? 5 : 4;
    // Adaptive: if plateau, add sets
    final plateauBonus = isOnPlateau ? 1 : 0;
    switch (f) {
      case FatigueLevel.fatigued: return (base - 1 + plateauBonus).clamp(2, 6);
      case FatigueLevel.fresh:    return (base + 1 + plateauBonus).clamp(3, 6);
      case FatigueLevel.normal:   return (base + plateauBonus).clamp(2, 6);
    }
  }

  // shouldShowUpgrade() → use MonetizationService.instance.shouldShowPaywall()
  double _computeWeightModifier(FatigueLevel f, WeightSuggestion s) {
    double m = 1.0;
    switch (f) {
      case FatigueLevel.fatigued: m *= 0.80; break;
      case FatigueLevel.normal:   m *= 0.95; break;
      case FatigueLevel.fresh:    break;
    }
    switch (s) {
      case WeightSuggestion.increase: m *= 1.05; break;
      case WeightSuggestion.decrease: m *= 0.90; break;
      case WeightSuggestion.maintain: break;
    }
    // Plateau adjustment: drop to reset
    if (isOnPlateau) m *= 0.90;
    return m.clamp(0.5, 1.15);
  }

  // ── Human-Like Coach Message Generator ───────────────────
  String _generateDailyCoachMessage(
      FatigueLevel fatigue, WeightSuggestion suggestion, String weakMuscle) {

    // Use adaptive tone instead of static profile preference
    final style  = adaptiveCoachTone;
    final streak = _streak.currentStreak;
    final trend  = performanceTrend;
    final mood   = _todayMood;
    final ctx    = timeContext;

    // ── Late night override — always recommend recovery ──────
    if (ctx == TimeContext.lateNight && fatigue != FatigueLevel.fresh) {
      return _pick([
        '🌙 Late night with fatigue — your best session tomorrow starts with recovery now.',
        '😴 Body is tired and it\'s late. Stretch, sleep, and attack tomorrow.',
        '🌙 Late night training with fatigue = injury risk. Rest is the smart move.',
      ]);
    }

    // ── 1. Streak pressure — one day from milestone ──────────
    if (streak > 0) {
      if (streak == 6)  return _streakPressure(style, streak, 7,  '7-DAY FIRE BADGE');
      if (streak == 13) return _streakPressure(style, streak, 14, 'UNSTOPPABLE BADGE');
      if (streak == 29) return _streakPressure(style, streak, 30, 'IRON WILL BADGE');
      if (streak == 59) return _streakPressure(style, streak, 60, 'LEGEND STATUS');
    }

    // ── 2. Comeback message — emotionally intelligent ────────
    if (isInactive) {
      final days = daysSinceLastWorkout;
      if (days == 1) {
        return _style(style,
          friendly: '💡 Yesterday was rest. Champions come back stronger. Today is yours.',
          strict:   '📋 1 day off. It ends today. Get moving.',
          military: '🪖 1 DAY OFFLINE. REPORT FOR DUTY. NOW.',
          hype:     '⚡ ONE day off and you\'re already itching to come back — GOOD! LET\'S GO!!');
      }
      if (days == 2) {
        return _style(style,
          friendly: '⚠️ 2 days without training. Your streak is at risk — protect what you\'ve built.',
          strict:   '⚠️ 2 days missed. Your competitors didn\'t skip. Today is mandatory.',
          military: '🪖 2 DAYS OFFLINE. STREAK UNDER THREAT. RESPOND.',
          hype:     '🔴 2 DAYS?! Your streak is BLEEDING OUT! Save it — TRAIN TODAY!!');
      }
      return _style(style,
        friendly: '👋 $daysSinceLastWorkout days since your last session. No judgment — let\'s write your comeback today 💪',
        strict:   '📋 $daysSinceLastWorkout days missed. Acknowledge it. Move past it. Today begins the rebuild.',
        military: '🪖 ${daysSinceLastWorkout}D OFFLINE. WELCOME BACK. OPERATION RESUME. EXECUTE.',
        hype:     '🔥 ${daysSinceLastWorkout} DAYS?? Your comeback story starts RIGHT NOW! MAKE IT EPIC!!');
    }

    // ── 3. Behavior pattern: user fails often ────────────────
    if (hasFailurePattern) {
      return _style(style,
        friendly: '💙 I\'ve noticed you\'ve been struggling lately. That\'s human — but today, just finish ONE set. Then another.',
        strict:   '📊 Pattern detected: 2+ incomplete sessions. Today: minimum 3 sets. Consistency first.',
        military: '🪖 PATTERN: FAILING. CORRECTION MODE. 3 SETS MINIMUM. EXECUTE MISSION.',
        hype:     '🧠 Your brain says quit — your BODY says go. Override it! Just START — momentum will carry you!!');
    }

    // ── 4. Deload signal ──────────────────────────────────────
    if (needsDeloadByVolume) {
      return _style(style,
        friendly: '🔄 Volume dropping 3 sessions. Smart move: deload week. Light sets, mobility focus.',
        strict:   '⚠️ Volume declining 3 sessions. Mandatory deload. 60% intensity max.',
        military: '🪖 DELOAD PROTOCOL ACTIVE. DATA SAYS REDUCE. EXECUTE.',
        hype:     '💡 Deload THIS week = comeback NEXT week with NEW PRS!! Trust the science!!');
    }

    // ── 5. Plateau → change strategy ─────────────────────────
    if (isOnPlateau) {
      return _style(style,
        friendly: '🔄 Plateau! Let\'s shake it up — drop 10%, add sets, attack from a new angle.',
        strict:   '📊 Strength stagnant 3+ sessions. Reset: -10% weight, +1 set. Rebuild.',
        military: '🪖 PLATEAU DETECTED. CHANGING TACTICS. DROP WEIGHT. ADD VOLUME. MOVE.',
        hype:     '💥 PLATEAU?! That\'s just your body BEGGING for a new stimulus! DESTROY IT!!');
    }

    // ── 6. Muscles skipped (AI memory-based) ─────────────────
    if (musclesSkippedLast7Days.isNotEmpty && _streak.totalWorkouts > 0) {
      final skipped = musclesSkippedLast7Days.first;
      final cap = '${skipped[0].toUpperCase()}${skipped.substring(1)}';
      return _style(style,
        friendly: '🎯 $cap hasn\'t been trained in 7 days — let\'s fix that imbalance today!',
        strict:   '⚠️ $cap skipped 7+ days. Muscle imbalance forming. Address it today.',
        military: '🪖 MEMORY ALERT: $cap NEGLECTED 7 DAYS. CORRECT IMBALANCE. TODAY.',
        hype:     '🔥 Your $cap is collecting dust for 7 DAYS! Wake it UP — time to PUNISH IT!!');
    }

    // ── 7. Declining performance — supportive ────────────────
    if (trend == 'declining') {
      return _style(style,
        friendly: '💙 Noticed your effort dipping. That\'s okay — just show up today. That\'s the whole goal.',
        strict:   '📉 Performance declining. Evaluate: sleep? food? stress? Then fix one thing today.',
        military: '🪖 EFFORT LEVEL: DEGRADING. IDENTIFY CAUSE. CORRECT. REPORT.',
        hype:     '🔥 You\'re in a slump but LEGENDS were BUILT in slumps! TODAY IS THE TURNING POINT!!');
    }

    // ── 8. Mood × Fatigue combos ──────────────────────────────
    if (mood == MoodType.tired && fatigue == FatigueLevel.fatigued) {
      return _style(style,
        friendly: '😴 Body + mind are tired. Light session — still counts! 💪',
        strict:   '😐 Tired and fatigued. Drop 30% intensity. Stay consistent.',
        military: '🪖 FATIGUE REAL. REDUCE WEIGHT. NEVER REDUCE EFFORT.',
        hype:     '💤 60% effort today builds the habit. Champions REST smart!');
    }

    if (mood == MoodType.energetic && fatigue == FatigueLevel.fresh) {
      return _style(style,
        friendly: '⚡ FULLY charged today! This is a PR day — go for it! 🔥',
        strict:   '🔥 Peak energy + full recovery = PR day. Attack every set.',
        military: '🪖 MAXIMUM READINESS. TODAY WE DESTROY RECORDS.',
        hype:     '🚀 FULL ENERGY + FULL RECOVERY = LEGEND STATUS TODAY!! GO!!');
    }

    if (fatigue == FatigueLevel.fatigued) {
      return _style(style,
        friendly: '⚠️ You\'re slightly fatigued — focus on form, not weight 💪',
        strict:   '⚠️ Fatigue detected. Reduce load 20%. Prioritize recovery.',
        military: '🪖 TACTICAL DELOAD. High fatigue. Reduce weight. Execute form.',
        hype:     '💥 Lighter today = HEAVIER tomorrow! Smart athletes adapt!');
    }

    // ── 9. Improving — push harder ────────────────────────────
    if (trend == 'improving') {
      final best = bestPerformingExercise;
      return _style(style,
        friendly: best.isNotEmpty
            ? '📈 You\'ve been on a roll! $best is your best move right now — own it today!'
            : '📈 Your effort has been improving! Keep this momentum going!',
        strict:   '📈 3-session upward trend. Progressive overload today. No excuses.',
        military: '🪖 UPWARD TREND CONFIRMED. CAPITALIZE. ADD WEIGHT TODAY.',
        hype:     '🚀 YOU\'VE BEEN ON ABSOLUTE FIRE!! Ride this wave and SMASH YOUR PR!!');
    }

    // ── 10. Weak muscle focus ─────────────────────────────────
    if (weakMuscle.isNotEmpty) {
      return _style(style,
        friendly: '🎯 Your $weakMuscle is lagging — prioritize it today!',
        strict:   '🎯 Weak point: $weakMuscle. Address the imbalance today.',
        military: '🪖 WEAKNESS DETECTED: $weakMuscle. Eliminate it. Add sets.',
        hype:     '🔥 $weakMuscle is your kryptonite — TODAY WE DESTROY IT!!');
    }

    // ── 11. Weight progression ────────────────────────────────
    if (suggestion == WeightSuggestion.increase) {
      return _style(style,
        friendly: '📈 Ready to level up — add 2.5kg today! You\'ve earned it!',
        strict:   '📈 Performance supports overload. Increase load today.',
        military: '🪖 DATA SAYS INCREASE. ADD WEIGHT. THAT IS THE MISSION.',
        hype:     '🔥 YOUR BODY IS READY TO GROW!! ADD WEIGHT AND MAKE HISTORY!!');
    }

    // ── 12. Milestone push ────────────────────────────────────
    if (streak > 0 && streak % 7 == 0) {
      return _pick([
        '👑 ${streak}-day streak! You are genuinely becoming someone different.',
        '🔱 ${streak} days straight. Most people don\'t make it here.',
        '⚔️ ${streak}-day warrior. The discipline is real now.',
      ]);
    }

    if (isBeginnerPhase) return _beginnerMotivation();

    // ── 13. Time-aware fallback ───────────────────────────────
    return _pick([timeAwareWorkoutNudge, _goalMessage()]);
  }

  /// Streak pressure message — one day away from milestone
  String _streakPressure(String style, int current, int target, String reward) {
    return _style(style,
      friendly: '🔥 ${current}-day streak! ONE more day unlocks the $reward. Don\'t let it slip now!',
      strict:   '📊 ${current} days in. $reward requires 1 more session. Show up.',
      military: '🪖 ${current}D STREAK. 1 DAY FROM $reward. THIS IS NOT THE DAY TO STOP.',
      hype:     '💥 ${current} DAYS AND THE $reward IS ONE SESSION AWAY!! DON\'T YOU DARE QUIT NOW!!');
  }
// resetDailyUsageIfNeeded() removed — MonetizationService._resetDailyCountsIfNeeded() handles this
  String _style(String style, {
    required String friendly, required String strict,
    required String military, required String hype,
  }) {
    switch (style) {
      case 'strict':       return strict;
      case 'military':     return military;
      case 'motivational': return hype;
      default:             return friendly;
    }
  }

  String _pick(List<String> options) {
    if (options.isEmpty) return '';
    return options[_random.nextInt(options.length)];
  }

  void _saveAICache() {
    if (_aiInsight == null) return;
    _saveToPrefs(_Keys.aiCache, jsonEncode(_aiInsight!.toJson()));
  }

  void _loadAICache(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(_Keys.aiCache);
      if (raw == null) return;
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        final insight = AICoachInsight.fromJson(decoded);
        if (insight.cacheDate == _todayStr) _aiInsight = insight;
      }
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════
  // PUBLIC AI API
  // ═══════════════════════════════════════════════════════════
  String get dailyCoachMessage {
    if (!isPremium) return '🔒 Upgrade to Premium for your personalized AI coach!';
    return aiInsight.dailyCoachMessage;
  }

  FatigueLevel get currentFatigueLevel => aiInsight.fatigueLevel;

  String get fatigueMessage {
    if (!isPremium) {
      return aiInsight.fatigueLevel == FatigueLevel.fatigued
          ? '⚠️ High fatigue detected — upgrade for full analysis'
          : '✅ Recovery looks good — upgrade for details!';
    }
    return aiInsight.fatigueMessage;
  }

  String get weightSuggestionMessage {
    if (!isPremium) return '🔒 Upgrade for smart weight suggestions';
    return aiInsight.weightMessage;
  }

  String get weakMuscleInsight {
    if (!isPremium) return '🔒 Upgrade to discover your weak points';
    final w = aiInsight.weakMuscleGroup;
    return w.isEmpty ? '✅ Balanced training detected!' : '🎯 Focus area: $w';
  }

  int get recommendedSetsToday {
    if (!isPremium) return level == 'beginner' ? 3 : 4;
    return aiInsight.recommendedSets;
  }

  double get todayWeightModifier {
    if (!isPremium) return 1.0;
    return aiInsight.weightModifier;
  }

  double applyAIWeight(double baseWeight) {
    if (!isPremium || baseWeight <= 0) return baseWeight;
    return (baseWeight * todayWeightModifier).roundToDouble();
  }

  /// Plateau-aware adaptive weight suggestion
  double adaptiveNextWeight(String exerciseKey) {
    if (!isPremium) return 0;
    final exLogs = _logs.where((l) => l.exercise == exerciseKey).toList();
    if (exLogs.isEmpty) return 20;
    exLogs.sort((a, b) => b.date.compareTo(a.date));
    final last = exLogs.first;

    if (isOnPlateau) {
      // Plateau break: drop to 90%
      return (last.weight * 0.90).roundToDouble().clamp(5, 500);
    }

    final suggestion = _computeWeightSuggestion();
    switch (suggestion) {
      case WeightSuggestion.increase: return (last.weight + 2.5).clamp(0, 500);
      case WeightSuggestion.decrease: return (last.weight - 2.5).clamp(0, 500);
      case WeightSuggestion.maintain: return last.weight;
    }
  }
// — Muscle mapping per exercise —
String _getMuscleFromExercise(String name) {
  final n = name.toLowerCase();

  if (n.contains('bench') || n.contains('chest') || n.contains('push'))
    return 'chest';

  if (n.contains('row') || n.contains('pull') || n.contains('lat'))
    return 'back';

  if (n.contains('squat') ||
      n.contains('leg') ||
      n.contains('lunge') ||
      n.contains('deadlift'))
    return 'legs';

  if (n.contains('shoulder') || n.contains('lateral') || n.contains('press'))
    return 'shoulders';

  if (n.contains('curl') || n.contains('bicep'))
    return 'arms';

  if (n.contains('tricep') || n.contains('pushdown'))
    return 'arms';

  return 'other';
}

String _getCategory(String name) {
  final n = name.toLowerCase();

  if (n.contains("bench") || n.contains("push")) return "Chest";
  if (n.contains("pull") || n.contains("row")) return "Back";
  if (n.contains("squat") || n.contains("leg")) return "Legs";
  if (n.contains("curl")) return "Biceps";
  if (n.contains("tricep")) return "Triceps";

  return "General";
}

String _getEmoji(String name) {
  final n = name.toLowerCase();

  if (n.contains("bench") || n.contains("push")) return "💪";
  if (n.contains("pull") || n.contains("row")) return "🏋️";
  if (n.contains("leg") || n.contains("squat")) return "🦵";
  if (n.contains("cardio")) return "🔥";

  return "🏋️";
}
  // ═══════════════════════════════════════════════════════════
  // GAMIFICATION EVENT SYSTEM — returns structured events, no UI
  // ═══════════════════════════════════════════════════════════

  /// Returns XP event + dopamine message for workout completion
  XPEvent onWorkoutCompleted() {
    const base        = 50;
    final effortBonus = analytics.effortScoreToday >= 80 ? 20 : 0;
    final streakBonus = (_streak.currentStreak / 7).floor() * 10;
    final xp          = base + effortBonus + streakBonus;

    final label = _postWorkoutImpactMessage(analytics.effortScoreToday, xp);
    return XPEvent(type: XPEventType.workoutComplete, xp: xp, label: label);
  }
void onSetLogged(String exercise, double weight, int reps) {
  _addMuscleLoad(exercise, weight, reps);
}
  /// Dopamine-engineered post-workout messages
  String _postWorkoutImpactMessage(double effortScore, int xp) {
    if (effortScore >= 90) {
      return _pick([
        '🔥 ELITE session. That just upgraded your body.',
        '⚡ You\'re becoming dangerous. +$xp XP earned.',
        '💥 That was ELITE. Your future self thanks you.',
        '🏆 100% effort. Sessions like this build champions.',
      ]);
    }
    if (effortScore >= 70) {
      return _pick([
        '💪 Solid session. The work is adding up.',
        '📈 Another deposit in the bank. +$xp XP.',
        '🔥 That session just upgraded you — feel the difference.',
        '⚡ Consistent and strong. Keep this going.',
      ]);
    }
    if (effortScore >= 50) {
      return _pick([
        '✅ You showed up. That\'s already winning.',
        '💙 Not your best — but you did it. +$xp XP.',
        '🔁 Done is better than perfect. Come back stronger.',
        '🙌 You moved. That matters more than you think.',
      ]);
    }
    // Low effort — honest but kind
    return _pick([
      '💙 Tough session. Rest tonight, attack tomorrow.',
      '🔄 Short workout > no workout. Reset and reload.',
      '⚡ Some days are just survival. You survived. +$xp XP.',
    ]);
  }

  /// Returns XP event with high-energy PR celebration
  XPEvent onPRBroken({required String exerciseName}) {
    const base         = 40;
    final plateauBonus = isOnPlateau ? 30 : 0;
    final streakBonus  = _streak.currentStreak >= 14 ? 15 : 0;
    final xp           = base + plateauBonus + streakBonus;

    final label = _prCelebrationMessage(exerciseName, plateauBonus > 0);
    return XPEvent(
      type:  XPEventType.prBroken,
      xp:    xp,
      label: label,
      achievementId: 'pr_${exerciseName.replaceAll(' ', '_').toLowerCase()}',
    );
  }

  /// High-energy PR celebration messages
  String _prCelebrationMessage(String exercise, bool plateauBroken) {
    if (plateauBroken) {
      return _pick([
        '🏆 PLATEAU DESTROYED! New PR on $exercise. The work paid off.',
        '💥 BREAKTHROUGH! $exercise PR — you cracked the plateau!',
        '🔱 Plateau: DEFEATED. $exercise PR. You evolved.',
      ]);
    }
    return _pick([
      '🏆 NEW PR: $exercise! Write this down — you just made history.',
      '⚡ $exercise record SHATTERED! This is why you show up.',
      '🔥 PR on $exercise! Your body just leveled up.',
      '💥 Personal RECORD: $exercise! The proof is in the plates.',
    ]);
  }

  /// Returns XP event for streak day
  XPEvent onStreakMaintained() {
    // Check for milestone
    final milestone = streakMilestones.firstWhereOrNull(
        (m) => m.days == _streak.currentStreak);

    if (milestone != null) {
      return XPEvent(
        type:  XPEventType.streakMilestone,
        xp:    milestone.bonusXP,
        label: '${milestone.emoji} ${milestone.label} — ${milestone.days} day streak!',
        achievementId: 'streak_${milestone.days}',
      );
    }

    return XPEvent(
      type:  XPEventType.streakDay,
      xp:    20,
      label: '🔥 ${_streak.currentStreak}-day streak maintained!',
    );
  }

  /// Returns XP event for completing a full week
  XPEvent? checkPerfectWeek() {
    if (weeklyCompletedDays >= 5) {
      return const XPEvent(
        type:  XPEventType.perfectWeek,
        xp:    100,
        label: '⭐ Perfect Week — 5+ workouts completed!',
        achievementId: 'perfect_week',
      );
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════
  // COMPUTED GETTERS
  // ═══════════════════════════════════════════════════════════
  bool   get isBeginnerPhase    => _streak.totalWorkouts < 7;
  int    get todayIndex         => (DateTime.now().weekday - 1).clamp(0, 6);
  int    get weeklyCompletedDays => _weekPlan.where((d) => d.isCompleted).length;
  double get weeklyScore        => ((weeklyCompletedDays / 7) * 100).clamp(0.0, 100.0);
  double get consistencyScore   => ((_streak.currentStreak / 7).clamp(0.0, 1.0) * 100);
  double get weeklyVolumeTotalKg {
    final now = DateTime.now();
    return _logs.where((l) => now.difference(l.date).inDays < 7)
        .fold(0.0, (s, l) => s + l.weight * l.reps);
  }
  double get weeklyPerformanceScore => analytics.weeklyImprovementPct;
  double get volumeTrend            => analytics.weeklyImprovementPct;

  double get recoveryScore {
    if (_cachedRecoveryScore != null) return _cachedRecoveryScore!.toDouble();
    final score = getOverallRecovery().toDouble();
    _cachedRecoveryScore = score.toInt();
    return score;
  }

  bool get isFatigued {
    _cachedIsFatigued ??= AIEngine.isFatigued(_logs);
    return _cachedIsFatigued!;
  }

  bool get needsDeload => needsDeloadByVolume;
  // ↑ needsDeloadByVolume now uses AnalyticsEngine.shouldDeload (scientific ACWR)

  double get strengthProgress {
    if (_logs.length < 2) return 0;
    final last = _logs.last; final prev = _logs[_logs.length - 2];
    if (prev.weight == 0) return 0;
    return ((last.weight - prev.weight) / prev.weight) * 100;
  }

  Set<String> get completedDays =>
      _weekPlan.where((d) => d.isCompleted).map((d) => d.title).toSet();

  DayPlan get todayPlan {
    if (_weekPlan.isEmpty) return _buildDefaultWeek().first;
    final today = todayIndex;
    if (today >= _weekPlan.length) return _weekPlan.last;
    return _weekPlan[today];
  }

  double get waterProgress {
    final goal = _profile.dailyWaterGoalMl <= 0 ? 1 : _profile.dailyWaterGoalMl;
    return (_profile.currentWaterMl / goal).clamp(0.0, 1.0);
  }

  double get tdee => AIEngine.estimateTDEE(
    weightKg: _profile.weightKg, heightCm: _profile.heightCm,
    age: _profile.age, gender: _profile.gender,
    activityLevel: _profile.activityLevel, goal: _profile.goal,
  );

  String get aiFullAdvice {
    final protein = AIEngine.getProteinTarget(
      bodyWeightKg: _profile.weightKg, goal: _profile.goal,
      fitnessLevel: _profile.level);
    return '${tdee.toStringAsFixed(0)} kcal · $protein protein';
  }

  List<String> get lastWorkoutNames =>
      _history.take(5).map((e) => e.workoutName).toList();
  List<String> get lastWorkouts => lastWorkoutNames;

  String get aiSuggestion {
    if (_aiSuggestion.isNotEmpty) return _aiSuggestion;
    if (isPremium) return aiInsight.dailyCoachMessage;

    // Smart fallback: behavior-aware even for free users
    if (isInactive && daysSinceLastWorkout >= 2) {
      return inactivityNudge;
    }

    // Tease premium with a partial behavior insight
    if (hasFailurePattern) {
      return '💙 Noticed some tough sessions lately — upgrade for your personalized recovery plan 🔒';
    }
    if (musclesSkippedLast7Days.isNotEmpty) {
      final s = musclesSkippedLast7Days.first;
      return '⚠️ Your ${s[0].toUpperCase()}${s.substring(1)} needs attention — upgrade for AI-prioritized plans 🔒';
    }

    if (isBeginnerPhase) return _beginnerMotivation();
    if (_todayMood == MoodType.tired)     return '😴 Tired today — 60% effort still builds the habit!';
    if (_todayMood == MoodType.energetic) return '⚡ You\'re FIRED UP! Push for PRs today! 🔥';
    return AIEngine.getDailySuggestion(
      lastWorkouts: lastWorkoutNames.isEmpty ? ['Push'] : lastWorkoutNames,
      goal: _profile.goal, streak: _streak.currentStreak,
      trainerType: _profile.trainerType, weakMuscle: weakMuscle, logs: _logs,
    );
  }

  String get smartCoach {
    if (_cachedCoachMessage != null) return _cachedCoachMessage!;
    _cachedCoachMessage = isPremium
        ? aiInsight.dailyCoachMessage
        : AIEngine.getSmartCoach(logs: _logs, mood: _todayMood,
            trainerType: _profile.trainerType,
            currentStreak: _streak.currentStreak);
    return _cachedCoachMessage!;
  }

  String get progressionTip {
    if (isPremium) {
      if (isOnPlateau) return '🔄 Plateau! Drop 10% weight, reset reps, rebuild momentum.';
      return aiInsight.weightMessage;
    }
    if (_logs.isEmpty) return '🚀 Start simple. Build consistency first.';
    if (_logs.length < 2) return '📈 Keep going — building momentum!';
    final last = _logs[_logs.length - 1];
    final prev = _logs[_logs.length - 2];
    final ex   = last.exercise.split('_').first;
    final isBW = last.weight == 0;
    if (last.reps < prev.reps) return '⚠️ Performance drop in $ex — rest well tonight';
    if (last.reps > prev.reps) return isBW ? '🔥 More reps in $ex!' : '🔥 Add weight next session';
    return isBW ? '🔁 Add reps in $ex' : '⬆️ Increase weight in $ex';
  }

  String get topMuscleGroup {
    final map = muscleGroupFrequency;
    if (map.isEmpty) return 'None';
    return map.entries.reduce((a, b) => a.value > b.value ? a : b).key;
  }
String getStrengthTrend(String exercise) {
  return AIEngine.getStrengthTrend(_logs, exercise);
}
  Map<String, int> get muscleGroupFrequency {
    final map = <String, int>{};
    for (final day in _weekPlan) {
      for (final ex in day.exercises) {
        if (ex.category.isNotEmpty) map[ex.category] = (map[ex.category] ?? 0) + 1;
      }
    }
    return map;
  }

  Map<String, int> get muscleTrainingFrequency {
    final map = <String, int>{};
    for (final log in _logs) {
      final m = log.exercise.split('_').first.toLowerCase();
      if (m.isNotEmpty) map[m] = (map[m] ?? 0) + 1;
    }
    return map;
  }

  String get weakestMuscle {
    if (isPremium) return aiInsight.weakMuscleGroup;
    final freq = muscleTrainingFrequency;
    if (freq.isEmpty) return '';
    return (freq.entries.toList()..sort((a, b) => a.value.compareTo(b.value))).first.key;
  }
  String get weakMuscle => weakestMuscle;

  bool isMuscleOvertrained(String muscle) =>
      _weekPlan.expand((d) => d.exercises)
          .where((e) => e.category.toLowerCase() == muscle.toLowerCase())
          .length >= 3;

  List<double> get weeklyVolumeData {
    final v = List<double>.filled(7, 0);
    for (final h in _history) {
      try { v[(DateTime.parse(h.date).weekday - 1).clamp(0, 6)] += h.totalVolume; }
      catch (_) {}
    }
    return v;
  }

  List<int> get workoutsByDayOfWeek {
    final c = List<int>.filled(7, 0);
    for (final h in _history) {
      try { c[(DateTime.parse(h.date).weekday - 1).clamp(0, 6)]++; }
      catch (_) {}
    }
    return c;
  }

  String get _todayStr {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2,'0')}-'
           '${n.day.toString().padLeft(2,'0')}';
  }

  String getDayName(int index) {
    const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    return days[index.clamp(0, 6)];
  }

  // ── Comeback / Nudge messages ─────────────────────────────
  String get inactivityNudge {
    final days = daysSinceLastWorkout;
    if (days == 0) return '';
    if (days == 1) {
      return _pick([
        '💡 Yesterday was rest. Today is for action.',
        '⚡ One day off. That\'s it. Back to it today.',
        '🔄 Rest done. Now let\'s build on it.',
      ]);
    }
    if (days == 2) {
      return _pick([
        '⚠️ 2 days off. Your streak is at risk — protect what you\'ve built.',
        '🔴 2 days slipping. Your body is ready. Your excuses aren\'t.',
        '⏰ 48 hours missed. Every champion has a comeback moment — this is yours.',
      ]);
    }
    if (days == 3) {
      return _pick([
        '🔴 3 days missed. Comeback starts NOW — not tomorrow.',
        '💥 3 days? The only way back is through. Let\'s go.',
        '🔁 3 days off. Your muscles have recovered. What\'s the real reason?',
      ]);
    }
    if (days <= 7) {
      return _pick([
        '🔁 $days days away. Your body is recovered — time to remind it who\'s boss.',
        '⚡ $days days gone. Every session is a vote for who you\'re becoming.',
        '💪 $days days since your last session. Your comeback story has one chapter left to write.',
      ]);
    }
    return _pick([
      '👋 $days days? No judgment — greatness doesn\'t have an expiry. Start today.',
      '🔥 $days days away. The gym didn\'t miss you — but your goals did.',
      '💙 $days days. Life happens. But so does growth — when you choose it.',
    ]);
  }

  // ── Session Impact Score ──────────────────────────────────

  /// Session impact score 0–100 based on sets, intensity, volume
  double get sessionImpactScore {
    final today = _weekPlan.elementAtOrNull(todayIndex);
    if (today == null || today.exercises.isEmpty) return 0;

    final setsPlanned   = today.exercises.fold(0, (v, e) => v + e.sets.length);
    final setsCompleted = today.exercises.fold(0, (v, e) =>
        v + e.sets.where((s) => s.done).length);
    final volume = _calcVolume(today);

    if (setsPlanned == 0) return 0;

    // Component 1: completion ratio (40%)
    final completion = (setsCompleted / setsPlanned * 100).clamp(0, 100);

    // Component 2: volume intensity (40%) — normalized to 1000 kg·reps baseline
    const baseline = 1000.0;
    final intensity = (volume / baseline * 100).clamp(0, 100);

    // Component 3: exercise variety (20%) — more exercises = higher score
    final variety = (today.exercises.length / 6 * 100).clamp(0, 100);

    final raw = (completion * 0.4) + (intensity * 0.4) + (variety * 0.2);
    return (raw + _jitter(3)).clamp(0, 97);
  }

  /// Human-readable session impact message
  String get sessionImpactMessage {
    final score = sessionImpactScore;
    if (score == 0) return '';
    if (score >= 85) return _pick([
      '🔥 ELITE session. That just upgraded you.',
      '⚡ You\'re becoming dangerous. Keep it up.',
      '💥 That was ELITE — your body will remember this.',
    ]);
    if (score >= 65) return _pick([
      '💪 Strong session. The work is compounding.',
      '📈 Solid effort. This is how transformations happen.',
      '🏋️ Quality session — you earned your recovery.',
    ]);
    if (score >= 40) return _pick([
      '✅ Decent effort. Build on this tomorrow.',
      '🔄 Steady progress. Consistency beats perfection.',
      '💙 You showed up. That\'s the foundation.',
    ]);
    return _pick([
      '🔁 Short session counts. Come back stronger.',
      '⚡ Done > perfect. Reset and reload tomorrow.',
      '💙 Any movement is progress. See you tomorrow.',
    ]);
  }

  // ═══════════════════════════════════════════════════════════
  // STREAK POPUP
  // ═══════════════════════════════════════════════════════════
  void triggerStreakPopup() {
    showStreakPopup = true; notifyListeners();
    Future.delayed(const Duration(seconds: 3), () {
      showStreakPopup = false; notifyListeners();
    });
  }
void _addMuscleLoad(String exercise, double weight, int reps) {
  final muscle = _getMuscleFromExercise(exercise);

  final load = weight * reps;

  _muscleLoad.update(
    muscle,
    (value) => value + load,
    ifAbsent: () => load,
  );
}
  // ═══════════════════════════════════════════════════════════
  // PLANNER
  // ═══════════════════════════════════════════════════════════
  void updateDayTitle(int i, String title) {
    if (!_isValidDayIndex(i)) return;
    _weekPlan[i].title = title.trim().isEmpty ? 'Workout' : title.trim();
    _safeNotify(); _saveWeekPlan();
  }

  void clearDay(int i) {
    if (!_isValidDayIndex(i)) return;
    _weekPlan[i]..exercises.clear()..isCompleted = false..durationMinutes = 0;
    _safeNotify(); _saveWeekPlan();
  }

  void resetWeek() { _weekPlan = _buildDefaultWeek(); _safeNotify(); _saveWeekPlan(); }

  void toggleRestDay(int i) {
    if (!_isValidDayIndex(i)) return;
    final day = _weekPlan[i];
    day.isRestDay = !day.isRestDay;
    if (day.isRestDay) {
      day.exercises.clear(); day.isCompleted = false; day.durationMinutes = 0;
    }
    _safeNotify(); _saveWeekPlan();
  }

  void generateSmartPlan() {
    startBatch();
    try {
      final result = AIEngine.generateWeeklyPlan(
        goal: _profile.goal, level: _profile.level, logs: _logs,
        weakMuscle: weakMuscle, recoveryScore: recoveryScore.round(),
        fatigued: isFatigued,
      );
      final historyNames = _logs.map((e) => e.exercise.split('_').first).toList();
      final newPlan  = <DayPlan>[];
      final modifier = todayWeightModifier;
      final sets     = recommendedSetsToday;

      for (int i = 0; i < 7; i++) {
        final exNames = result.plan[_dayNames[i]] ?? [];
        if (exNames.isEmpty || exNames.first == 'Rest') {
          newPlan.add(DayPlan(id: _uuid.v4(), dayIndex: i,
              title: 'Rest Day 😴', exercises: [], isRestDay: true));
          continue;
        }
        final type = _splitTypeForDay(i, _profile.level, _profile.goal);
        final exs  = AIEngine.generateDayWorkout(
          goal: _profile.goal, level: _profile.level, type: type,
          history: historyNames, weakMuscle: weakMuscle,
          isBeginner: isBeginnerPhase,
        );
        final planned = exs.map((ex) => PlannedExercise(
          id: _uuid.v4(), baseId: '${ex["name"]}_${ex["type"] ?? ""}',
          name:       ex['name']       as String? ?? 'Exercise',
          category:   ex['muscle']     as String? ?? '',
          emoji:      ex['emoji']      as String? ?? '💪',
          type:       ex['type']       as String? ?? '',
          unit:       ex['unit']       as String? ?? 'kg',
          bodyweight: ex['bodyweight'] as bool?   ?? false,
          sets: List.generate(sets.clamp(1, 6), (_) => ExSet(
            id:     _uuid.v4(),
            reps:   (ex['smartReps'] as int? ?? 10).clamp(1, 50),
            weight: ex['bodyweight'] == true ? 0.0
                : ((ex['smartWeight'] as num?)?.toDouble() ?? 20.0) * modifier,
          )),
        )).toList();
        newPlan.add(DayPlan(id: _uuid.v4(), dayIndex: i,
            title: _formatTitle(type), exercises: planned));
      }
      while (newPlan.length < 7) {
        newPlan.add(DayPlan(id: _uuid.v4(), dayIndex: newPlan.length,
            title: 'Rest Day 😴', exercises: [], isRestDay: true));
      }
      _weekPlan = newPlan.take(7).toList();
      _validateAndFixWeekPlan();
    } catch (e) { debugPrint('generateSmartPlan: $e'); }
    finally { endBatch(); _saveWeekPlan(); }
  }

  void generateWorkoutForDay(String type, int dayIndex) {
  if (!_isValidDayIndex(dayIndex)) return;

  // FIX: Rest day la proper handle karo — empty exercises nako
  if (type.toLowerCase() == 'rest') {
    _weekPlan[dayIndex]
      ..title = 'Rest Day 😴'
      ..exercises.clear()
      ..isRestDay = true
      ..durationMinutes = 0;
    _safeNotify();
    _saveWeekPlan();
    return;
  }

  clearDay(dayIndex);

  final exs = AIEngine.generateDayWorkout(
    goal: _profile.goal,
    level: _profile.level,
    type: type,
    history: lastWorkoutNames,
    weakMuscle: weakMuscle,
    isBeginner: isBeginnerPhase,
  );

  // FIX: WorkoutClassifier varun correct title set karo
  final classifiedType = exs.isNotEmpty
      ? WorkoutClassifier.classifyDayFromExercises(
          exs.map((e) => e['name'] as String? ?? '').toList())
      : type;
  _weekPlan[dayIndex].title = _formatTitle(classifiedType);

  final modifier = todayWeightModifier;
  final sets     = recommendedSetsToday;

  for (final ex in exs) {
    final isBW = ex['bodyweight'] == true;
    _weekPlan[dayIndex].exercises.add(PlannedExercise(
      id: _uuid.v4(),
      baseId: '${ex["name"]}_${ex["type"] ?? ""}',
      name:       ex['name']       as String? ?? '',
      category:   ex['muscle']     as String? ?? '',
      emoji:      ex['emoji']      as String? ?? '💪',
      type:       ex['type']       as String? ?? '',
      unit:       isBW ? 'reps' : (ex['unit'] as String? ?? 'kg'),
      bodyweight: isBW,
      sets: List.generate(sets.clamp(1, 6), (_) => ExSet(
        id:     _uuid.v4(),
        reps:   (ex['smartReps'] as int? ?? 10).clamp(1, 50),
        weight: isBW ? 0.0
            : ((ex['smartWeight'] as num?)?.toDouble() ?? 20.0) * modifier,
      )),
    ));
  }

  _safeNotify();
  _saveWeekPlan();
}

  Future<void> applyGeneratedPlan(WorkoutPlanResult result) async {
    if (_weekPlan.isEmpty) _weekPlan = _buildDefaultWeek(); // ✅ fixed: was length!=7
    for (final entry in result.plan.entries) {
      final idx = _parseDayIndex(entry.key);
      if (idx < 0 || idx >= 7) continue;
      _weekPlan[idx] = DayPlan(
        id: _uuid.v4(), dayIndex: idx, title: _typeFromNames(entry.value),
        exercises: entry.value.where((e) => e != 'Rest').map((e) =>
          PlannedExercise(
            id: e.hashCode.toString(),
            baseId: e.toLowerCase().replaceAll(' ', '_'),
            name: e, category: 'AI', emoji: '💪',
            type: 'strength', unit: 'kg', bodyweight: false,
            sets: [ExSet(id: e.hashCode.toString(), reps: 10, weight: 0)],
          )).toList(),
      );
    }
    _safeNotify(); await _saveWeekPlan();
  }

  // ═══════════════════════════════════════════════════════════
  // EXERCISE OPERATIONS
  // ═══════════════════════════════════════════════════════════
  String getKey(String baseId) => baseId.toLowerCase().trim();

  PlannedExercise? _findEx(int dayIndex, String exId) {
    if (!_isValidDayIndex(dayIndex)) return null;
    final list = _weekPlan[dayIndex].exercises;
    if (list.isEmpty) return null;
    try { return list.firstWhere((e) => e.id == exId); }
    catch (_) { return list.isNotEmpty ? list.first : null; }
  }

  void addExercise(int dayIndex, {
    required String name, required String category, required String emoji,
    String type = '', String unit = 'kg', required String baseId,
    bool isBodyweight = false,
  }) {
    if (!_isValidDayIndex(dayIndex) || name.trim().isEmpty) return;
    final day = _weekPlan[dayIndex];
    day.isRestDay = false;
    final key = getKey(baseId);
    if (day.exercises.any((e) => getKey(e.baseId) == key)) return;
    day.exercises.add(PlannedExercise(
      id: _uuid.v4(), name: name.trim(), category: category,
      emoji: emoji.isEmpty ? '💪' : emoji, type: type,
      unit: isBodyweight ? 'reps' : (unit.isEmpty ? 'kg' : unit),
      baseId: baseId, bodyweight: isBodyweight,
      sets: [ExSet(id: _uuid.v4(), reps: 10, weight: isBodyweight ? 0.0 : 20.0)],
    ));
    _safeNotify(); _saveWeekPlan();
  }

  void removeExercise(int dayIndex, String exId) {
    if (!_isValidDayIndex(dayIndex)) return;
    _weekPlan[dayIndex].exercises.removeWhere((e) => e.id == exId);
    _safeNotify(); _saveWeekPlan();
  }

  void addSet(int dayIndex, String exId) {
    final ex = _findEx(dayIndex, exId); if (ex == null) return;
    final last = ex.sets.isNotEmpty ? ex.sets.last : null;
    ex.sets.add(ExSet(id: _uuid.v4(), reps: last?.reps ?? 10,
        weight: ex.bodyweight ? 0.0 : (last?.weight ?? 20.0)));
    _safeNotify(); _saveWeekPlan();
  }

  void removeSet(int dayIndex, String exId, String setId) {
    final ex = _findEx(dayIndex, exId);
    if (ex == null || ex.sets.length <= 1) return;
    ex.sets.removeWhere((s) => s.id == setId);
    _syncLog(dayIndex, exId); _safeNotify(); _saveWeekPlan();
  }

  void updateSet(
  int dayIndex,
  String exId,
  String setId, {
  int? reps,
  double? weight,
}) {
  final ex = _findEx(dayIndex, exId);
  if (ex == null) return;

  final s = ex.sets.where((s) => s.id == setId).firstOrNull;
  if (s == null) return;

  // 👉 Update reps safely
  if (reps != null) {
    s.reps = reps.clamp(0, 999);
  }

  // 👉 Update weight safely
  if (weight != null) {
    if (weight > 500) return;
    s.weight = weight.clamp(0, 500);
  }

  // 👉 FINAL VALUES (important)
  final finalReps = s.reps;
  final finalWeight = s.weight;

  // 👉 AI LOAD TRACK (ONLY VALID DATA)
  if (finalReps > 0 && finalWeight > 0) {
    onSetLogged(ex.name, finalWeight.toDouble(), finalReps);
  }

  // 👉 Normal flow
  _safeNotify();
  _saveWeekPlan();

  // 👉 Sync logs if completed
  if (s.done) {
    _syncLog(dayIndex, exId);
  }
}

  void toggleSetDone(int dayIndex, String exId, String setId) {
    final ex = _findEx(dayIndex, exId); if (ex == null) return;
    final s = ex.sets.where((s) => s.id == setId).firstOrNull;
    if (s == null) return;
    s.done = !s.done;
    _safeNotify(); _saveWeekPlan(); _syncLog(dayIndex, exId);
  }

  void _syncLog(int dayIndex, String exId) {
  final ex = _findEx(dayIndex, exId);
  if (ex == null) return;

  final key      = getKey(ex.baseId);
  final doneSets = ex.sets.where((s) => s.done).toList();
  final now      = DateTime.now();

  _logs.removeWhere((l) =>
      l.exercise == key && l.date.year == now.year &&
      l.date.month == now.month && l.date.day == now.day);

  if (doneSets.isNotEmpty) {
    final best = doneSets.reduce((a, b) =>
        (ex.unit == 'reps' ? a.reps >= b.reps : a.weight >= b.weight) ? a : b);

    // FIX 3: WorkoutClassifier varun muscle detect karo
    // category empty asel tari exercise name varun classify karo
    String muscleKey = _normalizeMuscle(ex.category);
    if (muscleKey.isEmpty || muscleKey == 'other') {
      // Custom exercise — name varun classify
      final detectedMuscle = WorkoutClassifier.classifyMuscle(ex.name);
      muscleKey = _normalizeMuscle(detectedMuscle);
    }

    if (muscleKey.isNotEmpty && muscleKey != 'other') {
      _lastMuscleTrained.update(
        muscleKey,
        (existing) => now.isAfter(existing) ? now : existing,
        ifAbsent: () => now,
      );
      _saveLastMuscleTrained();
    }

    final newLog = WorkoutLog(
      exercise: key,
      date: now,
      weight:  best.weight.clamp(0, 500),
      reps:    best.reps.clamp(0, 999),
      minutes: ex.unit == 'min' ? best.weight.toInt() : 0,
      // FIX: muscleGroup correct set karo
      muscleGroup: muscleKey.isNotEmpty ? muscleKey : null,
    );
    _logs.add(newLog);
    _logs.sort((a, b) => a.date.compareTo(b.date));

    if (_logs.length > _maxLogs) {
      _logs = _logs.sublist(_logs.length - _maxLogs);
    }

    // Near-miss cache update
    final pr = getPR(key, ex.unit);
    if (pr > 0) {
      final val = ex.unit == 'reps' ? best.reps.toDouble()
          : ex.unit == 'min' ? best.weight
          : best.weight;
      final gap = pr - val;
      final gapPct = gap / pr;
      if (gap > 0 && gapPct <= 0.10) {
        _nearMissCache[key] = {
          'value': val, 'gap': gap, 'unit': ex.unit, 'date': _todayStr,
        };
      }
    }
  }

  _invalidateCache();
  _saveLogs();
}

  // ═══════════════════════════════════════════════════════════
  // PROGRESSION ENGINE
  // ═══════════════════════════════════════════════════════════
  ProgressionResult analyzeProgression(PlannedExercise ex) {
    final validSets = ex.sets.where((s) => s.reps > 0).toList();

    if (validSets.isEmpty) {
      return ProgressionResult(
        message:    'Start your first set 💪',
        nextWeight: ex.bodyweight ? 0 : 20,
        targetReps: 10,
      );
    }

    final last = validSets.last;

    if (last.reps <= 5) {
      return ProgressionResult(
        message:    '⚠️ Too heavy — reduce weight',
        nextWeight: (last.weight - 2.5).clamp(0, 500),
        targetReps: 8,
      );
    }
    if (last.reps >= 12) {
      return ProgressionResult(
        message:    '🔥 Increase weight next set!',
        nextWeight: (last.weight + 2.5).clamp(0, 500),
        targetReps: 8,
      );
    }
    return ProgressionResult(
      message:    '💪 Perfect range — control it',
      nextWeight: last.weight,
      targetReps: last.reps + 1,
    );
  }

  String getTrainerMessage(PlannedExercise ex) => analyzeProgression(ex).message;
  double getSuggestedWeight(PlannedExercise ex) => analyzeProgression(ex).nextWeight;

  // ═══════════════════════════════════════════════════════════
  // LOGS & PR
  // ═══════════════════════════════════════════════════════════
  List<WorkoutLog> getLogsForExercise(String key) =>
      _logs.where((l) => l.exercise == key).toList();
  List<WorkoutLog> getHistory(String key) => getLogsForExercise(key);

  double getPR(String key, String unit) {
    final ex = _logs.where((l) =>
        l.exercise == key && l.weight >= 0 && l.weight <= 500).toList();
    if (ex.isEmpty) return 0;
    if (unit == 'reps') return ex.map((l) => l.reps.toDouble()).reduce((a,b) => a>b?a:b);
    if (unit == 'min')  return ex.map((l) => l.minutes.toDouble()).reduce((a,b) => a>b?a:b);
    return ex.map((l) => l.weight).reduce((a, b) => a > b ? a : b);
  }

  int getPRReps(String key) {
    final ex = _logs.where((l) => l.exercise == key).toList();
    if (ex.isEmpty) return 0;
    return (ex..sort((a, b) => b.weight.compareTo(a.weight))).first.reps;
  }

  String? getPRDate(String key, String unit) {
    final ex = getLogsForExercise(key); if (ex.isEmpty) return null;
    final best = unit == 'reps' ? ex.reduce((a,b) => a.reps > b.reps ? a : b)
               : unit == 'min'  ? ex.reduce((a,b) => a.minutes > b.minutes ? a : b)
               :                   ex.reduce((a,b) => a.weight > b.weight ? a : b);
    return '${best.date.day}/${best.date.month}/${best.date.year}';
  }

  bool isNewPR(String key, double weight, int reps, String unit,
      {int minutes = 0}) {
    final ex = _logs.where((l) => l.exercise == key).toList();
    if (ex.isEmpty) return true;
    final maxW    = ex.map((e) => e.weight).reduce((a,b) => a>b?a:b);
    final maxReps = ex.where((e) => e.weight == weight)
        .map((e) => e.reps).fold(0, (a, b) => a > b ? a : b);
    return weight > maxW || (weight == maxW && reps > maxReps);
  }
  /// Structured PR check — returns PRResult with outcome + context
PRResult checkPRResult(String key, double weight, int reps, String unit) {
  final logs = _logs.where((l) => l.exercise == key).toList();

  // First ever log
  if (logs.isEmpty) {
    return PRResult(
      outcome:     PROutcome.first,
      newWeight:   weight,
      newReps:     reps,
      prevWeight:  0,
      prevReps:    0,
      improvePct:  0,
    );
  }

  final prevWeight = getPR(key, unit);
  final prevReps   = getPRReps(key);

  // True PR: weight up, OR same weight + more reps
  if (weight > prevWeight ||
      (weight >= prevWeight && reps > prevReps)) {
    final pct = prevWeight > 0
        ? ((weight - prevWeight) / prevWeight * 100)
        : (prevReps > 0 ? ((reps - prevReps) / prevReps * 100) : 5.0);
    return PRResult(
      outcome:    PROutcome.pr,
      newWeight:  weight,
      newReps:    reps,
      prevWeight: prevWeight,
      prevReps:   prevReps,
      improvePct: pct.clamp(0, 999),
    );
  }

  // Match: exact same weight + reps
  if ((weight - prevWeight).abs() < 0.01 && reps == prevReps) {
    return PRResult(
      outcome:    PROutcome.match,
      newWeight:  weight,
      newReps:    reps,
      prevWeight: prevWeight,
      prevReps:   prevReps,
      improvePct: 0,
    );
  }

  // Drop: anything lower
  final dropPct = prevWeight > 0
      ? ((prevWeight - weight) / prevWeight * 100)
      : 0.0;
  return PRResult(
    outcome:    PROutcome.drop,
    newWeight:  weight,
    newReps:    reps,
    prevWeight: prevWeight,
    prevReps:   prevReps,
    improvePct: -(dropPct.clamp(0.0, 100.0)),
  );
}

String _getMuscleGroup(String exercise) {
  final e = exercise.toLowerCase();

  if (e.contains('bench') || e.contains('chest')) return 'chest';
  if (e.contains('lat') || e.contains('pull') || e.contains('row')) return 'back';
  if (e.contains('squat') || e.contains('leg')) return 'legs';
  if (e.contains('shoulder') || e.contains('press')) return 'shoulders';
  if (e.contains('bicep') || e.contains('curl')) return 'arms';
  if (e.contains('tricep')) return 'arms';
  if (e.contains('abs') || e.contains('crunch')) return 'core';

  return 'other';
}
  void addLog(String key, double weight, int reps, DateTime date,
      {int minutes = 0}) {
    _logs.removeWhere((l) =>
        l.exercise == key && l.date.year == date.year &&
        l.date.month == date.month && l.date.day == date.day);
    _logs.add(WorkoutLog(
  exercise: key,
  date: date,
  weight: weight.clamp(0, 500),
  reps: reps.clamp(0, 999),
  minutes: minutes,
  muscleGroup: _getMuscleGroup(key), // 🔥 IMPORTANT LINE
));
    _logs.sort((a, b) => a.date.compareTo(b.date));
    if (_logs.length > _maxLogs) _logs = _logs.sublist(_logs.length - _maxLogs);
    _invalidateCache(); notifyListeners(); _saveLogs();
  }

  List<FlSpot> getProgressSpots(String key, String unit) {
    final filtered = _logs
        .where((l) => l.exercise == key && l.weight >= 0 && l.weight <= 500)
        .toList()..sort((a, b) => a.date.compareTo(b.date));
    if (filtered.isEmpty) return [];
    final spots = <FlSpot>[];
    for (int i = 0; i < filtered.length; i++) {
      final log = filtered[i];
      double y = unit == 'reps' ? log.reps.toDouble()
               : unit == 'min'  ? log.minutes.toDouble()
               : log.weight;
      if (y <= 0 && spots.isNotEmpty) y = spots.last.y;
      if (y >= 0) spots.add(FlSpot(i.toDouble(), y));
    }
    if (spots.isEmpty) return [];
    return spots.length == 1
        ? [FlSpot(0, spots.first.y), FlSpot(1, spots.first.y)]
        : spots;
  }

  double calculateNextWeight({
    required double currentWeight, required int reps, required int targetReps,
  }) {
    if (currentWeight <= 0) return 20;
    if (reps >= targetReps + 2) return currentWeight + 2.5;
    if (reps <= targetReps - 3) return (currentWeight - 2.5).clamp(0, 999);
    return currentWeight;
  }

  // ═══════════════════════════════════════════════════════════
  // WORKOUT COMPLETION
  // ═══════════════════════════════════════════════════════════
  Future<List<AppBadge>> markDayComplete(int dayIndex, int durationMin) async {
    if (!_isValidDayIndex(dayIndex)) return [];
    final day = _weekPlan[dayIndex];
    if (day.isCompleted) return [];

    day.isCompleted     = true;
    day.durationMinutes = durationMin.clamp(0, 600);
    triggerStreakPopup();

    _history.insert(0, HistoryEntry(
      id: _uuid.v4(), date: _todayStr, workoutName: day.title,
      durationMinutes: durationMin, totalVolume: _calcVolume(day),
      exerciseCount: day.exercises.length,
      setCount: day.exercises.fold(0, (v, e) => v + e.sets.length),
    ));

    _streak.totalWorkouts++;
    _streak.currentStreak++;
    _streak.lastWorkoutDate = _todayStr;
    if (_streak.currentStreak > _streak.longestStreak) {
      _streak.longestStreak = _streak.currentStreak;
    }

    final newBadges = BadgeSystem.checkNewBadges(_streak, _streak.earnedBadges);
    _streak.earnedBadges.addAll(newBadges.map((b) => b.id));

    // Record performance in AI memory
    _recordPerformancePattern(day);

    // ✅ NEW: Auto-save weekly memory when all planned days complete
    // This gives AI full context for next week's plan generation
    final plannedCount   = _weekPlan.where((d) => !d.isRestDay).length;
    final completedCount = _weekPlan.where((d) => d.isCompleted).length;
    if (completedCount >= plannedCount && plannedCount > 0) {
      await saveCurrentWeekAsMemory();
    }

    // Clear near-miss cache — fresh slate for next session
    _nearMissCache.clear();

    // ✅ Behavior-based paywall — check after workout milestones
    // UI reads pendingPaywallTrigger and shows PaywallSheet if set
    _pendingPaywallTrigger = await checkPaywallTrigger();

    _aiInsight         = null;
    _analyticsSnapshot = null;
    _invalidateCache();
    notifyListeners();
    await Future.wait([_saveWeekPlan(), _saveStreak(), _saveHistory()]);
    return newBadges;
  }

  double _calcVolume(DayPlan day) {
    double total = 0;
    for (final ex in day.exercises) {
      for (final s in ex.sets) {
        if (!s.done) continue;
        if (ex.unit == 'min')                        total += s.weight.clamp(0, 600);
        else if (ex.bodyweight || ex.unit == 'reps') total += s.reps.clamp(0, 999).toDouble();
        else total += (s.weight * (s.reps > 0 ? s.reps : 1)).clamp(0, 100000);
      }
    }
    return total;
  }

  // ═══════════════════════════════════════════════════════════
  // WATER & PROFILE
  // ═══════════════════════════════════════════════════════════
  void addWater(int ml) {
    final max = (_profile.dailyWaterGoalMl * 2).clamp(1000, 10000);
    _profile.currentWaterMl = (_profile.currentWaterMl + ml).clamp(0, max);
    _safeNotify(); _saveProfile();
  }

  void updateProfile(UserProfile updated) {
    _profile = updated; _invalidateCache(); notifyListeners(); _saveProfile();
  }

  void setWaterGoal(int ml) {
    _profile.dailyWaterGoalMl = ml.clamp(500, 10000);
    _safeNotify(); _saveProfile();
  }

  void resetWater() { _profile.currentWaterMl = 0; _safeNotify(); _saveProfile(); }

  void updateSetting(String key, dynamic value) {
    if (value == null) return;
    _settings[key] = value; notifyListeners(); _saveSettings();
  }

  Future<void> setMood(MoodType mood) async {
    _todayMood = mood;
    _aiInsight = null; _analyticsSnapshot = null;
    _invalidateCache(); notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_Keys.mood, mood.name);
    } catch (_) {}
  }

  void toggleFavorite(String name) {
    if (name.isEmpty) return;
    _favorites.contains(name) ? _favorites.remove(name) : _favorites.add(name);
    notifyListeners(); _saveFavorites();
  }

  void addCustomExercise({
  required int dayIndex,
  required String name,
  required String category,
  required String emoji,
  required bool isBodyweight,
}) {
  // FIX: category empty asel tar WorkoutClassifier varun auto-detect
  String resolvedCategory = category;
  if (category.isEmpty || category.toLowerCase() == 'custom') {
    final detected = WorkoutClassifier.classifyMuscle(name);
    resolvedCategory = detected.isNotEmpty ? detected : 'Custom';
  }

  // Capitalize first letter
  if (resolvedCategory.isNotEmpty) {
    resolvedCategory = resolvedCategory[0].toUpperCase() +
        resolvedCategory.substring(1);
  }

  addExercise(
    dayIndex,
    name: name,
    category: resolvedCategory,
    emoji: emoji.isEmpty ? '💪' : emoji,
    type: isBodyweight ? 'Bodyweight' : WorkoutClassifier.classifyExercise(name),
    unit: isBodyweight ? 'reps' : 'kg',
    isBodyweight: isBodyweight,
    baseId: name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_'),
  );
}

  // ═══════════════════════════════════════════════════════════
  // PERSISTENCE
  // ═══════════════════════════════════════════════════════════
  Future<void> _saveToPrefs(String key, String val) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(key, val);
    } catch (e) { debugPrint('save($key): $e'); }
  }

  Future<void> _saveWeekPlan() async {
    try {
      final data = _weekPlan.map((d) => d.toJson()).toList();
      final encoded = jsonEncode(data);
      await _saveToPrefs(_Keys.weekPlan, encoded);
      _workoutBox?.put(_Keys.hiveWeekPlan, encoded);
      debugPrint('💾 WEEKLY PLAN SAVED: \${_weekPlan.length} days');
    } catch (e) { debugPrint('❌ _saveWeekPlan: $e'); }
  }

  void _saveProfile()         => _saveToPrefs(_Keys.profile,
      jsonEncode(_profile.toJson()));
  Future<void> _saveStreak()  async => _saveToPrefs(_Keys.streak,
      jsonEncode(_streak.toJson()));
  Future<void> _saveHistory() async => _saveToPrefs(_Keys.history,
      jsonEncode(_history.map((h) => h.toJson()).toList()));
  void _saveFavorites()       => _saveToPrefs(_Keys.favorites,
      jsonEncode(_favorites.toList()));
  void _saveSettings()        => _saveToPrefs(_Keys.settings,
      jsonEncode(_settings));
  void _saveLogs()            => _saveToPrefs(_Keys.logs,
      jsonEncode(_logs.map((l) => l.toJson()).toList()));
  void _saveMeasurements()    => _saveToPrefs(_Keys.measurements,
      jsonEncode(_measurements.map((m) => m.toJson()).toList()));

  List<DayPlan> _loadWeekPlan(SharedPreferences prefs) {
    // ✅ FIX: accept 1-7 days (AI plans can be 3-6 days)
    // Old: if (plans.length == 7) → AI plans (4 days) were silently discarded on restart

    // Try Hive first (faster)
    try {
      final hiveRaw = _workoutBox?.get(_Keys.hiveWeekPlan);
      List? hiveList;
      if (hiveRaw is String) hiveList = jsonDecode(hiveRaw) as List?;
      else if (hiveRaw is List) hiveList = hiveRaw;
      if (hiveList != null && hiveList.isNotEmpty) {
        final plans = hiveList.map<DayPlan?>((j) {
          try { return DayPlan.fromJson(Map<String,dynamic>.from(j as Map)); }
          catch (_) { return null; }
        }).whereType<DayPlan>().toList();
        if (plans.isNotEmpty) {
          debugPrint('✅ WEEKLY PLAN LOADED from Hive: \${plans.length} days');
          return plans;
        }
      }
    } catch (e) { debugPrint('Hive load: $e'); }

    // Fallback to SharedPreferences
    try {
      final wJson = prefs.getString(_Keys.weekPlan);
      if (wJson != null) {
        final d = jsonDecode(wJson);
        if (d is List) {
          final plans = d.map<DayPlan?>((j) {
            try { return DayPlan.fromJson(j as Map<String,dynamic>); }
            catch (_) { return null; }
          }).whereType<DayPlan>().toList();
          if (plans.isNotEmpty) {
            debugPrint('✅ WEEKLY PLAN LOADED from Prefs: \${plans.length} days');
            return plans;
          }
        }
      }
    } catch (e) { debugPrint('Prefs load: $e'); }

    debugPrint('⚠️ No saved plan — default week');
    return _buildDefaultWeek();
  }

  void _validateAndFixWeekPlan() {
    if (_weekPlan.isEmpty) {
      _weekPlan = _buildDefaultWeek();
      return;
    }
    // ✅ FIX: AI returns 3-6 days — pad to 7 with rest days instead of resetting
    // Old code: if length != 7 → wipe everything → AI plan lost!
    while (_weekPlan.length < 7) {
      _weekPlan.add(DayPlan(
        id:        _uuid.v4(),
        dayIndex:  _weekPlan.length,
        title:     'Rest Day 😴',
        exercises: [],
        isRestDay: true,
      ));
    }
    // Trim if somehow > 7
    if (_weekPlan.length > 7) _weekPlan = _weekPlan.sublist(0, 7);
    // Ensure dayIndex is always correct
    for (int i = 0; i < _weekPlan.length; i++) _weekPlan[i].dayIndex = i;
  }
// ── applyAISuggestion ─────────────────────────────────────────
// tools_screen.dart line 681 वर call होतो
void applyAISuggestion(int dayIndex, List<String> suggestions) {
  if (!_isValidDayIndex(dayIndex)) return;
  _weekPlan[dayIndex].isRestDay = false;
  for (final name in suggestions) {
    if (name.isEmpty) continue;
    addExercise(
      dayIndex,
      name: name,
      category: WorkoutClassifier.classifyMuscle(name).isNotEmpty
          ? (() {
              final m = WorkoutClassifier.classifyMuscle(name);
              return m[0].toUpperCase() + m.substring(1);
            })()
          : 'AI',
      emoji: '💪',
      baseId: name.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_'),
    );
  }
}

// ── addMeasurement ────────────────────────────────────────────
// body_measurement_screen.dart line 45 वर call होतो
void addMeasurement(BodyMeasurement m) {
  _measurements.insert(0, m);
  notifyListeners();
  _saveMeasurements();
}

// ── deleteMeasurement ─────────────────────────────────────────
// body_measurement_screen.dart line 116 वर call होतो
void deleteMeasurement(String id) {
  _measurements.removeWhere((m) => m.id == id);
  notifyListeners();
  _saveMeasurements();
}
  void _resetToDefaults() {
    _weekPlan = _buildDefaultWeek(); _profile = UserProfile();
    _streak = StreakData(); _history = []; _logs = [];
    _measurements = []; _favorites = {};
    _lastMuscleTrained = {}; _perfMemory = [];
    _smoothedReadiness = null;
    _smoothedFatigue   = null;
    _smoothedIntensity = null;
    _nearMissCache     = {};
  }

  T? _decode<T>(SharedPreferences p, String key,
      T Function(Map<String, dynamic>) fn) {
    final s = p.getString(key); if (s == null) return null;
    try {
      final d = jsonDecode(s);
      if (d is Map<String, dynamic>) return fn(d);
      return null;
    } catch (_) { return null; }
  }

  List<T> _decodeList<T>(SharedPreferences p, String key,
      T Function(Map<String, dynamic>) fn) {
    final s = p.getString(key); if (s == null) return [];
    try {
      final d = jsonDecode(s); if (d is! List) return [];
      return d.map<T?>((j) {
        try {
          if (j is Map<String, dynamic>) return fn(j);
          if (j is Map) return fn(Map<String, dynamic>.from(j));
          return null;
        } catch (_) { return null; }
      }).whereType<T>().toList();
    } catch (_) { return []; }
  }

  List<DayPlan> _buildDefaultWeek() {
  const titles = [
    'Push Day',   // Mon
    'Pull Day',   // Tue
    'Legs Day',   // Wed
    'Rest Day 😴',// Thu
    'Push Day',   // Fri
    'Pull Day',   // Sat
    'Rest Day 😴',// Sun
  ];
  const rests = [false, false, false, true, false, false, true];

  return List.generate(7, (i) => DayPlan(
    id:        _uuid.v4(),
    dayIndex:  i,
    title:     titles[i],
    exercises: [],
    isRestDay: rests[i],
  ));
}

  bool _isValidDayIndex(int i) => i >= 0 && i < _weekPlan.length;

  static const List<String> _dayNames = [
    'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
  ];

  String _splitTypeForDay(int i, String level, String goal) {
  // ── Beginner: Full Body 3 days ──
  if (level == 'beginner') {
    const s = ['Full', 'Rest', 'Full', 'Rest', 'Full', 'Rest', 'Rest'];
    return s[i.clamp(0, 6)];
  }

  // ── Advanced Muscle Gain: 6-day PPLPPL ──
  if (level == 'advanced' && goal == 'muscle_gain') {
    const s = ['Push', 'Pull', 'Legs', 'Push', 'Pull', 'Legs', 'Rest'];
    return s[i.clamp(0, 6)];
  }

  // ── Default (Intermediate): PPL + Rest ──
  // Mon=Push, Tue=Pull, Wed=Legs, Thu=Rest, Fri=Push, Sat=Pull, Sun=Rest
  const s = ['Push', 'Pull', 'Legs', 'Rest', 'Push', 'Pull', 'Rest'];
  return s[i.clamp(0, 6)];
}

  String _formatTitle(String t) {
    switch (t.toLowerCase()) {
      case 'push': return 'Push Day';  case 'pull': return 'Pull Day';
      case 'legs': return 'Legs Day';  case 'rest': return 'Rest Day';
      case 'full': return 'Full Body'; case 'core': return 'Core Day';
      default:     return t.isNotEmpty ? t : 'Workout';
    }
  }

  int _parseDayIndex(String day) {
    const m = {'monday':0,'tuesday':1,'wednesday':2,'thursday':3,
               'friday':4,'saturday':5,'sunday':6};
    return m[day.toLowerCase()] ?? -1;
  }

  String _typeFromNames(List<String> names) {
    final all = names.join(' ').toLowerCase();
    if (all.contains('push') || all.contains('chest'))   return 'Push';
    if (all.contains('pull') || all.contains('back'))    return 'Pull';
    if (all.contains('squat') || all.contains('leg'))    return 'Legs';
    if (all.contains('shoulder'))                        return 'Shoulders';
    if (all.contains('bicep') || all.contains('tricep')) return 'Arms';
    return 'Workout';
  }

  String _beginnerMotivation() {
    const msgs = [
      '🚀 Day 1 — The hardest part is starting. You already won by showing up.',
      '🔥 Day 2 — Yesterday counts. Two in a row means a pattern is forming.',
      '💪 Day 3 — Third session. Your nervous system is beginning to adapt.',
      '⚡ Day 4 — Four days. Discipline is overriding motivation. That\'s growth.',
      '🏆 Day 5 — Five days in. Most people quit at day 3. You didn\'t.',
      '😈 Day 6 — One more. Tomorrow you\'ll be someone who completed a full week.',
      '👑 Day 7 — FULL WEEK COMPLETE. The version of you who started day 1 is gone.',
    ];
    return msgs[(_streak.totalWorkouts - 1).clamp(0, msgs.length - 1)];
  }

  String _goalMessage() {
    final options = <String, List<String>>{
      'fat_loss': [
        '🔥 Burn mode ON — push the pace today!',
        '💦 Fat burning session — keep rest short!',
        '⚡ Metabolic conditioning — go hard!',
      ],
      'muscle_gain': [
        '💪 Mind-muscle connection — quality reps!',
        '🏋️ Hypertrophy focus — slow, controlled tempo.',
        '📈 Volume day — squeeze every rep!',
      ],
      'strength': [
        '🏋️ Heavy day — attack the big lifts!',
        '💪 Strength focus — compound movements first.',
        '⚡ Power session — warm up thoroughly!',
      ],
    };
    final list = options[_profile.goal] ?? ['⚡ Another day, another session. Let\'s go!'];
    return _pick(list);
  }
}

// ═══════════════════════════════════════════════════════════════
// EXTENSIONS
// ═══════════════════════════════════════════════════════════════
extension ListFirstOrNull<T> on List<T> {
  T? get firstOrNull => isEmpty ? null : first;

  T? firstWhereOrNull(bool Function(T) test) {
    for (final e in this) { if (test(e)) return e; }
    return null;
  }

  List<T> takeLast(int n) {
    if (n <= 0 || isEmpty) return [];
    return length <= n ? toList() : sublist(length - n);
  }
}

extension ListElementAt<T> on List<T> {
  T? elementAtOrNull(int index) {
    if (index < 0 || index >= length) return null;
    return this[index];
  }
}
