// lib/providers/workout_provider.dart
// ══════════════════════════════════════════════════════════
// Owns: sets, logs, PR tracking, weekly stats
// Extracted from: app_provider.dart (was 3670 lines)
// Depends on: nothing else in providers (no circular deps)
// ══════════════════════════════════════════════════════════

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../models/workout_log.dart';
import '../core/enums/pr_outcome.dart';
import '../services/ai_engine.dart';

// ─────────────────────────────────────────────────────────
// PR RESULT — value object
// ─────────────────────────────────────────────────────────
class PRResult {
  final PROutcome outcome;
  final double    newWeight;
  final int       newReps;
  final double    prevWeight;
  final int       prevReps;
  final double    improvePct;

  const PRResult({
    required this.outcome,
    required this.newWeight,
    required this.newReps,
    required this.prevWeight,
    required this.prevReps,
    required this.improvePct,
  });

  bool get isPR    => outcome.isPR;
  bool get isFirst => outcome.isFirst;
  bool get isMatch => outcome.isMatch;

  static PRResult compute({
    required double newWeight,
    required int    newReps,
    required double prevWeight,
    required int    prevReps,
    required String unit,
  }) {
    // First ever
    if (prevWeight == 0 && prevReps == 0) {
      return PRResult(
        outcome: PROutcome.first, newWeight: newWeight, newReps: newReps,
        prevWeight: 0, prevReps: 0, improvePct: 0,
      );
    }

    // Weight PR
    if (newWeight > prevWeight + 0.01) {
      final pct = prevWeight > 0
          ? ((newWeight - prevWeight) / prevWeight * 100)
          : 0.0;
      return PRResult(
        outcome: PROutcome.pr, newWeight: newWeight, newReps: newReps,
        prevWeight: prevWeight, prevReps: prevReps,
        improvePct: pct.clamp(0, 999),
      );
    }

    // Rep PR (same weight, more reps)
    if ((newWeight - prevWeight).abs() < 0.01 && newReps > prevReps) {
      return PRResult(
        outcome: PROutcome.repPR, newWeight: newWeight, newReps: newReps,
        prevWeight: prevWeight, prevReps: prevReps, improvePct: 0,
      );
    }

    // Volume PR
    final newVol  = newWeight * newReps;
    final prevVol = prevWeight * prevReps;
    if (newVol > prevVol * 1.01) {
      final pct = ((newVol - prevVol) / prevVol * 100).clamp(0.0, 999.0);
      return PRResult(
        outcome: PROutcome.volumePR, newWeight: newWeight, newReps: newReps,
        prevWeight: prevWeight, prevReps: prevReps, improvePct: pct,
      );
    }

    // Match
    if ((newWeight - prevWeight).abs() < 0.01 && newReps == prevReps) {
      return PRResult(
        outcome: PROutcome.match, newWeight: newWeight, newReps: newReps,
        prevWeight: prevWeight, prevReps: prevReps, improvePct: 0,
      );
    }

    return PRResult(
      outcome: PROutcome.drop, newWeight: newWeight, newReps: newReps,
      prevWeight: prevWeight, prevReps: prevReps, improvePct: 0,
    );
  }
}

// ─────────────────────────────────────────────────────────
// WORKOUT PROVIDER
// ─────────────────────────────────────────────────────────
class WorkoutProvider extends ChangeNotifier {
  static const _keyLogs = 'workout_logs_v4';
  static const _keyPRs  = 'pr_data_v2';

  final _uuid = const Uuid();

  // ── State ──────────────────────────────────────────────
  List<WorkoutLog>          _logs        = [];
  Map<String, double>       _prWeights   = {}; // exerciseKey → best weight
  Map<String, int>          _prReps      = {}; // exerciseKey → best reps at that weight
  bool                      _loading     = true;

  // ── Getters ────────────────────────────────────────────
  List<WorkoutLog>    get logs        => List.unmodifiable(_logs);
  bool                get isLoading   => _loading;

  // ─────────────────────────────────────────────────────────
  // INIT
  // ─────────────────────────────────────────────────────────
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _loadLogs(prefs);
      _loadPRs(prefs);
    } catch (e) {
      debugPrint('WorkoutProvider.init error: $e');
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  void _loadLogs(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(_keyLogs);
      if (raw == null) return;
      final list = jsonDecode(raw) as List;
      _logs = list.map((j) => WorkoutLog.fromJson(j as Map<String, dynamic>)).toList();
      // Keep last 500 only — prevents unbounded growth
      if (_logs.length > 500) {
        _logs = _logs.sublist(_logs.length - 500);
      }
    } catch (e) {
      debugPrint('_loadLogs error: $e');
    }
  }

  void _loadPRs(SharedPreferences prefs) {
    try {
      final raw = prefs.getString(_keyPRs);
      if (raw == null) return;
      final map = jsonDecode(raw) as Map<String, dynamic>;
      _prWeights = Map<String, double>.from(
          (map['weights'] as Map? ?? {}).map((k, v) => MapEntry(k as String, (v as num).toDouble())));
      _prReps = Map<String, int>.from(
          (map['reps'] as Map? ?? {}).map((k, v) => MapEntry(k as String, (v as num).toInt())));
    } catch (e) {
      debugPrint('_loadPRs error: $e');
    }
  }

  Future<void> _saveLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyLogs, jsonEncode(_logs.map((l) => l.toJson()).toList()));
    } catch (e) {
      debugPrint('_saveLogs error: $e');
    }
  }

  Future<void> _savePRs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyPRs, jsonEncode({
        'weights': _prWeights,
        'reps':    _prReps,
      }));
    } catch (e) {
      debugPrint('_savePRs error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────
  // PR SYSTEM
  // ─────────────────────────────────────────────────────────
  String exerciseKey(String baseId) => baseId.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '_');

  double getPRWeight(String key)    => _prWeights[key] ?? 0.0;
  int    getPRReps(String key)      => _prReps[key] ?? 0;

  PRResult checkPR(String key, double weight, int reps, String unit) {
    final result = PRResult.compute(
      newWeight:  weight,
      newReps:    reps,
      prevWeight: getPRWeight(key),
      prevReps:   getPRReps(key),
      unit:       unit,
    );

    if (result.isPR) {
      _prWeights[key] = weight;
      _prReps[key]    = reps;
      _savePRs();
    }

    return result;
  }

  // ─────────────────────────────────────────────────────────
  // LOG A SET
  // ─────────────────────────────────────────────────────────
  Future<PRResult> logSet({
    required String exerciseName,
    required String baseId,
    required double weight,
    required int    reps,
    required String unit,
    required String muscleGroup,
  }) async {
    final key = exerciseKey(baseId);
    final result = checkPR(key, weight, reps, unit);

    _logs.add(WorkoutLog(
      exercise:    key,
      date:        DateTime.now(),
      weight:      weight,
      reps:        reps,
      muscleGroup: muscleGroup,
    ));

    await _saveLogs();
    notifyListeners();
    return result;
  }

  // ─────────────────────────────────────────────────────────
  // ANALYTICS HELPERS
  // ─────────────────────────────────────────────────────────

  /// Total volume lifted in kg (all time)
  double get totalVolumeAllTime =>
      _logs.fold(0.0, (s, l) => s + l.weight * l.reps);

  /// Total volume in last N days
  double volumeInDays(int days) {
    final cutoff = DateTime.now().subtract(Duration(days: days));
    return _logs
        .where((l) => l.date.isAfter(cutoff))
        .fold(0.0, (s, l) => s + l.weight * l.reps);
  }

  /// Volume per muscle group (last 7 days)
  Map<String, double> get weeklyVolumeByMuscle {
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    final map = <String, double>{};
    for (final log in _logs.where((l) => l.date.isAfter(cutoff))) {
      final m = log.muscleGroup ?? 'other';
      map[m] = (map[m] ?? 0) + log.weight * log.reps;
    }
    return map;
  }

  /// e1RM for an exercise (Epley formula)
  double estimatedE1RM(String key) {
    final w = getPRWeight(key);
    final r = getPRReps(key);
    if (w == 0 || r == 0) return 0;
    if (r == 1) return w;
    return w * (1 + r / 30.0);
  }

  /// Strength progression: list of (date, weight) pairs for an exercise
  List<MapEntry<DateTime, double>> strengthProgression(String key) {
    return _logs
        .where((l) => l.exercise == key && l.weight > 0)
        .map((l) => MapEntry(l.date, l.weight))
        .toList()
      ..sort((a, b) => a.key.compareTo(b.key));
  }

  /// Sets per muscle per week (last 7 days)
  Map<String, int> get setsPerMuscleThisWeek {
    final cutoff = DateTime.now().subtract(const Duration(days: 7));
    final map = <String, int>{};
    for (final log in _logs.where((l) => l.date.isAfter(cutoff))) {
      final m = log.muscleGroup ?? 'other';
      map[m] = (map[m] ?? 0) + 1;
    }
    return map;
  }

  /// Last trained date per muscle
  Map<String, DateTime> get lastTrainedByMuscle {
    final map = <String, DateTime>{};
    for (final log in _logs) {
      final m = log.muscleGroup ?? 'other';
      final existing = map[m];
      if (existing == null || log.date.isAfter(existing)) {
        map[m] = log.date;
      }
    }
    return map;
  }

  /// Weakest muscle (lowest volume in last 14 days)
  String get weakestMuscle {
    final cutoff = DateTime.now().subtract(const Duration(days: 14));
    final map = <String, double>{};
    for (final log in _logs.where((l) => l.date.isAfter(cutoff))) {
      final m = log.muscleGroup ?? 'other';
      if (m == 'other') continue;
      map[m] = (map[m] ?? 0) + log.weight * log.reps;
    }
    if (map.isEmpty) return '';
    return map.entries.reduce((a, b) => a.value < b.value ? a : b).key;
  }

  /// Muscles not trained in last 7 days
  List<String> get musclesSkippedLastWeek {
    final trained = lastTrainedByMuscle;
    final cutoff  = DateTime.now().subtract(const Duration(days: 7));
    const all     = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
    return all.where((m) {
      final last = trained[m];
      return last == null || last.isBefore(cutoff);
    }).toList();
  }
}
