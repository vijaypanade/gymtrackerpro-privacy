class WorkoutLog {
  final String exercise;
  final DateTime date;
  final double weight;
  final int reps;
  final int minutes;
final String? muscleGroup;
  WorkoutLog({
  required this.exercise,
  required this.date,
  required this.weight,
  required this.reps,
  this.minutes = 0,
  this.muscleGroup, // 🔥 ADD THIS
});

  Map<String, dynamic> toJson() {
    return {
  'exercise': exercise,
  'date': date.toIso8601String(),
  'weight': weight,
  'reps': reps,
  'minutes': minutes,
  'muscleGroup': muscleGroup, // 🔥 ADD THIS
};
  }

  factory WorkoutLog.fromJson(Map<String, dynamic> json) {
    return WorkoutLog(
      exercise: json['exercise'] ?? '',
      date: DateTime.tryParse(json['date'] ?? '') ?? DateTime.now(),
      weight: (json['weight'] is num)
          ? (json['weight'] as num).toDouble()
          : double.tryParse(json['weight'].toString()) ?? 0,
      reps: json['reps'] ?? 0,
      minutes: json['minutes'] ?? 0,
        muscleGroup: json['muscleGroup'],
    );
  }
}