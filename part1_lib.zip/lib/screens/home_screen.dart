import '../services/ad_service.dart';
// lib/screens/home_screen.dart — v8.0 PREMIUM
// Upgrades: radial ambient glow, frosted AppBar, glowing rank orb with pulse,
// mood tiles with glassmorphism selection + coach copy, AI Coach animated border,
// pulsing ring on AI orb, missions ring counter + staggered rows,
// recovery tiles with animated progress bars + score label, today workout hero
// layout, quick action tiles with glow, impact stat numbers, badge shimmer sweep,
// horizontal shimmer skeleton, coach-tone copy throughout.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/notification_service.dart';

import 'package:provider/provider.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'premium_screen.dart';
import '../models/models.dart';
import '../providers/app_provider.dart';
import '../providers/gamification_provider.dart';
import '../utils/app_constants.dart';

import '../utils/app_routes.dart';
import '../utils/recovery_grid_data.dart';
import '../widgets/shared_widgets.dart';
import '../services/ai_engine.dart';

import '../services/monetization_service.dart'; // ✅ Paywall + Usage pill
import 'planner_screen.dart';
import 'ai_chat_screen.dart';
import 'ai_setup_screen.dart';
import 'main_shell.dart';
import '../models/workout_log.dart';
import '../utils/recovery_ui.dart';
import '../widgets/muscle_chip.dart';

// ════════════════════════════════════════════════
// HAPTICS — consistent system (Phase 1)
// ════════════════════════════════════════════════
class _H {
  static void heavy()     => HapticFeedback.heavyImpact();
  static void medium()    => HapticFeedback.mediumImpact();
  static void light()     => HapticFeedback.lightImpact();
  static void selection() => HapticFeedback.selectionClick();
  static void success()   => HapticFeedback.heavyImpact();
  static void tap()       => HapticFeedback.lightImpact();
}


// ════════════════════════════════════════════════
// HOME SCREEN
// ════════════════════════════════════════════════
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, bool>(
      selector: (_, ap) => ap.loading,
      builder: (context, loading, _) {
        if (loading) return const _HomeSkeletonScreen();
        return Scaffold(
          backgroundColor: AppColors.bg,
          // ✅ Banner ad at bottom — free users only
          bottomNavigationBar: Selector<AppProvider, bool>(
  selector: (_, ap) => ap.isPremium,
  builder: (_, isPremium, __) => isPremium
      ? const SizedBox.shrink()
      : GTPBannerAd(isPremium: isPremium), // ✅ premium check
),
          body: Stack(children: [
            // Ambient radial glow — top
            Positioned(
              top: -100, left: -60, right: -60,
              child: IgnorePointer(child: Container(
                height: 360,
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter, radius: 0.75,
                    colors: [
                      AppColors.gold.withValues(alpha: 0.055),
                      Colors.transparent,
                    ],
                  ),
                ),
              )),
            ),
            CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                const _HomeAppBar(),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(
                      AppSpacing.lg, AppSpacing.xs, AppSpacing.lg, 120),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _FadeSlide(delay: 0,   child: const _XPRankBar()),
                      const SizedBox(height: AppSpacing.lg),
                      _FadeSlide(delay: 55,  child: const _MoodRow()),
                      const SizedBox(height: AppSpacing.lg),
                      _FadeSlide(delay: 100, child: const _AICoachCard()),
                      const SizedBox(height: AppSpacing.lg),
                      _FadeSlide(delay: 140, child: const _MissionsCard()),
                      const SizedBox(height: AppSpacing.xxl),

                      const _SectionHeader(
                          title: 'Muscle Recovery',
                          sub: 'How your body is bouncing back'),
                      const SizedBox(height: AppSpacing.md),
                      _FadeSlide(delay: 170, child: const _RecoveryGrid()),
                      const SizedBox(height: AppSpacing.xxl),

                      _SectionHeaderWithAction(
                          title: "Today's Workout",
                          sub: 'Your mission for today',
                          action: 'Edit Plan',
                          onAction: () => context
                              .findAncestorStateOfType<MainShellState>()
                              ?.changeTab(1)),
                      const SizedBox(height: AppSpacing.md),
                      _FadeSlide(delay: 200, child: const _TodayWorkoutCard()),
                      const SizedBox(height: AppSpacing.xxl),

                      const _SectionHeader(title: 'Quick Actions', sub: 'One tap, done'),
                      const SizedBox(height: AppSpacing.md),
                      _FadeSlide(delay: 230, child: const _QuickActions()),
                      const SizedBox(height: AppSpacing.xxl),

                      const _SectionHeader(title: 'Your Progress', sub: 'Keep building momentum'),
                      const SizedBox(height: AppSpacing.md),
                      _FadeSlide(delay: 255, child: const _StatsRow()),
                      const SizedBox(height: AppSpacing.xxl),

                      const _SectionHeader(title: 'Achievements', sub: 'Every rep counts'),
                      const SizedBox(height: AppSpacing.md),
                      _FadeSlide(delay: 280, child: const _BadgesScroll()),
                      const SizedBox(height: AppSpacing.lg),
                    ]),
                  ),
                ),
              ],
            ),
            const _OverlayLayer(),
          ]),
        );
      },
    );
  }
}

// ════════════════════════════════════════════════
// SECTION HEADERS
// ════════════════════════════════════════════════
class _SectionHeader extends StatelessWidget {
  final String title;
  final String? sub;
  const _SectionHeader({required this.title, this.sub});

  @override
  Widget build(BuildContext context) => _SectionHeaderBase(
      title: title, sub: sub);
}

class _SectionHeaderWithAction extends StatelessWidget {
  final String title, action;
  final String? sub;
  final VoidCallback onAction;
  const _SectionHeaderWithAction(
      {required this.title, required this.action,
       required this.onAction, this.sub});

  @override
  Widget build(BuildContext context) => _SectionHeaderBase(
      title: title, sub: sub, action: action, onAction: onAction);
}

class _SectionHeaderBase extends StatelessWidget {
  final String title;
  final String? sub, action;
  final VoidCallback? onAction;
  const _SectionHeaderBase(
      {required this.title, this.sub, this.action, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
        Row(children: [
          Container(
            width: 3, height: 15,
            decoration: BoxDecoration(
              gradient: AppGradients.gold,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(title.toUpperCase(), style: TextStyle(fontFamily: 'Inter',
            color: AppColors.textPrimary, fontSize: 12,
            fontWeight: FontWeight.w800, letterSpacing: 1.0,
          )),
        ]),
        if (sub != null) Padding(
          padding: const EdgeInsets.only(left: 11, top: 2),
          child: Text(sub!, style: TextStyle(fontFamily: 'Inter',
            color: AppColors.textMuted, fontSize: 11)),
        ),
      ])),
      if (action != null)
        GestureDetector(
          onTap: onAction,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.gold.withValues(alpha: 0.09),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: AppColors.gold.withValues(alpha: 0.25), width: 0.8),
            ),
            child: Text(action!, style: TextStyle(fontFamily: 'Inter',
              color: AppColors.gold, fontSize: 11, fontWeight: FontWeight.w700)),
          ),
        ),
    ]);
  }
}

// ════════════════════════════════════════════════
// RECOVERY GRID — animated bar + score + glow band
// ════════════════════════════════════════════════
class _RecoveryGrid extends StatelessWidget {
  const _RecoveryGrid();

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, int>(
      selector: (_, ap) => ap.refreshTrigger,
      builder: (_, __, ___) {
        final ap = context.watch<AppProvider>();
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: RecoveryGridData.muscles.length,
          gridDelegate: RecoveryGridData.gridDelegate,
          itemBuilder: (_, i) {
            final m     = RecoveryGridData.muscles[i];
            final score = ap.getMuscleRecovery(m['key']!).toInt().clamp(0, 100);
            return _RecoveryTile(
              muscle: m['label']!, score: score, emoji: m['emoji']!,
              delay: Duration(milliseconds: i * 45),
            );
          },
        );
      },
    );
  }
}

class _RecoveryTile extends StatefulWidget {
  final String muscle, emoji;
  final int score;
  final Duration delay;
  const _RecoveryTile({required this.muscle, required this.score,
      required this.emoji, required this.delay});

  @override
  State<_RecoveryTile> createState() => _RecoveryTileState();
}

class _RecoveryTileState extends State<_RecoveryTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _bar;

  Color get _color {
    if (widget.score >= 70) return AppColors.green;
    if (widget.score >= 40) return AppColors.yellow;
    return AppColors.red;
  }

  String get _statusLabel {
    if (widget.score >= 80) return 'Ready';
    if (widget.score >= 60) return 'Good';
    if (widget.score >= 40) return 'Fair';
    return 'Rest';
  }

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 850));
    _bar = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic);
    Future.delayed(widget.delay, () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _bar,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(AppSpacing.md),
          border: Border.all(
              color: _color.withValues(alpha: 0.22 * _bar.value), width: 1),
          boxShadow: [BoxShadow(
            color: _color.withValues(alpha: 0.08 * _bar.value),
            blurRadius: 8, spreadRadius: 0,
          )],
        ),
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
          Text(widget.emoji, style: const TextStyle(fontSize: 18, height: 1.0)),
          const SizedBox(height: 2),
          Text(widget.muscle, style: TextStyle(fontFamily: 'Inter',
            color: AppColors.textSecondary, fontSize: 9,
            fontWeight: FontWeight.w600, height: 1.1,
          ), overflow: TextOverflow.ellipsis, maxLines: 1,
              textAlign: TextAlign.center),
          const SizedBox(height: 3),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: LinearProgressIndicator(
              value: (widget.score / 100) * _bar.value,
              minHeight: 3,
              backgroundColor: AppColors.bgElevated,
              valueColor: AlwaysStoppedAnimation(_color),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '${widget.score}%',
            style: TextStyle(fontFamily: 'Rajdhani',
                color: _color, fontSize: 11, fontWeight: FontWeight.w800,
                height: 1.1),
          ),
          Text(_statusLabel, style: TextStyle(fontFamily: 'Inter',
              color: _color.withValues(alpha: 0.75), fontSize: 8,
              fontWeight: FontWeight.w600, height: 1.1)),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// SKELETON — horizontal shimmer sweep
// ════════════════════════════════════════════════
class _HomeSkeletonScreen extends StatefulWidget {
  const _HomeSkeletonScreen();

  @override
  State<_HomeSkeletonScreen> createState() => _HomeSkeletonScreenState();
}

class _HomeSkeletonScreenState extends State<_HomeSkeletonScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _sweep;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1600))..repeat();
    _sweep = Tween<double>(begin: -1.5, end: 2.5)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _sweep,
          builder: (_, __) => Padding(
            padding: const EdgeInsets.fromLTRB(
                AppSpacing.lg, AppSpacing.xxl, AppSpacing.lg, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: AppSpacing.xl),
                _SBone(width: 200, height: 28, sweep: _sweep.value),
                const SizedBox(height: AppSpacing.xxl),
                _SBone(width: double.infinity, height: 90,
                    sweep: _sweep.value, r: 16),
                const SizedBox(height: AppSpacing.lg),
                _SBone(width: double.infinity, height: 68,
                    sweep: _sweep.value, r: 14),
                const SizedBox(height: AppSpacing.lg),
                _SBone(width: double.infinity, height: 100,
                    sweep: _sweep.value, r: 14),
                const SizedBox(height: AppSpacing.xl),
                Row(children: List.generate(3, (i) => Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(right: i < 2 ? AppSpacing.sm : 0),
                    child: _SBone(height: 72, sweep: _sweep.value, r: 12),
                  ),
                ))),
                const SizedBox(height: AppSpacing.xl),
                GridView.count(
                  crossAxisCount: 3, shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: AppSpacing.sm,
                  crossAxisSpacing: AppSpacing.sm,
                  childAspectRatio: 0.95,
                  children: List.generate(6, (_) =>
                      _SBone(height: 80, sweep: _sweep.value, r: 12)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SBone extends StatelessWidget {
  final double? width;
  final double height, sweep;
  final double r;
  const _SBone({this.width, required this.height,
      required this.sweep, this.r = 8});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(r),
      child: SizedBox(
        width: width, height: height,
        child: Stack(children: [
          Container(color: AppColors.bgCardLight),
          Positioned.fill(child: Transform.translate(
            offset: Offset(sweep * 220, 0),
            child: Container(
              decoration: BoxDecoration(gradient: LinearGradient(colors: [
                Colors.transparent,
                Colors.white.withValues(alpha: 0.05),
                Colors.transparent,
              ])),
            ),
          )),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// OVERLAY
// ════════════════════════════════════════════════
class _OverlayLayer extends StatelessWidget {
  const _OverlayLayer();

  @override
  Widget build(BuildContext context) {
    return Consumer2<AppProvider, GamificationProvider>(
      builder: (context, ap, gp, _) => Stack(children: [
        if (gp.showXPPopup)     _XPToast(xp: gp.lastXPGained),
        if (gp.showBadgePopup && gp.lastUnlockedBadge != null)
          _BadgePopup(badge: gp.lastUnlockedBadge!),
        if (gp.showRankUpPopup && gp.newRank != null)
          _RankUpPopup(rank: gp.newRank!),
        if (ap.showStreakPopup)
          _StreakToast(streak: ap.streak.currentStreak),
      ]),
    );
  }
}

// ════════════════════════════════════════════════
// APP BAR — frosted
// ════════════════════════════════════════════════
class _HomeAppBar extends StatelessWidget {
  const _HomeAppBar();

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      backgroundColor: AppColors.bg.withValues(alpha: 0.93),
      elevation: 0, floating: true, snap: true,
      titleSpacing: AppSpacing.lg,
      title: Row(children: [
        Container(
          width: 34, height: 34,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, gradient: AppGradients.gold),
          child: const Icon(Icons.fitness_center_rounded,
              size: 17, color: Colors.black),
        ),
        const SizedBox(width: AppSpacing.sm),
        Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, children: [
          Text('GymTracker Pro', style: TextStyle(fontFamily: 'Rajdhani',
              fontSize: 16, fontWeight: FontWeight.w900,
              letterSpacing: 0.3, color: AppColors.textPrimary),
              overflow: TextOverflow.ellipsis),
          Text('BETA', style: TextStyle(fontFamily: 'Inter',
              fontSize: 8, fontWeight: FontWeight.w800,
              color: AppColors.gold, letterSpacing: 2)),
        ])),
      ]),
      actions: [
        _Tap(
          onTap: () => Navigator.push(
              context, slideRoute(const AIChatScreen())),
          child: Container(
            margin: const EdgeInsets.only(right: AppSpacing.sm),
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: 7),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                AppColors.gold.withValues(alpha: 0.16),
                AppColors.gold.withValues(alpha: 0.07),
              ]),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: AppColors.gold.withValues(alpha: 0.38), width: 0.8),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.smart_toy_rounded, size: 13,
                  color: AppColors.gold),
              const SizedBox(width: AppSpacing.xs),
              Text('AI Coach', style: TextStyle(fontFamily: 'Inter',
                  fontSize: 10, fontWeight: FontWeight.w800,
                  color: AppColors.gold)),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(right: AppSpacing.lg),
          child: Selector<AppProvider, int>(
            selector: (_, ap) => ap.streak.currentStreak,
            builder: (_, streak, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: AppColors.orange.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: AppColors.orange.withValues(alpha: 0.25)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Text('🔥', style: TextStyle(fontSize: 13)),
                const SizedBox(width: 3),
                Text('$streak', style: TextStyle(fontFamily: 'Rajdhani',
                    fontSize: 15, fontWeight: FontWeight.w900,
                    color: AppColors.orange)),
              ]),
            ),
          ),
        ),
      ],
    );
  }
}

// ════════════════════════════════════════════════
// XP RANK BAR
// ════════════════════════════════════════════════
class _XPRankBar extends StatelessWidget {
  const _XPRankBar();

  @override
  Widget build(BuildContext context) {
    return Selector<GamificationProvider, XPSystem>(
      selector: (_, gp) => gp.xp,
      builder: (_, xp, __) => Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: const Color(0xFF0C0C07),
          borderRadius: BorderRadius.circular(AppSpacing.lg),
          border: Border.all(
              color: AppColors.gold.withValues(alpha: 0.22), width: 1),
          boxShadow: [BoxShadow(
            color: AppColors.gold.withValues(alpha: 0.07),
            blurRadius: 20, spreadRadius: 0,
          )],
        ),
        child: Column(children: [
          Row(children: [
            _PulseOrb(emoji: xp.rank.emoji,
                gradient: AppGradients.rankGradient(xp.rank.index)),
            const SizedBox(width: AppSpacing.md),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Text(xp.rank.displayName.toUpperCase(),
                      style: TextStyle(fontFamily: 'Rajdhani',
                        color: AppColors.gold, fontSize: 15,
                        fontWeight: FontWeight.w900, letterSpacing: 1.3)),
                  const SizedBox(width: AppSpacing.xs + 2),
                  _XPPill(xp: xp.totalXP),
                ]),
                const SizedBox(height: 3),
                Text(xp.weeklyXP > 0
                    ? '${xp.weeklyXP} XP earned this week 🔥'
                    : 'Start training to earn XP',
                    style: TextStyle(fontFamily: 'Inter',
                        color: AppColors.textMuted, fontSize: 11)),
              ],
            )),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${(xp.rankProgress * 100).toInt()}%',
                  style: TextStyle(fontFamily: 'Rajdhani',
                      color: AppColors.gold, fontSize: 20,
                      fontWeight: FontWeight.w900)),
              Text('to ${xp.nextRankName}',
                  style: TextStyle(fontFamily: 'Inter',
                      color: AppColors.textMuted, fontSize: 10)),
            ]),
          ]),
          const SizedBox(height: AppSpacing.md),
          _AnimatedXPBar(progress: xp.rankProgress),
          const SizedBox(height: AppSpacing.xs),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(xp.rank.displayName, style: TextStyle(fontFamily: 'Inter',
                color: AppColors.textMuted, fontSize: 9,
                fontWeight: FontWeight.w600)),
            Text(xp.nextRankName, style: TextStyle(fontFamily: 'Inter',
                color: AppColors.gold.withValues(alpha: 0.55), fontSize: 9,
                fontWeight: FontWeight.w600)),
          ]),
          // XP next goal tease
          if (xp.xpToNextRank > 0) ...[
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppColors.gold.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.gold.withValues(alpha: 0.18)),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('⚡', style: TextStyle(fontSize: 11)),
                const SizedBox(width: 5),
                Text(
                  '${xp.xpToNextRank} XP to ${xp.nextRankName} ${xp.nextRankEmoji}',
                  style: TextStyle(fontFamily: 'Inter',
                    color: AppColors.gold, fontSize: 10,
                    fontWeight: FontWeight.w800),
                ),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}

class _PulseOrb extends StatefulWidget {
  final String emoji;
  final Gradient gradient;
  const _PulseOrb({required this.emoji, required this.gradient});

  @override
  State<_PulseOrb> createState() => _PulseOrbState();
}

class _PulseOrbState extends State<_PulseOrb>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 2200))..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _pulse,
    builder: (_, __) => Container(
      width: 52, height: 52,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: widget.gradient,
        boxShadow: [BoxShadow(
          color: AppColors.gold.withValues(alpha: 0.32 * _pulse.value),
          blurRadius: 16 * _pulse.value, spreadRadius: 2 * _pulse.value,
        )],
      ),
      child: Center(child: Text(widget.emoji,
          style: const TextStyle(fontSize: 26))),
    ),
  );
}

class _XPPill extends StatelessWidget {
  final int xp;
  const _XPPill({required this.xp});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(
      gradient: LinearGradient(colors: [
        AppColors.gold.withValues(alpha: 0.18),
        AppColors.gold.withValues(alpha: 0.08),
      ]),
      borderRadius: BorderRadius.circular(6),
      border: Border.all(
          color: AppColors.gold.withValues(alpha: 0.3), width: 0.5),
    ),
    child: Text('$xp XP', style: TextStyle(fontFamily: 'Inter',
        color: AppColors.gold, fontSize: 9, fontWeight: FontWeight.w800)),
  );
}

class _AnimatedXPBar extends StatefulWidget {
  final double progress;
  const _AnimatedXPBar({required this.progress});

  @override
  State<_AnimatedXPBar> createState() => _AnimatedXPBarState();
}

class _AnimatedXPBarState extends State<_AnimatedXPBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1000));
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic);
    _ctrl.forward();
  }

  @override
  void didUpdateWidget(covariant _AnimatedXPBar old) {
    super.didUpdateWidget(old);
    if (old.progress != widget.progress) _ctrl.forward(from: 0);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _anim,
    builder: (_, __) => XPProgressBar(
        progress: widget.progress * _anim.value),
  );
}

// ════════════════════════════════════════════════
// MOOD ROW
// ════════════════════════════════════════════════
class _MoodRow extends StatelessWidget {
  const _MoodRow();

  Color _color(MoodType m) {
    switch (m) {
      case MoodType.tired:     return AppColors.blue;
      case MoodType.energetic: return AppColors.green;
      default:                 return AppColors.gold;
    }
  }

  String _coachText(MoodType m) {
    switch (m) {
      case MoodType.tired:
        return '💙 Body\'s telling you something. Smart recovery is still progress.';
      case MoodType.energetic:
        return '🔥 This is YOUR day. Go break that record — you\'re ready.';
      default:
        return '👊 Solid headspace. Execute the plan and walk out stronger.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, MoodType>(
      selector: (_, ap) => ap.todayMood,
      builder: (context, mood, _) => Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(AppSpacing.lg),
          border: Border.all(color: AppColors.borderSoft, width: 0.5),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('HOW ARE YOU FEELING TODAY?', style: TextStyle(fontFamily: 'Inter',
            color: AppColors.textMuted, fontSize: 10,
            fontWeight: FontWeight.w700, letterSpacing: 1.2,
          )),
          const SizedBox(height: AppSpacing.md),
          Row(children: MoodType.values.map((m) {
            final sel   = mood == m;
            final color = _color(m);
            return Expanded(
              child: _Tap(
                onTap: () {
                  _H.selection();
                  context.read<AppProvider>().setMood(m);
                },
                child: AnimatedContainer(
                  duration: AppDurations.fast,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(
                      vertical: AppSpacing.md + 2),
                  decoration: BoxDecoration(
                    color: sel
                        ? color.withValues(alpha: 0.12)
                        : AppColors.bgCardLight,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: sel ? color : Colors.transparent, width: 1.2),
                    boxShadow: sel ? [BoxShadow(
                      color: color.withValues(alpha: 0.20),
                      blurRadius: 10, spreadRadius: 0)] : null,
                  ),
                  child: Column(children: [
                    AnimatedScale(scale: sel ? 1.28 : 1.0,
                        duration: AppDurations.fast,
                        child: Text(m.emoji,
                            style: const TextStyle(fontSize: 22))),
                    const SizedBox(height: AppSpacing.xs),
                    Text(m.label, style: TextStyle(fontFamily: 'Inter',
                      color: sel ? color : AppColors.textMuted,
                      fontSize: 10,
                      fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
                    )),
                  ]),
                ),
              ),
            );
          }).toList()),
          if (mood != MoodType.normal) ...[
            const SizedBox(height: AppSpacing.md),
            AnimatedContainer(
              duration: AppDurations.fast,
              width: double.infinity,
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: _color(mood).withValues(alpha: 0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: _color(mood).withValues(alpha: 0.2), width: 0.5),
              ),
              child: Text(_coachText(mood), style: TextStyle(fontFamily: 'Inter',
                  color: _color(mood), fontSize: 12,
                  fontWeight: FontWeight.w500, height: 1.5)),
            ),
          ],
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// AI COACH CARD — animated glow border
// ════════════════════════════════════════════════
class _AICoachCard extends StatefulWidget {
  const _AICoachCard();

  @override
  State<_AICoachCard> createState() => _AICoachCardState();
}

class _AICoachCardState extends State<_AICoachCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 2600))..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.07, end: 0.22)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider,
        ({int recovery, String suggestion, bool canUseAI, bool isPremium, int aiRemaining})>(
      selector: (_, ap) => (
        recovery:    ap.getOverallRecovery(),
        suggestion:  ap.aiSuggestion,
        canUseAI:    ap.canUseAI(),
        isPremium:   ap.isPremium,
        aiRemaining: ap.aiUsesRemaining,
      ),
      builder: (context, data, _) {
        final rColor = data.recovery >= 70 ? AppColors.green
            : data.recovery >= 40 ? AppColors.yellow : AppColors.red;

        return AnimatedBuilder(
          animation: _glow,
          builder: (_, child) => Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0B0900),
              borderRadius: BorderRadius.circular(AppSpacing.lg),
              border: Border.all(
                  color: AppColors.gold.withValues(alpha: _glow.value),
                  width: 1),
              boxShadow: [BoxShadow(
                color: AppColors.gold.withValues(alpha: _glow.value * 0.55),
                blurRadius: 18, spreadRadius: 0,
              )],
            ),
            child: child,
          ),
          child: _Tap(
            onTap: () => Navigator.push(
                context, slideRoute(const AIChatScreen())),
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Row(children: [
                _AIRingOrb(),
                const SizedBox(width: AppSpacing.md),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Text('AI COACH', style: TextStyle(fontFamily: 'Inter',
                          color: AppColors.gold, fontSize: 10,
                          fontWeight: FontWeight.w800, letterSpacing: 1.5)),
                      const SizedBox(width: AppSpacing.sm),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: rColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text('${data.recovery}% recovered',
                            style: TextStyle(fontFamily: 'Inter',
                                color: rColor, fontSize: 8.5,
                                fontWeight: FontWeight.w700)),
                      ),

                      // ✅ AI usage pill — free users see "2 AI left"

                    ]),
                    const SizedBox(height: AppSpacing.xs + 2),
                    data.canUseAI
                        ? Text(
                            data.suggestion.isEmpty
                                ? '💪 You\'re primed. Let\'s crush today\'s session.'
                                : data.suggestion,
                            style: TextStyle(fontFamily: 'Inter',
                                color: AppColors.textPrimary, fontSize: 13,
                                height: 1.5),
                          )
                        : _Tap(
                            onTap: () => PaywallSheet.show(context,
                              trigger:  PaywallTrigger.aiLimitHit,
                              onUpgrade:    () {},
                              onAdComplete: () {},
                            ),
                            child: Text(
                                '🔒 Daily AI limit reached — tap to unlock',
                                style: TextStyle(fontFamily: 'Inter',
                                    color: AppColors.gold, fontSize: 13,
                                    fontWeight: FontWeight.w600)),
                          ),
                  ],
                )),
                const SizedBox(width: AppSpacing.sm),
                Icon(Icons.arrow_forward_ios_rounded,
                    color: AppColors.gold.withValues(alpha: 0.5), size: 14),
              ]),
            ),
          ),
        );
      },
    );
  }
}

class _AIRingOrb extends StatefulWidget {
  @override
  State<_AIRingOrb> createState() => _AIRingOrbState();
}

class _AIRingOrbState extends State<_AIRingOrb>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _ring;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1800))..repeat();
    _ring = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _ring,
    builder: (_, __) => SizedBox(
      width: 52, height: 52,
      child: Stack(alignment: Alignment.center, children: [
        Transform.scale(
          scale: 0.88 + 0.32 * _ring.value,
          child: Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: AppColors.gold.withValues(
                      alpha: (1 - _ring.value) * 0.45), width: 1.5),
            ),
          ),
        ),
        Container(
          width: 44, height: 44,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, gradient: AppGradients.gold),
          child: const Icon(Icons.smart_toy_rounded,
              size: 22, color: Colors.black),
        ),
      ]),
    ),
  );
}

// ════════════════════════════════════════════════
// MISSIONS CARD
// ════════════════════════════════════════════════
class _MissionsCard extends StatelessWidget {
  const _MissionsCard();

  @override
  Widget build(BuildContext context) {
    // FIX: Auto-init missions if 0/0 using current AppProvider state
    final ap = context.read<AppProvider>();
    final gp = context.read<GamificationProvider>();
    if (gp.totalMissions == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          gp.initMissionsIfNeeded(
            streak:        ap.streak.currentStreak,
            totalWorkouts: ap.streak.totalWorkouts,
            goal:          ap.profile.goal,
            weakMuscle:    ap.weakestMuscle,
            currentWaterMl: ap.profile.currentWaterMl,
            waterGoalMl:   ap.profile.dailyWaterGoalMl,
          );
          // 🔥 Wire streak notification — fires at 8PM if no workout today
          NotificationService.instance.scheduleStreakReminder(
            currentStreak:      ap.streak.currentStreak,
            hasWorkedOutToday:  ap.todayPlan.isCompleted,
            userName:           ap.profile.name.isEmpty ? 'Champion' : ap.profile.name,
          );
        }
      });
    }

    return Selector<GamificationProvider,
        ({List<DailyMission> missions, int completed, int total, bool allDone})>(
      selector: (_, gp) => (
        missions:  gp.missions,
        completed: gp.completedMissions,
        total:     gp.totalMissions,
        allDone:   gp.allMissionsComplete,
      ),
      builder: (_, data, __) => Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(AppSpacing.lg),
          border: Border.all(
              color: data.allDone
                  ? AppColors.green.withValues(alpha: 0.38)
                  : AppColors.borderSoft,
              width: 1),
          boxShadow: data.allDone ? [BoxShadow(
            color: AppColors.green.withValues(alpha: 0.09),
            blurRadius: 18, spreadRadius: 0)] : null,
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(data.allDone ? '✅' : '🎯',
                style: const TextStyle(fontSize: 14)),
            const SizedBox(width: AppSpacing.sm),
            Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('DAILY MISSIONS', style: TextStyle(fontFamily: 'Inter',
                  color: AppColors.textPrimary, fontSize: 11,
                  fontWeight: FontWeight.w800, letterSpacing: 1.1)),
              Text('Complete them all for bonus XP', style: TextStyle(fontFamily: 'Inter',
                  color: AppColors.textMuted, fontSize: 10)),
            ])),
            _MissionRingCounter(
                completed: data.completed, total: data.total,
                allDone: data.allDone),
          ]),
          const SizedBox(height: AppSpacing.md),
          const Divider(color: AppColors.divider, height: 1),
          const SizedBox(height: AppSpacing.md),
          ...data.missions.asMap().entries.map((e) =>
              _MissionRow(mission: e.value,
                  delay: Duration(milliseconds: e.key * 55))),
          if (data.allDone) ...[
            const SizedBox(height: AppSpacing.sm),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.sm + 2),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  AppColors.green.withValues(alpha: 0.12),
                  AppColors.green.withValues(alpha: 0.04),
                ]),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: AppColors.green.withValues(alpha: 0.25), width: 0.5),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.star_rounded, color: AppColors.gold, size: 14),
                const SizedBox(width: 6),
                Text('All missions crushed — beast mode 🦁', style: TextStyle(fontFamily: 'Inter',
                    color: AppColors.green, fontSize: 12,
                    fontWeight: FontWeight.w700)),
              ]),
            ),
          ],
        ]),
      ),
    );
  }
}

class _MissionRingCounter extends StatelessWidget {
  final int completed, total;
  final bool allDone;
  const _MissionRingCounter(
      {required this.completed, required this.total, required this.allDone});

  @override
  Widget build(BuildContext context) {
    final pct = total > 0 ? completed / total : 0.0;
    return SizedBox(
      width: 46, height: 46,
      child: Stack(alignment: Alignment.center, children: [
        CircularProgressIndicator(
          value: pct, strokeWidth: 3.5,
          backgroundColor: AppColors.bgElevated,
          valueColor: AlwaysStoppedAnimation(
              allDone ? AppColors.green : AppColors.gold),
        ),
        Text('$completed/$total', style: TextStyle(fontFamily: 'Rajdhani',
            color: allDone ? AppColors.green : AppColors.gold,
            fontSize: 11, fontWeight: FontWeight.w800)),
      ]),
    );
  }
}

class _MissionRow extends StatefulWidget {
  final DailyMission mission;
  final Duration delay;
  const _MissionRow({required this.mission, required this.delay});

  @override
  State<_MissionRow> createState() => _MissionRowState();
}

class _MissionRowState extends State<_MissionRow>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 300));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0.04, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    Future.delayed(widget.delay, () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final m = widget.mission;
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(position: _slide,
        child: Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: Row(children: [
            AnimatedContainer(
              duration: AppDurations.fast,
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: m.isCompleted
                    ? AppColors.green.withValues(alpha: 0.14)
                    : AppColors.bgCardLight,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: m.isCompleted
                        ? AppColors.green : AppColors.borderSoft,
                    width: 0.8),
                boxShadow: m.isCompleted ? [BoxShadow(
                  color: AppColors.green.withValues(alpha: 0.2),
                  blurRadius: 8)] : null,
              ),
              child: Center(child: Text(
                m.isCompleted ? '✓' : m.emoji,
                style: TextStyle(
                    fontSize: m.isCompleted ? 14 : 13,
                    color: m.isCompleted ? AppColors.green : null,
                    fontWeight: FontWeight.w800),
              )),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(m.title, style: TextStyle(fontFamily: 'Inter',
                  color: m.isCompleted
                      ? AppColors.textMuted : AppColors.textPrimary,
                  fontSize: 13, fontWeight: FontWeight.w600,
                  decoration: m.isCompleted
                      ? TextDecoration.lineThrough : null,
                  decorationColor: AppColors.textMuted,
                )),
                Text(m.description, style: TextStyle(fontFamily: 'Inter',
                    color: AppColors.textMuted, fontSize: 11)),
              ],
            )),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.gold.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(7),
                border: Border.all(
                    color: AppColors.gold.withValues(alpha: 0.2), width: 0.5),
              ),
              child: Text('+${m.xpReward} XP',
                  style: TextStyle(fontFamily: 'Inter',
                      color: AppColors.gold, fontSize: 10,
                      fontWeight: FontWeight.w800)),
            ),
          ]),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════
// TODAY'S WORKOUT
// ════════════════════════════════════════════════
class _TodayWorkoutCard extends StatelessWidget {
  const _TodayWorkoutCard();

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, ({DayPlan today, int todayIndex})>(
      selector: (_, ap) => (today: ap.todayPlan, todayIndex: ap.todayIndex),
      builder: (context, data, _) {
        final today = data.today;

        if (today.isRestDay) {
          return Container(
            padding: const EdgeInsets.all(AppSpacing.lg),
            decoration: BoxDecoration(
              color: AppColors.bgCard,
              borderRadius: BorderRadius.circular(AppSpacing.lg),
              border: Border.all(color: AppColors.borderSoft, width: 0.5),
            ),
            child: Row(children: [
              Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                  color: AppColors.bgCardLight,
                  borderRadius: BorderRadius.circular(14)),
                child: const Center(
                    child: Text('😴', style: TextStyle(fontSize: 30))),
              ),
              const SizedBox(width: AppSpacing.lg),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Rest Day', style: TextStyle(fontFamily: 'Rajdhani',
                      color: AppColors.textPrimary, fontSize: 22,
                      fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text('Smart recovery = stronger tomorrow. You\'ve earned this.',
                      style: TextStyle(fontFamily: 'Inter',
                          color: AppColors.textMuted, fontSize: 12,
                          height: 1.45)),
                ],
              )),
            ]),
          );
        }

        if (today.exercises.isEmpty) {
          return _Tap(
            onTap: () => Navigator.push(
                context, slideRoute(const AISetupScreen())),
            child: Container(
              padding: const EdgeInsets.all(AppSpacing.lg),
              decoration: BoxDecoration(
                color: AppColors.bgCard,
                borderRadius: BorderRadius.circular(AppSpacing.lg),
                border: Border.all(
                    color: AppColors.gold.withValues(alpha: 0.3), width: 1),
              ),
              child: Row(children: [
                Container(
                  width: 58, height: 58,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      AppColors.gold.withValues(alpha: 0.16),
                      AppColors.gold.withValues(alpha: 0.06),
                    ]),
                    borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.auto_awesome_rounded,
                      color: AppColors.gold, size: 26),
                ),
                const SizedBox(width: AppSpacing.lg),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('No workout yet', style: TextStyle(fontFamily: 'Rajdhani',
                        color: AppColors.textPrimary, fontSize: 20,
                        fontWeight: FontWeight.w900)),
                    Text('Let AI build your perfect plan in seconds 🤖',
                        style: TextStyle(fontFamily: 'Inter',
                            color: AppColors.textMuted, fontSize: 12,
                            height: 1.4)),
                  ],
                )),
                const Icon(Icons.arrow_forward_rounded,
                    color: AppColors.gold, size: 20),
              ]),
            ),
          );
        }

        final done  = today.completedExercises;
        final total = today.exercises.length;
        final pct   = (total > 0 ? done / total : 0.0).clamp(0.0, 1.0);

        return _Tap(
          onTap: () => Navigator.push(context, slideRoute(
              PlannerScreen(initialDayIndex: data.todayIndex))),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.bgCard,
              borderRadius: BorderRadius.circular(AppSpacing.lg),
              border: Border.all(
                  color: today.isCompleted
                      ? AppColors.green.withValues(alpha: 0.38)
                      : AppColors.borderSoft,
                  width: 1),
              boxShadow: today.isCompleted ? [BoxShadow(
                color: AppColors.green.withValues(alpha: 0.08),
                blurRadius: 14)] : null,
            ),
            child: Column(children: [
              // Header
              Padding(
                padding: const EdgeInsets.fromLTRB(
                    AppSpacing.lg, AppSpacing.lg, AppSpacing.lg, AppSpacing.md),
                child: Row(children: [
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(today.title, style: TextStyle(fontFamily: 'Rajdhani',
                          color: AppColors.textPrimary, fontSize: 21,
                          fontWeight: FontWeight.w900)),
                      const SizedBox(height: 3),
                      Text('$total exercises · ${today.exercises.fold(0, (s, e) => s + e.sets.length)} sets',
                          style: TextStyle(fontFamily: 'Inter',
                              color: AppColors.textMuted, fontSize: 12)),
                    ],
                  )),
                  CircularPercentIndicator(
                    radius: 30.0, lineWidth: 5.0, percent: pct,
                    center: Text('$done/$total', style: TextStyle(fontFamily: 'Inter',
                        fontSize: 10, fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary)),
                    progressColor: today.isCompleted
                        ? AppColors.green : AppColors.gold,
                    backgroundColor: AppColors.bgElevated,
                    circularStrokeCap: CircularStrokeCap.round,
                    animation: true, animationDuration: 950,
                  ),
                ]),
              ),

              // Exercise list
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
                child: Column(
                  children: today.exercises.take(3).map((ex) => Padding(
                    padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                    child: Row(children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color: ex.isComplete
                              ? AppColors.green.withValues(alpha: 0.10)
                              : AppColors.bgCardLight,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(child: Text(ex.emoji,
                            style: const TextStyle(fontSize: 15))),
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(child: Text(ex.name,
                          style: TextStyle(fontFamily: 'Inter',
                            color: ex.isComplete
                                ? AppColors.textMuted : AppColors.textPrimary,
                            fontSize: 13, fontWeight: FontWeight.w500,
                            decoration: ex.isComplete
                                ? TextDecoration.lineThrough : null,
                            decorationColor: AppColors.textMuted,
                          ),
                          overflow: TextOverflow.ellipsis)),
                      Text('${ex.sets.length}×', style: TextStyle(fontFamily: 'Inter',
                          color: AppColors.textMuted, fontSize: 11)),
                      const SizedBox(width: AppSpacing.sm),
                      Icon(ex.isComplete
                          ? Icons.check_circle_rounded
                          : Icons.radio_button_unchecked_rounded,
                          size: 14,
                          color: ex.isComplete
                              ? AppColors.green : AppColors.borderMedium),
                    ]),
                  )).toList(),
                ),
              ),
              if (today.exercises.length > 3)
                Padding(
                  padding: const EdgeInsets.fromLTRB(
                      AppSpacing.lg, 0, AppSpacing.lg, AppSpacing.xs),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('+${today.exercises.length - 3} more exercises',
                        style: TextStyle(fontFamily: 'Inter',
                            color: AppColors.textMuted, fontSize: 11)),
                  ),
                ),

              // CTA
              Padding(
                padding: const EdgeInsets.fromLTRB(
                    AppSpacing.lg, AppSpacing.sm,
                    AppSpacing.lg, AppSpacing.lg),
                child: today.isCompleted
                    ? Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            vertical: AppSpacing.md),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [
                            AppColors.green.withValues(alpha: 0.14),
                            AppColors.green.withValues(alpha: 0.05),
                          ]),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: AppColors.green.withValues(alpha: 0.3),
                              width: 0.8),
                        ),
                        child: Row(mainAxisAlignment:
                            MainAxisAlignment.center, children: [
                          const Icon(Icons.check_circle_rounded,
                              color: AppColors.green, size: 15),
                          const SizedBox(width: 6),
                          Text('Crushed it! You\'re unstoppable 🔥',
                              style: TextStyle(fontFamily: 'Inter',
                                  color: AppColors.green, fontSize: 12,
                                  fontWeight: FontWeight.w700)),
                        ]),
                      )
                    : GoldButton(
                        text: 'Start Workout 💪',
                        icon: Icons.play_arrow_rounded,
                        width: double.infinity,
                        onTap: () => Navigator.push(context, slideRoute(
                            PlannerScreen(
                                initialDayIndex: data.todayIndex))),
                      ),
              ),
            ]),
          ),
        );
      },
    );
  }
}

// ════════════════════════════════════════════════
// QUICK ACTIONS
// ════════════════════════════════════════════════
class _QuickActions extends StatelessWidget {
  const _QuickActions();

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, double>(
      selector: (_, ap) => ap.waterProgress,
      builder: (context, waterPct, _) {
        final wColor = waterPct >= 0.7 ? AppColors.green : AppColors.blue;
        return Row(children: [
          _ActionTile(
            emoji: '💧', label: 'Water',
            value: '${(waterPct * 100).toInt()}%', color: wColor,
            onTap: () {
              _H.light();
              final ap = context.read<AppProvider>();
              ap.addWater(250);
              context.read<GamificationProvider>().checkAutoMissions(
                  waterProgress: ap.waterProgress, totalSetsDone: 0);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: const Text('💧 +250ml — stay hydrated, champion!'),
                backgroundColor: AppColors.blue,
                duration: const Duration(seconds: 1),
                behavior: SnackBarBehavior.floating,
                margin: const EdgeInsets.fromLTRB(16, 0, 16, 90),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ));
            },
          ),
          const SizedBox(width: AppSpacing.md),
          _ActionTile(
            emoji: '🤖', label: 'AI Chat', value: 'Ask',
            color: AppColors.gold,
            onTap: () => Navigator.push(
                context, slideRoute(const AIChatScreen())),
          ),
          const SizedBox(width: AppSpacing.md),
          _ActionTile(
            emoji: '⚡', label: 'Generate', value: 'Plan',
            color: AppColors.purple,
            onTap: () => Navigator.push(
                context, slideRoute(const AISetupScreen())),
          ),
        ]);
      },
    );
  }
}

class _ActionTile extends StatelessWidget {
  final String emoji, label, value;
  final Color color;
  final VoidCallback onTap;
  const _ActionTile({required this.emoji, required this.label,
      required this.value, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
    child: _Tap(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
            vertical: AppSpacing.lg, horizontal: AppSpacing.sm),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(AppSpacing.md),
          border: Border.all(
              color: color.withValues(alpha: 0.24), width: 0.8),
          boxShadow: [BoxShadow(
            color: color.withValues(alpha: 0.09),
            blurRadius: 12, spreadRadius: 0,
          )],
        ),
        child: Column(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.11),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(child: Text(emoji,
                style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(value, style: TextStyle(fontFamily: 'Rajdhani',
              color: color, fontSize: 17, fontWeight: FontWeight.w900)),
          Text(label, style: TextStyle(fontFamily: 'Inter',
              color: AppColors.textMuted, fontSize: 10,
              fontWeight: FontWeight.w500)),
        ]),
      ),
    ),
  );
}

// ════════════════════════════════════════════════
// STATS ROW
// ════════════════════════════════════════════════
class _StatsRow extends StatelessWidget {
  const _StatsRow();

  @override
  Widget build(BuildContext context) {
    return Selector2<AppProvider, GamificationProvider,
        ({int totalWorkouts, int longestStreak, int weeklyXP})>(
      selector: (_, ap, gp) => (
        totalWorkouts: ap.streak.totalWorkouts,
        longestStreak: ap.streak.longestStreak,
        weeklyXP:      gp.xp.weeklyXP,
      ),
      builder: (_, data, __) => Row(children: [
        _ImpactStat(emoji: '🏋️', value: '${data.totalWorkouts}',
            label: 'Sessions', color: AppColors.gold),
        const SizedBox(width: AppSpacing.md),
        _ImpactStat(emoji: '🔥', value: '${data.longestStreak}d',
            label: 'Best Streak', color: AppColors.orange),
        const SizedBox(width: AppSpacing.md),
        _ImpactStat(emoji: '⚡', value: '${data.weeklyXP}',
            label: 'XP This Week', color: AppColors.purple),
      ]),
    );
  }
}

class _ImpactStat extends StatelessWidget {
  final String emoji, value, label;
  final Color color;
  const _ImpactStat({required this.emoji, required this.value,
      required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(
          vertical: AppSpacing.lg, horizontal: AppSpacing.sm),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(AppSpacing.md),
        border: Border.all(
            color: color.withValues(alpha: 0.20), width: 0.8),
      ),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: AppSpacing.xs),
        Text(value, style: TextStyle(fontFamily: 'Rajdhani',
            color: color, fontSize: 24,
            fontWeight: FontWeight.w900, letterSpacing: 0.4)),
        Text(label, style: TextStyle(fontFamily: 'Inter',
            color: AppColors.textMuted, fontSize: 9.5,
            fontWeight: FontWeight.w500),
            textAlign: TextAlign.center),
      ]),
    ),
  );
}

// ════════════════════════════════════════════════
// BADGES SCROLL — shimmer sweep on unlocked
// ════════════════════════════════════════════════
class _BadgesScroll extends StatelessWidget {
  const _BadgesScroll();

  @override
  Widget build(BuildContext context) {
    return Selector<AppProvider, List<String>>(
      selector: (_, ap) => ap.streak.earnedBadges,
      builder: (_, earned, __) => SizedBox(
        height: 98,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: BadgeSystem.all.length,
          separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.sm),
          itemBuilder: (_, i) {
            final badge    = BadgeSystem.all[i];
            final unlocked = earned.contains(badge.id);
            return _BadgeTile(badge: badge, unlocked: unlocked,
                delay: Duration(milliseconds: i * 50));
          },
        ),
      ),
    );
  }
}

class _BadgeTile extends StatefulWidget {
  final AppBadge badge;
  final bool unlocked;
  final Duration delay;
  const _BadgeTile({required this.badge, required this.unlocked,
      required this.delay});

  @override
  State<_BadgeTile> createState() => _BadgeTileState();
}

class _BadgeTileState extends State<_BadgeTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _sw;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 1800));
    _sw = Tween<double>(begin: -1.5, end: 2.5)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
    if (widget.unlocked) {
      Future.delayed(widget.delay, () { if (mounted) _ctrl.repeat(); });
    }
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 74,
    child: AnimatedBuilder(
      animation: _sw,
      builder: (_, __) => Stack(alignment: Alignment.bottomCenter, children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 74, height: 74,
            decoration: BoxDecoration(
              color: widget.unlocked
                  ? AppColors.gold.withValues(alpha: 0.10)
                  : AppColors.bgCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: widget.unlocked
                      ? AppColors.gold.withValues(alpha: 0.38)
                      : AppColors.borderSoft,
                  width: widget.unlocked ? 1 : 0.5),
              boxShadow: widget.unlocked ? [BoxShadow(
                color: AppColors.gold.withValues(alpha: 0.14),
                blurRadius: 8)] : null,
            ),
            child: Stack(alignment: Alignment.center, children: [
              Text(widget.unlocked ? widget.badge.emoji : '🔒',
                  style: TextStyle(
                      fontSize: widget.unlocked ? 30 : 22)),
              if (widget.unlocked)
                Positioned.fill(child: Transform.translate(
                  offset: Offset(_sw.value * 74, 0),
                  child: Container(decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [
                      Colors.transparent,
                      Colors.white.withValues(alpha: 0.09),
                      Colors.transparent,
                    ]),
                  )),
                )),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Text(widget.badge.title, style: TextStyle(fontFamily: 'Inter',
            color: widget.unlocked ? AppColors.gold : AppColors.textMuted,
            fontSize: 8.5, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis),
        ),
      ]),
    ),
  );
}

// ════════════════════════════════════════════════
// OVERLAY TOASTS & POPUPS
// ════════════════════════════════════════════════
class _XPToast extends StatelessWidget {
  final int xp;
  const _XPToast({required this.xp});

  @override
  Widget build(BuildContext context) => Positioned(
    top: MediaQuery.of(context).padding.top + 60,
    right: AppSpacing.lg,
    child: TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 450),
      curve: Curves.elasticOut,
      builder: (_, v, child) => Transform.scale(scale: v, child: child),
      child: Container(
        padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg, vertical: AppSpacing.sm + 2),
        decoration: BoxDecoration(
          gradient: AppGradients.gold,
          borderRadius: BorderRadius.circular(AppRadii.pill),
          boxShadow: AppShadows.buttonGlow(),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Text('⚡', style: TextStyle(fontSize: 14)),
          const SizedBox(width: AppSpacing.xs),
          Text('+$xp XP', style: TextStyle(fontFamily: 'Rajdhani',
              color: Colors.black, fontSize: 16, fontWeight: FontWeight.w900)),
        ]),
      ),
    ),
  );
}

class _BadgePopup extends StatelessWidget {
  final AppBadge badge;
  const _BadgePopup({required this.badge});

  @override
  Widget build(BuildContext context) => Positioned.fill(
    child: IgnorePointer(child: Center(
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 550),
        curve: Curves.elasticOut,
        builder: (_, v, child) => Transform.scale(scale: v, child: child),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: AppSpacing.xxl + 8),
          padding: const EdgeInsets.all(AppSpacing.xxl + 4),
          decoration: BoxDecoration(
            color: AppColors.bgModal,
            borderRadius: BorderRadius.circular(AppRadii.xl),
            border: Border.all(
                color: AppColors.gold.withValues(alpha: 0.5), width: 1.5),
            boxShadow: [BoxShadow(
                color: AppColors.gold.withValues(alpha: 0.28),
                blurRadius: 44, spreadRadius: 4)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(badge.emoji, style: const TextStyle(fontSize: 56)),
            const SizedBox(height: AppSpacing.sm),
            Text('BADGE UNLOCKED!', style: TextStyle(fontFamily: 'Inter',
                color: AppColors.gold, fontSize: 11,
                fontWeight: FontWeight.w800, letterSpacing: 3)),
            const SizedBox(height: AppSpacing.xs + 2),
            Text(badge.title, style: AppTextStyles.h2),
            const SizedBox(height: AppSpacing.xs),
            Text(badge.description, style: AppTextStyles.bodySmall,
                textAlign: TextAlign.center),
            const SizedBox(height: AppSpacing.md),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.lg, vertical: 7),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  AppColors.gold.withValues(alpha: 0.18),
                  AppColors.gold.withValues(alpha: 0.08),
                ]),
                borderRadius: BorderRadius.circular(12)),
              child: Text('+${badge.xpReward} XP',
                  style: TextStyle(fontFamily: 'Rajdhani',
                      color: AppColors.gold, fontSize: 18,
                      fontWeight: FontWeight.w900)),
            ),
          ]),
        ),
      ),
    )),
  );
}

class _RankUpPopup extends StatelessWidget {
  final UserRank rank;
  const _RankUpPopup({required this.rank});

  @override
  Widget build(BuildContext context) => Positioned.fill(
    child: IgnorePointer(child: Center(
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 650),
        curve: Curves.elasticOut,
        builder: (_, v, child) => Transform.scale(scale: v, child: child),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: AppSpacing.xxl),
          padding: const EdgeInsets.symmetric(
              vertical: AppSpacing.xxl, horizontal: AppSpacing.xxl),
          decoration: BoxDecoration(
            gradient: AppGradients.rankGradient(rank.index),
            borderRadius: BorderRadius.circular(AppRadii.xl),
            boxShadow: AppShadows.floating,
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(rank.emoji, style: const TextStyle(fontSize: 64)),
            const SizedBox(height: AppSpacing.md),
            Text('RANK UP!', style: TextStyle(fontFamily: 'Inter',
                color: Colors.white.withValues(alpha: 0.7),
                fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 3.5)),
            const SizedBox(height: AppSpacing.xs),
            Text(rank.displayName.toUpperCase(), style: TextStyle(fontFamily: 'Rajdhani',
                color: Colors.white, fontSize: 38,
                fontWeight: FontWeight.w900, letterSpacing: 2)),
            const SizedBox(height: AppSpacing.xs + 2),
            Text('You\'ve levelled up — keep pushing! 🔥',
                style: TextStyle(fontFamily: 'Inter',
                    color: Colors.white.withValues(alpha: 0.85), fontSize: 13)),
          ]),
        ),
      ),
    )),
  );
}

class _StreakToast extends StatelessWidget {
  final int streak;
  const _StreakToast({required this.streak});

  @override
  Widget build(BuildContext context) => Positioned(
    bottom: 98, left: AppSpacing.xl, right: AppSpacing.xl,
    child: TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 460),
      curve: Curves.easeOutBack,
      builder: (_, v, child) => Transform.translate(
          offset: Offset(0, 22 * (1 - v)),
          child: Opacity(opacity: v, child: child)),
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.lg),
        decoration: BoxDecoration(
          color: AppColors.bgModal,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: AppColors.orange.withValues(alpha: 0.42), width: 1),
          boxShadow: AppShadows.colored(AppColors.orange),
        ),
        child: Row(children: [
          const Text('🔥', style: TextStyle(fontSize: 30)),
          const SizedBox(width: AppSpacing.md),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$streak-Day Streak! 🔥', style: TextStyle(fontFamily: 'Rajdhani',
                  color: AppColors.orange, fontSize: 19,
                  fontWeight: FontWeight.w900)),
              Text('You\'re unstoppable. Never break the chain.',
                  style: TextStyle(fontFamily: 'Inter',
                      color: AppColors.textSecondary, fontSize: 12,
                      height: 1.4)),
            ],
          )),
        ]),
      ),
    ),
  );
}

// ════════════════════════════════════════════════
// ANIMATION HELPERS
// ════════════════════════════════════════════════
class _FadeSlide extends StatefulWidget {
  final Widget child;
  final int delay;
  const _FadeSlide({required this.child, required this.delay});

  @override
  State<_FadeSlide> createState() => _FadeSlideState();
}

class _FadeSlideState extends State<_FadeSlide>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 380));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
        begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: widget.delay),
            () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _fade,
    child: SlideTransition(position: _slide, child: widget.child),
  );
}

/// Scale-down tap feedback wrapper.
class _Tap extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _Tap({required this.child, required this.onTap});

  @override
  State<_Tap> createState() => _TapState();
}

class _TapState extends State<_Tap> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 80),
        reverseDuration: const Duration(milliseconds: 160));
    _scale = Tween<double>(begin: 1.0, end: 0.95)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown:   (_) => _ctrl.forward(),
    onTapUp:     (_) { _ctrl.reverse(); widget.onTap(); },
    onTapCancel: () => _ctrl.reverse(),
    child: ScaleTransition(scale: _scale, child: widget.child),
  );
}
